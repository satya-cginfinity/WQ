package main

import (
	"fmt"
	"log"
	"net/http"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/controllers"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/middleware"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/router"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
	"go.uber.org/dig"
)

//	@title			Excelergy API
//	@version		1.0
//	@description	API for Excelergy customer management
//	@termsOfService	http://swagger.io/terms/

//	@contact.name	API Support
//	@contact.email	support@shellenergy.com

//	@license.name	Apache 2.0
//	@license.url	http://www.apache.org/licenses/LICENSE-2.0.html

//	@host		localhost:50000
//	@BasePath	/

// @securityDefinitions.apikey	ApiKeyAuth
// @in							header
// @name						X-API-Key
func main() {
	container := dig.New()

	for _, dependency := range dependencies {
		if err := container.Provide(
			dependency.Constructor,
			dig.As(dependency.Interfaces...),
			dig.Group(dependency.Group),
		); err != nil {
			log.Fatalln("Error providing dependency:", err)
		}
	}

	if err := container.Invoke(func(logger logger.ILogger) {
		// You can use the logger here if needed
		logger.Info("Dependencies registered successfully.")
	}); err != nil {
		log.Fatalln("Error invoking logger:", err)
	}

	if err := container.Invoke(invokeServer); err != nil {
		log.Fatalln("Error invoking router:", err)
	}
}

type InvokeServerParams struct {
	dig.In
	Router      router.IRouter
	Config      router.IRouterConfig
	Logger      logger.ILogger
	Auth        middleware.IAPIKeyAuth
	Controllers []controllers.IController `group:"controllers"`
}

func invokeServer(params InvokeServerParams) {
	// Apply API key authentication middleware before registering routes
	params.Router.Use(params.Auth.Middleware)
	params.Logger.Info("API key authentication middleware applied")

	for _, controller := range params.Controllers {
		controller.RegisterRoutes(params.Router)
		params.Logger.Info("Controller routes registered")
	}

	addr := fmt.Sprintf(":%d", params.Config.RouterPort())
	info := fmt.Sprintf("Starting server at %s", addr)
	params.Logger.Info(info)

	if err := http.ListenAndServe(addr, params.Router); err != nil {
		params.Logger.Fatal("Failed to start server", "error", err)
	}
}
