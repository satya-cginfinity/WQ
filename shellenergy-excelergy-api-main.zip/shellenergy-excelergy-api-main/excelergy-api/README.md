# excelergy-api

Description: This is the main API for Excelergy

repo-team-owner: @sede-enterprise/teams/ses-backoffice-admin

created-by: David Alcazar (David.Alcazar@shellenergy.com)

---

## 📁 Project Structure & Architecture

This project follows a **clean architecture** approach with dependency injection using Uber's `dig` container. The structure is designed to promote separation of concerns, testability, and maintainability.

### Folder Structure

```
excelergy-api/
├── config/          # Configuration management
├── controllers/     # HTTP request handlers
├── docs/            # API documentation (Swagger)
├── logger/          # Logging infrastructure
├── router/          # HTTP routing layer
├── dependencies.go  # Dependency injection configuration
└── main.go          # Application entry point
```

### 🎯 Architectural Decisions

#### 1. **Dependency Injection with Uber Dig**
- **Why**: Promotes loose coupling and makes testing easier
- **Implementation**: All dependencies are registered in `dependencies.go` and resolved at runtime
- **Benefits**: 
  - Easy to mock dependencies for testing
  - Clear dependency graph
  - Prevents circular dependencies

#### 2. **Interface-Driven Design**
- **Why**: Enables flexibility and testability
- **Implementation**: Each package defines interfaces (prefixed with `I`) that concrete implementations satisfy
- **Examples**:
  - `IRouter` for routing abstraction
  - `IController` for controller contracts
  - `IConfig` for configuration access
- **Benefits**:
  - Easy to swap implementations (e.g., switching from Gin to another router)
  - Facilitates unit testing with mocks
  - Clear contracts between layers

#### 3. **Separation of Concerns**

##### **config/**
- **Purpose**: Centralized configuration management
- **Responsibilities**: 
  - Load environment variables
  - Provide configuration values to other components
  - Implement multiple config interfaces for different concerns
- **Decision**: Single config struct implementing multiple interfaces reduces duplication

##### **controllers/**
- **Purpose**: Handle HTTP requests and responses
- **Responsibilities**:
  - Parse request parameters
  - Validate input
  - Call business logic (via repositories)
  - Format responses
- **Decision**: Controllers should be thin—business logic lives in `excelergy-core`
- **Pattern**: Each controller registers its own routes via `RegisterRoutes()`

##### **router/**
- **Purpose**: Abstract the HTTP routing framework
- **Responsibilities**:
  - Define routing interface
  - Wrap framework-specific implementations (Gin)
  - Handle CORS and middleware
- **Decision**: Abstracts Gin behind `IRouter` interface for framework independence

##### **logger/**
- **Purpose**: Structured logging infrastructure
- **Responsibilities**:
  - Provide logging interface
  - Configure log format and output
  - Wrap underlying logger (Zap)
- **Decision**: API layer has its own logger configuration while using core logger interface

##### **docs/**
- **Purpose**: API documentation
- **Responsibilities**:
  - Host Swagger/OpenAPI specifications
  - Auto-generated from code annotations
- **Decision**: Keep docs close to API code for easier maintenance

#### 4. **Layered Architecture**

```
┌─────────────────────────────────────┐
│         main.go (Entry Point)       │
│    - Bootstrap DI container         │
│    - Start HTTP server              │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│         Router Layer                │
│    - HTTP routing                   │
│    - Middleware                     │
│    - CORS handling                  │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│       Controllers Layer             │
│    - Request/Response handling      │
│    - Input validation               │
│    - HTTP concerns                  │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│      excelergy-core                 │
│    - Business logic                 │
│    - Data access                    │
│    - External API integration       │
└─────────────────────────────────────┘
```

**Decision Rationale**: This layering ensures that:
- HTTP concerns stay in the API layer
- Business logic lives in the core layer
- Easy to add new interfaces (GraphQL, gRPC) without touching business logic

#### 5. **Controller Registration Pattern**

- **Implementation**: Controllers are registered as a group in the DI container
- **Process**:
  1. Each controller implements `IController` interface
  2. Controllers are provided with `dig.Group("controllers")`
  3. At startup, all controllers auto-register their routes
- **Benefits**:
  - Adding new controllers is simple—just add to dependencies
  - No manual route registration needed
  - Self-documenting through interface contracts

### 🔧 Configuration Management

The `Config` struct implements multiple interfaces:
- `IConfig`: General configuration
- `IRouterConfig`: Router-specific settings
- `ILoggerConfig`: Logger-specific settings
- `IClientConfig`: HTTP client settings (from core)

**Why**: Single source of truth for configuration while maintaining interface segregation principle.

### 🚀 Bootstrap Process

1. **Create DI Container**: Initialize Uber Dig container
2. **Register Dependencies**: Loop through `dependencies` array
3. **Provide Constructors**: Register each component with its interfaces
4. **Invoke Server**: Start HTTP server with all dependencies resolved
5. **Register Routes**: Controllers automatically register their endpoints

### 📝 Best Practices

1. **Keep controllers thin**: Business logic belongs in `excelergy-core`
2. **Use interfaces**: Always depend on abstractions, not concretions
3. **Constructor injection**: All dependencies passed via constructors
4. **Error handling**: Return errors up the stack, log at appropriate level
5. **HTTP semantics**: Use correct status codes and content types

### 🔗 Integration with excelergy-core

The API layer depends on `excelergy-core` for:
- **Repositories**: Data access and external API calls
- **Entities**: Shared data structures
- **Logger interface**: Common logging abstraction
- **HTTP Client**: Configured client for external APIs

This separation allows the core business logic to be reused across multiple interfaces (REST API, CLI, etc.).

---

## 🚀 Getting Started

### Prerequisites

- **Go**: 1.25 or higher
- **Git**: For cloning the repository
- **swag CLI**: For generating Swagger documentation (optional)

### Installation

1. **Clone the repository**:
```bash
git clone https://github.com/sede-enterprise/shellenergy-excelergy-api.git
cd shellenergy-excelergy-api/excelergy-api
```

2. **Install dependencies**:
```bash
go mod download
```

3. **Set up environment variables**:
```bash
cp .env.template .env
```

Edit `.env` with your configuration:
```dotenv
DEVELOPMENT=true                                    # Enable development mode
ROUTER_PORT=50000                                    # Port for the API server
ALLOW_CORS=true                                     # Enable CORS
ALLOWED_CORS_ORIGINS=http://localhost:4001          # Comma-separated list of allowed origins
HTTP_BASE_URL=https://api.example.com               # Base URL for external API
HTTP_TIMEOUT=60                                     # HTTP request timeout in seconds
HTTP_TOKEN=your_api_token_here                      # Authentication token for external API
```

### Running the Application

#### Development Mode

```bash
# From the excelergy-api directory
go run main.go dependencies.go
```

The server will start on the port specified in your `.env` file (default: `50000`).

You should see output like:
```
Dependencies registered successfully.
Controller routes registered
Controller routes registered
Starting server at :50000
```

#### Production Build

```bash
# Build the binary
go build -o excelergy-api

# Run the binary
./excelergy-api
```

#### Using Air (Hot Reload for Development)

Install Air for automatic reloading during development:
```bash
go install github.com/air-verse/air@latest

# Run with hot reload
air
```

### Accessing the API

Once running, you can access:

- **Health Check**: `http://localhost:50000/health`
- **Swagger Documentation**: `http://localhost:50000/swagger/index.html`
- **Customer Endpoint**: `http://localhost:50000/customer?customerId=123`

Example health check:
```bash
curl http://localhost:50000/health
```

---

## 🧪 Testing

### Running Tests

```bash
# Run all tests
go test ./...

# Run tests with verbose output
go test -v ./...

# Run tests with coverage
go test -cover ./...

# Generate coverage report
go test -coverprofile=coverage.out ./...
go tool cover -html=coverage.out -o coverage.html
```

### Test Structure

Tests should follow Go conventions:
- Test files: `*_test.go`
- Test functions: `func TestXxx(t *testing.T)`
- Table-driven tests for multiple scenarios

### Testing Best Practices

1. **Mock Dependencies**: Use interfaces to mock repositories, clients, and loggers
2. **Test Controllers**: Test HTTP handlers with `httptest.ResponseRecorder`
3. **Test Configuration**: Verify config loading and environment variable parsing
4. **Integration Tests**: Test full request/response cycle with test servers

Example controller test structure:
```go
func TestCustomerController_GetCustomer(t *testing.T) {
    // Setup mocks
    mockRepo := &MockCustomerRepository{}
    mockLogger := &MockLogger{}
    
    // Create controller
    controller := NewCustomerController(mockLogger, mockRepo, mockRouter)
    
    // Create test request
    req := httptest.NewRequest("GET", "/customer?customerId=123", nil)
    w := httptest.NewRecorder()
    
    // Execute
    controller.GetCustomer(w, req)
    
    // Assert
    assert.Equal(t, http.StatusOK, w.Code)
}
```

### Running Specific Tests

```bash
# Run tests in a specific package
go test ./controllers/...

# Run a specific test
go test -run TestCustomerController_GetCustomer ./controllers/

# Run tests with race detection
go test -race ./...
```

---

## 📚 Swagger Documentation

### Generating Swagger Docs

This project uses [swaggo/swag](https://github.com/swaggo/swag) to auto-generate Swagger documentation from code annotations.

#### Install Swag CLI

```bash
go install github.com/swaggo/swag/cmd/swag@latest
```

Verify installation:
```bash
swag --version
```

#### Generate Documentation

From the `excelergy-api` directory:

```bash
# Generate swagger docs
swag init

# Or with custom options
swag init --parseDependency --parseInternal
```

This will:
- Parse your Go comments for Swagger annotations
- Generate `docs/docs.go`, `docs/swagger.json`, and `docs/swagger.yaml`
- Update API documentation automatically

#### Format Swagger Comments

```bash
# Format swagger comments
swag fmt
```

### Adding Swagger Annotations

#### Main API Information

Add to `main.go`:
```go
// @title           Excelergy API
// @version         1.0
// @description     API for Excelergy customer management
// @termsOfService  http://swagger.io/terms/

// @contact.name   API Support
// @contact.email  support@shellenergy.com

// @license.name  Apache 2.0
// @license.url   http://www.apache.org/licenses/LICENSE-2.0.html

// @host      localhost:50000
// @BasePath  /

// @securityDefinitions.apikey BearerAuth
// @in header
// @name Authorization
```

#### Controller Endpoint Documentation

Add to controller methods:
```go
// GetCustomer godoc
// @Summary      Get customer by ID
// @Description  Retrieves customer information by customer ID
// @Tags         customers
// @Accept       json
// @Produce      json
// @Param        customerId  query     int  true  "Customer ID"
// @Success      200  {object}  entities.Customer
// @Failure      400  {object}  map[string]string
// @Failure      404  {object}  map[string]string
// @Failure      500  {object}  map[string]string
// @Router       /customer [get]
func (c *CustomerController) GetCustomer(w http.ResponseWriter, r *http.Request) {
    // Implementation
}
```

#### Common Swagger Annotations

- `@Summary`: Short description (appears in endpoint list)
- `@Description`: Detailed description
- `@Tags`: Group endpoints by category
- `@Accept`: Content types the endpoint accepts (json, xml, etc.)
- `@Produce`: Content types the endpoint returns
- `@Param`: Define parameters (query, path, header, body)
- `@Success`: Define successful responses
- `@Failure`: Define error responses
- `@Router`: Define the route path and HTTP method
- `@Security`: Apply security definitions

### Viewing Swagger UI

1. **Start the application**:
```bash
go run main.go dependencies.go
```

2. **Open Swagger UI in browser**:
```
http://localhost:50000/swagger/index.html
```

The Swagger UI provides:
- Interactive API documentation
- Try-it-out functionality to test endpoints
- Request/response examples
- Schema definitions

### Updating Documentation

Whenever you:
- Add new endpoints
- Modify existing endpoints
- Change request/response structures
- Update API metadata

**Remember to regenerate docs**:
```bash
swag init
```

Then restart your application to see the changes.

---

## 🛠️ Development Workflow

### Adding a New Controller

1. Create interface in `controllers/i[name]_controller.go`
2. Implement controller in `controllers/[name]_controller.go`
3. Add Swagger annotations to methods
4. Register in `dependencies.go` with `dig.Group("controllers")`
5. Run `swag init` to update docs
6. Test the new endpoint

### Adding a New Route

Controllers auto-register routes through the `RegisterRoutes()` method:

```go
func (c *MyController) RegisterRoutes(router router.IRouter) {
    router.GET("/my-endpoint", c.MyHandler)
    router.POST("/my-endpoint", c.CreateHandler)
}
```

### Environment-Specific Configuration

- **Development**: Set `DEVELOPMENT=true` for verbose logging and TLS verification skipping
- **Production**: Set `DEVELOPMENT=false` for production logging and strict TLS

---

## 🐛 Troubleshooting

### Common Issues

**Port already in use**:
```bash
# Find process using port 50000
lsof -i :50000

# Kill the process
kill -9 <PID>
```

**Missing dependencies**:
```bash
go mod tidy
go mod download
```

**Swagger not updating**:
```bash
# Clean and regenerate
rm -rf docs/
swag init
```

**Module not found errors**:
```bash
# Update module references
go mod edit -replace github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core=../excelergy-core
go mod tidy
```

---

## 📖 Additional Resources

- [Uber Dig Documentation](https://pkg.go.dev/go.uber.org/dig)
- [Gin Web Framework](https://gin-gonic.com/docs/)
- [Swaggo Documentation](https://github.com/swaggo/swag)
- [Zap Logger](https://pkg.go.dev/go.uber.org/zap)
- [Go Testing](https://golang.org/pkg/testing/)
