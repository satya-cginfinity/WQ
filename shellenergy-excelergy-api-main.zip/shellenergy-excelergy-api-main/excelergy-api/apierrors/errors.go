package apierrors

import (
	"encoding/json"
	"fmt"
	"net/http"
)

// ErrorDetail holds the structured error fields returned in every error response.
type ErrorDetail struct {
	Code    string      `json:"code"`
	Message string      `json:"message"`
	Details interface{} `json:"details,omitempty"`
}

// ErrorResponse is the top-level envelope for all error responses.
type ErrorResponse struct {
	Error ErrorDetail `json:"error"`
}

// APIError represents an error that maps to a specific HTTP status code.
type APIError struct {
	HTTPStatus int
	Code       string
	Message    string
	Err        error // underlying error; surfaced as "details" in development mode only
}

// Error implements the error interface.
func (e *APIError) Error() string {
	if e.Err != nil {
		return fmt.Sprintf("%s: %v", e.Message, e.Err)
	}
	return e.Message
}

// Unwrap returns the underlying error for errors.Is / errors.As support.
func (e *APIError) Unwrap() error {
	return e.Err
}

// --- Constructors for each supported HTTP error status ---

// NewBadRequest creates a 400 Bad Request error.
func NewBadRequest(message string, err error) *APIError {
	return &APIError{
		HTTPStatus: http.StatusBadRequest,
		Code:       "BAD_REQUEST",
		Message:    message,
		Err:        err,
	}
}

// NewUnauthorized creates a 401 Unauthorized error.
func NewUnauthorized(message string, err error) *APIError {
	return &APIError{
		HTTPStatus: http.StatusUnauthorized,
		Code:       "UNAUTHORIZED",
		Message:    message,
		Err:        err,
	}
}

// NewForbidden creates a 403 Forbidden error.
func NewForbidden(message string, err error) *APIError {
	return &APIError{
		HTTPStatus: http.StatusForbidden,
		Code:       "FORBIDDEN",
		Message:    message,
		Err:        err,
	}
}

// NewNotFound creates a 404 Not Found error.
func NewNotFound(message string, err error) *APIError {
	return &APIError{
		HTTPStatus: http.StatusNotFound,
		Code:       "NOT_FOUND",
		Message:    message,
		Err:        err,
	}
}

// NewRateLimitExceeded creates a 429 Too Many Requests error.
func NewRateLimitExceeded(message string, err error) *APIError {
	return &APIError{
		HTTPStatus: http.StatusTooManyRequests,
		Code:       "RATE_LIMIT_EXCEEDED",
		Message:    message,
		Err:        err,
	}
}

// NewInternalError creates a 500 Internal Server Error.
func NewInternalError(message string, err error) *APIError {
	return &APIError{
		HTTPStatus: http.StatusInternalServerError,
		Code:       "INTERNAL_ERROR",
		Message:    message,
		Err:        err,
	}
}

// NewUpstreamError creates a 502 Bad Gateway error.
func NewUpstreamError(message string, err error) *APIError {
	return &APIError{
		HTTPStatus: http.StatusBadGateway,
		Code:       "UPSTREAM_ERROR",
		Message:    message,
		Err:        err,
	}
}

// NewTimeout creates a 504 Gateway Timeout error.
func NewTimeout(message string, err error) *APIError {
	return &APIError{
		HTTPStatus: http.StatusGatewayTimeout,
		Code:       "TIMEOUT",
		Message:    message,
		Err:        err,
	}
}

// WriteJSON writes a structured JSON error response to the http.ResponseWriter.
// When isDevelopment is true the underlying error (if any) is included in the
// "details" field; in non-development environments details are omitted.
func WriteJSON(w http.ResponseWriter, apiErr *APIError, isDevelopment bool) {
	detail := ErrorDetail{
		Code:    apiErr.Code,
		Message: apiErr.Message,
	}

	if isDevelopment && apiErr.Err != nil {
		detail.Details = map[string]string{
			"error": apiErr.Err.Error(),
		}
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(apiErr.HTTPStatus)
	json.NewEncoder(w).Encode(ErrorResponse{Error: detail})
}
