package apierrors

import (
	"context"
	"errors"
	"net/http"
	"strings"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"
)

// ClassifyRepositoryError inspects the error returned by the repository layer
// and maps it to the appropriate structured APIError.
func ClassifyRepositoryError(err error) *APIError {
	// Check for context-level errors first.
	if errors.Is(err, context.DeadlineExceeded) {
		return NewTimeout("upstream request timed out", err)
	}
	if errors.Is(err, context.Canceled) {
		return NewTimeout("request was cancelled", err)
	}

	// Check for typed upstream errors from the repository.
	var upstreamErr *repository.UpstreamError
	if errors.As(err, &upstreamErr) {
		return ClassifyUpstreamStatus(upstreamErr)
	}

	// Fallback: 500 Internal Server Error.
	return NewInternalError("an unexpected error occurred", err)
}

// ClassifyUpstreamStatus maps an upstream (Fusion) HTTP status to the
// appropriate APIError.
func ClassifyUpstreamStatus(ue *repository.UpstreamError) *APIError {
	switch ue.StatusCode {
	case http.StatusUnauthorized: // 401
		return NewUnauthorized("upstream service returned unauthorized", ue)
	case http.StatusForbidden, http.StatusNotFound: // 403 & 404
		return NewNotFound("record not found in upstream service", ue)
	case http.StatusTooManyRequests: // 429
		return NewRateLimitExceeded("upstream rate limit exceeded, please retry later", ue)
	default:
		// Any other non-success status from the upstream is a 502.
		if ue.StatusCode > 0 {
			return NewUpstreamError(
				"upstream service returned an error",
				ue,
			)
		}

		// StatusCode == 0 means we could not reach the upstream at all or
		// the response was unparseable.
		errMsg := ""
		if ue.Err != nil {
			errMsg = ue.Err.Error()
		}

		if strings.Contains(errMsg, "context deadline exceeded") ||
			strings.Contains(errMsg, "Timeout") ||
			strings.Contains(errMsg, "timeout") {
			return NewTimeout("upstream request timed out", ue)
		}

		return NewUpstreamError("failed to communicate with upstream service", ue)
	}
}
