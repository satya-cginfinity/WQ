package router

type IRouterConfig interface {
	RouterPort() int
	IsDevelopment() bool
	AllowCORS() bool
	AllowedCORSOrigins() []string
}
