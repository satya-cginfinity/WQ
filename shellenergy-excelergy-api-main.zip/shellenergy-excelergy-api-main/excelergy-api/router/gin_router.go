package router

import (
	"net/http"

	"github.com/gin-gonic/gin"
	core_logger "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
)

// GinRouter is a Gin-based implementation of IRouter
type GinRouter struct {
	engine *gin.Engine
	group  *gin.RouterGroup
	config IRouterConfig
	logger core_logger.ILogger
}

// NewGinRouter creates a new GinRouter instance
func NewGinRouter(config IRouterConfig, logger core_logger.ILogger) IRouter {
	engine := gin.Default()
	return &GinRouter{
		engine: engine,
		group:  &engine.RouterGroup,
		config: config,
		logger: logger,
	}
}

// GET registers a route for HTTP GET requests
func (g *GinRouter) GET(path string, handler http.HandlerFunc) {
	g.group.GET(path, gin.WrapF(handler))
}

// POST registers a route for HTTP POST requests
func (g *GinRouter) POST(path string, handler http.HandlerFunc) {
	g.group.POST(path, gin.WrapF(handler))
}

// PUT registers a route for HTTP PUT requests
func (g *GinRouter) PUT(path string, handler http.HandlerFunc) {
	g.group.PUT(path, gin.WrapF(handler))
}

// DELETE registers a route for HTTP DELETE requests
func (g *GinRouter) DELETE(path string, handler http.HandlerFunc) {
	g.group.DELETE(path, gin.WrapF(handler))
}

// PATCH registers a route for HTTP PATCH requests
func (g *GinRouter) PATCH(path string, handler http.HandlerFunc) {
	g.group.PATCH(path, gin.WrapF(handler))
}

// Use adds middleware to the router.
// If the middleware rejects the request (does not call the inner handler),
// the Gin handler chain is aborted so no subsequent handlers run.
func (g *GinRouter) Use(middleware func(http.Handler) http.Handler) {
	g.group.Use(func(c *gin.Context) {
		nextCalled := false
		middleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			nextCalled = true
			c.Next()
		})).ServeHTTP(c.Writer, c.Request)
		if !nextCalled {
			c.Abort()
		}
	})
}

// Group creates a route group with a common prefix
func (g *GinRouter) Group(prefix string) IRouter {
	newGroup := g.group.Group(prefix)
	return &GinRouter{
		engine: g.engine,
		group:  newGroup,
		config: g.config,
		logger: g.logger,
	}
}

// ServeHTTP implements the http.Handler interface
func (g *GinRouter) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	g.engine.ServeHTTP(w, r)
}
