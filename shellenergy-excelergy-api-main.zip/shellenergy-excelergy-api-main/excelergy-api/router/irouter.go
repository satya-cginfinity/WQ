package router

import "net/http"

// IRouter defines the interface for HTTP routing
type IRouter interface {
	// GET registers a route for HTTP GET requests
	GET(path string, handler http.HandlerFunc)

	// POST registers a route for HTTP POST requests
	POST(path string, handler http.HandlerFunc)

	// PUT registers a route for HTTP PUT requests
	PUT(path string, handler http.HandlerFunc)

	// DELETE registers a route for HTTP DELETE requests
	DELETE(path string, handler http.HandlerFunc)

	// PATCH registers a route for HTTP PATCH requests
	PATCH(path string, handler http.HandlerFunc)

	// Use adds middleware to the router
	Use(middleware func(http.Handler) http.Handler)

	// Group creates a route group with a common prefix
	Group(prefix string) IRouter

	// ServeHTTP implements the http.Handler interface
	ServeHTTP(w http.ResponseWriter, r *http.Request)
}
