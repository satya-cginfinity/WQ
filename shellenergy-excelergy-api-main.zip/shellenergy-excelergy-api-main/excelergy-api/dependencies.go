package main

import (
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/config"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/controllers"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/logger"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/middleware"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/router"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
	core_logger "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"
)

type Dependency struct {
	Constructor interface{}
	Interfaces  []interface{}
	Group       string
}

var dependencies = []Dependency{
	{
		Constructor: config.NewConfig,
		Interfaces: []interface{}{
			new(config.IConfig),
			new(router.IRouterConfig),
			new(logger.ILoggerConfig),
			new(client.IClientConfig),
			new(middleware.IAuthConfig),
		},
	},
	{
		Constructor: logger.NewLogger,
		Interfaces:  []interface{}{new(core_logger.ILogger)},
	},
	{
		Constructor: client.NewHTTPClient,
		Interfaces:  []interface{}{new(client.IClient)},
	},
	{
		Constructor: repository.NewCustomerRepository,
		Interfaces:  []interface{}{new(repository.ICustomerRepository)},
	},
	{
		Constructor: repository.NewAccountRepository,
		Interfaces:  []interface{}{new(repository.IAccountRepository)},
	},
	{
		Constructor: repository.NewCalendarRepository,
		Interfaces:  []interface{}{new(repository.ICalendarRepository)},
	},
	{
		Constructor: repository.NewReferenceRepository,
		Interfaces:  []interface{}{new(repository.IReferenceRepository)},
	},
	{
		Constructor: repository.NewInvoiceRepository,
		Interfaces:  []interface{}{new(repository.IInvoiceRepository)},
	},
	{
		Constructor: repository.NewLdcAccountRepository,
		Interfaces:  []interface{}{new(repository.ILdcAccountRepository)},
	},
	{
		Constructor: router.NewGinRouter,
		Interfaces:  []interface{}{new(router.IRouter)},
	},
	{
		Constructor: middleware.NewAPIKeyAuth,
		Interfaces:  []interface{}{new(middleware.IAPIKeyAuth)},
	},
	{
		Constructor: controllers.NewHealthController,
		Interfaces:  []interface{}{new(controllers.IController)},
		Group:       "controllers",
	},
	{
		Constructor: controllers.NewCustomerController,
		Interfaces:  []interface{}{new(controllers.IController)},
		Group:       "controllers",
	},
	{
		Constructor: controllers.NewAccountController,
		Interfaces:  []interface{}{new(controllers.IController)},
		Group:       "controllers",
	},
	{
		Constructor: controllers.NewCalendarController,
		Interfaces:  []interface{}{new(controllers.IController)},
		Group:       "controllers",
	},
	{
		Constructor: controllers.NewLdcAccountController,
		Interfaces:  []interface{}{new(controllers.IController)},
		Group:       "controllers",
	},
	{
		Constructor: controllers.NewReferenceController,
		Interfaces:  []interface{}{new(controllers.IController)},
		Group:       "controllers",
	},
	{
		Constructor: controllers.NewInvoiceController,
		Interfaces:  []interface{}{new(controllers.IController)},
		Group:       "controllers",
	},
	{
		Constructor: controllers.NewSwaggerController,
		Interfaces:  []interface{}{new(controllers.IController)},
		Group:       "controllers",
	}}
