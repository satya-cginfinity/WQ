package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type MonthlyUsageResponse struct {
	BeginningReading          float64                   `json:"beginningReading"`
	BillMethodCode            string                    `json:"billMethodCode"`
	BillMethodDesc            string                    `json:"billMethodDesc"`
	CancelIn                  bool                      `json:"cancelIn"`
	CreationDateTime          coreEntities.FlexibleTime `json:"creationDateTime"`
	DisplayCode               string                    `json:"displayCode"`
	DisplayName               string                    `json:"displayName"`
	EffectiveQuantity         float64                   `json:"effectiveQuantity"`
	EndingReading             float64                   `json:"endingReading"`
	FinalRead                 bool                      `json:"finalRead"`
	FirstDSTInterval          int32                     `json:"firstDSTInterval"`
	HasIntervals              bool                      `json:"hasIntervals"`
	IntervalFreqInMinutes     uint32                    `json:"intervalFreqInMinutes"`
	InvoiceHoldExpirationDate coreEntities.FlexibleTime `json:"invoiceHoldExpirationDate"`
	IsEligibleForSkipMatch    bool                      `json:"isEligibleForSkipMatch"`
	LDCAccountId              uint64                    `json:"ldcAccountId"`
	MeasSignificanceCode      string                    `json:"measSignificanceCode"`
	MeasSignificanceDesc      string                    `json:"measSignificanceDesc"`
	MeasurementRefCode        string                    `json:"measurementRefCode"`
	MeasurementRefDesc        string                    `json:"measurementRefDesc"`
	MeterMultiplier           float64                   `json:"meterMultiplier"`
	MeterNo                   string                    `json:"meterNo"`
	MeterRoleCode             string                    `json:"meterRoleCode"`
	OriginCode                string                    `json:"originCode"`
	OriginDesc                string                    `json:"originDesc"`
	PowerFactor               float64                   `json:"powerFactor"`
	PPAReasonCode             string                    `json:"ppaReasonCode"`
	PPARerate                 bool                      `json:"ppaRerate"`
	PrecedenceNo              uint32                    `json:"precedenceNo"`
	QualifierCode             string                    `json:"qualifierCode"`
	QualifierDesc             string                    `json:"qualifierDesc"`
	QuantityDelivered         float64                   `json:"quantityDelivered"`
	QuantityDeliveredInterval float64                   `json:"quantityDeliveredInterval"`
	QuantityDeliveredUOMCode  string                    `json:"quantityDeliveredUOMCode"`
	QuantityDeliveredUOMDesc  string                    `json:"quantityDeliveredUOMDesc"`
	Rated                     string                    `json:"rated"`
	ReferenceNumber           string                    `json:"referenceNumber"`
	ServicePeriodBeginDate    coreEntities.FlexibleTime `json:"servicePeriodBeginDate"`
	ServicePeriodEndDate      coreEntities.FlexibleTime `json:"servicePeriodEndDate"`
	ServicePeriodId           uint64                    `json:"servicePeriodId"`
	Skip810867MatchIn         bool                      `json:"skip810867MatchIn"`
	SkipHiLoValidation        bool                      `json:"skipHiLoValidation"`
	TimeZone                  string                    `json:"timeZone"`
	TransformerLossMultiplier float64                   `json:"transformerLossMultiplier"`
	TrueUp                    bool                      `json:"trueUp"`
	UnitOfMeasureCode         string                    `json:"unitOfMeasureCode"`
	UnitOfMeasureDesc         string                    `json:"unitOfMeasureDesc"`
	Units                     float64                   `json:"units"`
}

// FromCoreMonthlyUsage converts a core MonthlyUsage entity to a MonthlyUsageResponse
func FromCoreMonthlyUsage(monthlyUsage *coreEntities.MonthlyUsage) *MonthlyUsageResponse {
	if monthlyUsage == nil {
		return nil
	}
	return &MonthlyUsageResponse{
		BeginningReading:          monthlyUsage.BeginningReading,
		BillMethodCode:            monthlyUsage.BillMethodCode,
		BillMethodDesc:            monthlyUsage.BillMethodDesc,
		CancelIn:                  monthlyUsage.CancelIn,
		CreationDateTime:          monthlyUsage.CreationDateTime,
		DisplayCode:               monthlyUsage.DisplayCode,
		DisplayName:               monthlyUsage.DisplayName,
		EffectiveQuantity:         monthlyUsage.EffectiveQuantity,
		EndingReading:             monthlyUsage.EndingReading,
		FinalRead:                 monthlyUsage.FinalRead,
		FirstDSTInterval:          monthlyUsage.FirstDSTInterval,
		HasIntervals:              monthlyUsage.HasIntervals,
		IntervalFreqInMinutes:     monthlyUsage.IntervalFreqInMinutes,
		InvoiceHoldExpirationDate: monthlyUsage.InvoiceHoldExpirationDate,
		IsEligibleForSkipMatch:    monthlyUsage.IsEligibleForSkipMatch,
		LDCAccountId:              monthlyUsage.LDCAccountId,
		MeasSignificanceCode:      monthlyUsage.MeasSignificanceCode,
		MeasSignificanceDesc:      monthlyUsage.MeasSignificanceDesc,
		MeasurementRefCode:        monthlyUsage.MeasurementRefCode,
		MeasurementRefDesc:        monthlyUsage.MeasurementRefDesc,
		MeterMultiplier:           monthlyUsage.MeterMultiplier,
		MeterNo:                   monthlyUsage.MeterNo,
		MeterRoleCode:             monthlyUsage.MeterRoleCode,
		OriginCode:                monthlyUsage.OriginCode,
		OriginDesc:                monthlyUsage.OriginDesc,
		PowerFactor:               monthlyUsage.PowerFactor,
		PPAReasonCode:             monthlyUsage.PPAReasonCode,
		PPARerate:                 monthlyUsage.PPARerate,
		PrecedenceNo:              monthlyUsage.PrecedenceNo,
		QualifierCode:             monthlyUsage.QualifierCode,
		QualifierDesc:             monthlyUsage.QualifierDesc,
		QuantityDelivered:         monthlyUsage.QuantityDelivered,
		QuantityDeliveredInterval: monthlyUsage.QuantityDeliveredInterval,
		QuantityDeliveredUOMCode:  monthlyUsage.QuantityDeliveredUOMCode,
		QuantityDeliveredUOMDesc:  monthlyUsage.QuantityDeliveredUOMDesc,
		Rated:                     monthlyUsage.Rated,
		ReferenceNumber:           monthlyUsage.ReferenceNumber,
		ServicePeriodBeginDate:    monthlyUsage.ServicePeriodBeginDate,
		ServicePeriodEndDate:      monthlyUsage.ServicePeriodEndDate,
		ServicePeriodId:           monthlyUsage.ServicePeriodId,
		Skip810867MatchIn:         monthlyUsage.Skip810867MatchIn,
		SkipHiLoValidation:        monthlyUsage.SkipHiLoValidation,
		TimeZone:                  monthlyUsage.TimeZone,
		TransformerLossMultiplier: monthlyUsage.TransformerLossMultiplier,
		TrueUp:                    monthlyUsage.TrueUp,
		UnitOfMeasureCode:         monthlyUsage.UnitOfMeasureCode,
		UnitOfMeasureDesc:         monthlyUsage.UnitOfMeasureDesc,
		Units:                     monthlyUsage.Units,
	}
}
