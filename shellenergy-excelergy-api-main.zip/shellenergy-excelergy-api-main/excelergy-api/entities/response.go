package entities

// DataResponse is a generic wrapper that ensures all successful API responses
// are returned in the normalised envelope: {"data": [ ... ]}.
type DataResponse struct {
	Data interface{} `json:"data"`
}

// NewDataResponse wraps the given payload inside a DataResponse envelope.
func NewDataResponse(data interface{}) DataResponse {
	return DataResponse{Data: data}
}
