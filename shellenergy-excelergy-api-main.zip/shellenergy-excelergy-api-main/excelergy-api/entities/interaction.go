package entities

import coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"

type InteractionResponse struct {
	InteractionId    uint64 `json:"interactionId"`
	ContactName      string `json:"contactName"`
	Date             string `json:"date"`
	RelatedClassName string `json:"relatedClassName"`
	RelatedId        uint64 `json:"relatedId"`
	StartTime        int32  `json:"startTime"`
	SubTypeCode      string `json:"subTypeCode"`
	SubTypeCodeDesc  string `json:"subTypeCodeDesc"`
	Text             string `json:"text"`
	TypeCode         string `json:"typeCode"`
	UserName         string `json:"userName"`
}

// FromCoreInteraction converts a core Interaction entity to an InteractionResponse
func FromCoreInteraction(interaction *coreEntities.Interaction) *InteractionResponse {
	if interaction == nil {
		return nil
	}
	return &InteractionResponse{
		InteractionId:    interaction.InteractionId,
		ContactName:      interaction.ContactName,
		Date:             interaction.Date,
		RelatedClassName: interaction.RelatedClassName,
		RelatedId:        interaction.RelatedId,
		StartTime:        interaction.StartTime,
		SubTypeCode:      interaction.SubTypeCode,
		SubTypeCodeDesc:  interaction.SubTypeCodeDesc,
		Text:             interaction.Text,
		TypeCode:         interaction.TypeCode,
		UserName:         interaction.UserName,
	}
}
