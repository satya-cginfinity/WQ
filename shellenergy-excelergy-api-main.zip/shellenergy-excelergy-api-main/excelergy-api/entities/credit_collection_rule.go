package entities

import coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"

type CreditCollectionRuleResponse struct {
	AccountLevelLPC                      bool    `json:"accountLevelLPC"`
	ChargeLateFee                        bool    `json:"chargeLateFee"`
	ChargeOneTime                        bool    `json:"chargeOneTime"`
	CollectionScheduleId                 uint64  `json:"collectionScheduleId"`
	CustClassType                        string  `json:"custClassType"`
	DefaultRule                          bool    `json:"defaultRule"`
	DisplayCode                          string  `json:"displayCode"`
	DisplayName                          string  `json:"displayName"`
	DueDaysInvoiceNo                     uint32  `json:"dueDaysInvoiceNo"`
	DueDaysMonthNo                       uint32  `json:"dueDaysMonthNo"`
	GraceDaysNo                          uint32  `json:"graceDaysNo"`
	GracePeriod                          bool    `json:"gracePeriod"`
	GracePeriodString                    string  `json:"gracePeriodString"`
	InvoiceAmountIncludesPreviousBalance bool    `json:"invoiceAmountIncludesPreviousBalance"`
	InvoiceDate                          bool    `json:"invoiceDate"`
	InvoiceDueDateBaseCode               string  `json:"invoiceDueDateBaseCode"`
	IsCustom                             bool    `json:"isCustom"`
	LatePaymentChargePercentage          float64 `json:"latePaymentChargePercentage"`
	MaximumCharge                        float64 `json:"maximumCharge"`
	MaximumRefundAmount                  float64 `json:"maximumRefundAmount"`
	MinimumCharge                        float64 `json:"minimumCharge"`
	MinimumOverdue                       float64 `json:"minimumOverdue"`
	MinimumRefundAmount                  float64 `json:"minimumRefundAmount"`
	OverrideReason                       string  `json:"overrideReason"`
	RelateClassName                      string  `json:"relateClassName"`
	RelateId                             uint64  `json:"relateId"`
	RuleName                             string  `json:"ruleName"`
	Simple                               bool    `json:"simple"`
	SimpleCompoundCode                   string  `json:"simpleCompoundCode"`
	Today                                bool    `json:"today"`
	UseBusinessDays                      bool    `json:"useBusinessDays"`
}

// FromCoreCreditCollectionRule converts a core CreditCollectionRule entity to a CreditCollectionRuleResponse
func FromCoreCreditCollectionRule(rule *coreEntities.CreditCollectionRule) *CreditCollectionRuleResponse {
	if rule == nil {
		return nil
	}
	return &CreditCollectionRuleResponse{
		AccountLevelLPC:                      rule.AccountLevelLPC,
		ChargeLateFee:                        rule.ChargeLateFee,
		ChargeOneTime:                        rule.ChargeOneTime,
		CollectionScheduleId:                 rule.CollectionScheduleId,
		CustClassType:                        rule.CustClassType,
		DefaultRule:                          rule.DefaultRule,
		DisplayCode:                          rule.DisplayCode,
		DisplayName:                          rule.DisplayName,
		DueDaysInvoiceNo:                     rule.DueDaysInvoiceNo,
		DueDaysMonthNo:                       rule.DueDaysMonthNo,
		GraceDaysNo:                          rule.GraceDaysNo,
		GracePeriod:                          rule.GracePeriod,
		GracePeriodString:                    rule.GracePeriodString,
		InvoiceAmountIncludesPreviousBalance: rule.InvoiceAmountIncludesPreviousBalance,
		InvoiceDate:                          rule.InvoiceDate,
		InvoiceDueDateBaseCode:               rule.InvoiceDueDateBaseCode,
		IsCustom:                             rule.IsCustom,
		LatePaymentChargePercentage:          rule.LatePaymentChargePercentage,
		MaximumCharge:                        rule.MaximumCharge,
		MaximumRefundAmount:                  rule.MaximumRefundAmount,
		MinimumCharge:                        rule.MinimumCharge,
		MinimumOverdue:                       rule.MinimumOverdue,
		MinimumRefundAmount:                  rule.MinimumRefundAmount,
		OverrideReason:                       rule.OverrideReason,
		RelateClassName:                      rule.RelateClassName,
		RelateId:                             rule.RelateId,
		RuleName:                             rule.RuleName,
		Simple:                               rule.Simple,
		SimpleCompoundCode:                   rule.SimpleCompoundCode,
		Today:                                rule.Today,
		UseBusinessDays:                      rule.UseBusinessDays,
	}
}
