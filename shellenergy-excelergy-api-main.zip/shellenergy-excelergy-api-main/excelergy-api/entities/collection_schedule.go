package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type CollectionScheduleResponse struct {
	BillingType           string                    `json:"billingType"`
	BuisnessDayIn         bool                      `json:"buisnessDayIn"`
	CancelPaymentEventId  uint64                    `json:"cancelPaymentEventId"`
	CollectionEvents      []CollectionEventResponse `json:"collectionEvents"`
	Country               string                    `json:"country"`
	CustomerClassType     string                    `json:"customerClassType"`
	Name                  string                    `json:"name"`
	PADroppedResetEventId uint64                    `json:"paDroppedResetEventId"`
	ReducedBalanceEventId uint64                    `json:"reducedBalanceEventId"`
	ServiceType           string                    `json:"serviceType"`
	State                 string                    `json:"state"`
	TransTypes            []string                  `json:"transTypes"`
	Type                  string                    `json:"type"`
	VendorId              uint64                    `json:"vendorId"`
	VendorName            string                    `json:"vendorName"`
}

// FromCoreCollectionSchedule converts a core CollectionSchedule entity to a CollectionScheduleResponse
func FromCoreCollectionSchedule(schedule *coreEntities.CollectionSchedule) *CollectionScheduleResponse {
	if schedule == nil {
		return nil
	}
	var collectionEvents []CollectionEventResponse
	if schedule.CollectionEvents != nil {
		collectionEvents = make([]CollectionEventResponse, len(schedule.CollectionEvents))
		for i, event := range schedule.CollectionEvents {
			collectionEvents[i] = *FromCoreCollectionEvent(&event)
		}
	}

	return &CollectionScheduleResponse{
		BillingType:           schedule.BillingType,
		BuisnessDayIn:         schedule.BuisnessDayIn,
		CancelPaymentEventId:  schedule.CancelPaymentEventId,
		CollectionEvents:      collectionEvents,
		Country:               schedule.Country,
		CustomerClassType:     schedule.CustomerClassType,
		Name:                  schedule.Name,
		PADroppedResetEventId: schedule.PADroppedResetEventId,
		ReducedBalanceEventId: schedule.ReducedBalanceEventId,
		ServiceType:           schedule.ServiceType,
		State:                 schedule.State,
		TransTypes:            schedule.TransTypes,
		Type:                  schedule.Type,
		VendorId:              schedule.VendorId,
		VendorName:            schedule.VendorName,
	}
}
