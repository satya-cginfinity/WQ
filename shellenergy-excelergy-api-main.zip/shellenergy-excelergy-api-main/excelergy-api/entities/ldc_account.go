package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type LdcAccountResponse struct {
	AcctId                           uint64                     `json:"acctId"`
	ActiveIn                         bool                       `json:"activeIn"`
	Address                          *AddressResponse           `json:"address"`
	AddressId                        uint64                     `json:"addressId"`
	AlternateId                      string                     `json:"alternateId"`
	Balance                          *float64                   `json:"balance"`
	BillMethod                       string                     `json:"billMethod"`
	BudgetBill                       bool                       `json:"budgetBill"`
	BudgetBillActualCharges          float64                    `json:"budgetBillActualCharges"`
	BudgetBillBilledAmount           float64                    `json:"budgetBillBilledAmount"`
	BudgetBillPlans                  []BudgetBillPlanResponse   `json:"budgetBillPlans"`
	BudgetBillStatus                 *ReferenceCodeResponse     `json:"budgetBillStatus"`
	BudgetBillVariance               float64                    `json:"budgetBillVariance"`
	BudgetBillVarianceDisplay        string                     `json:"budgetBillVarianceDisplay"`
	BudgetBillVariancePercent        float64                    `json:"budgetBillVariancePercent"`
	BudgetBillVariancePercentDisplay string                     `json:"budgetBillVariancePercentDisplay"`
	BuildingType                     string                     `json:"buildingType"`
	BuildYear                        uint32                     `json:"buildYear"`
	ClassName                        string                     `json:"className"`
	CollectionScheduleId             uint64                     `json:"collectionScheduleId"`
	ContractStartDate                coreEntities.FlexibleTime  `json:"contractStartDate"`
	CoolSource                       string                     `json:"coolSource"`
	County                           string                     `json:"county"`
	CustomerClassType                string                     `json:"customerClassType"`
	DepositEscrows                   []DepositEscrowResponse    `json:"depositEscrows"`
	DisplayNameAndNumber             string                     `json:"displayNameAndNumber"`
	EligibleLoadPercentage           float64                    `json:"eligibleLoadPercentage"`
	EndDate                          coreEntities.FlexibleTime  `json:"endDate"`
	EquivalentStatus                 string                     `json:"equivalentStatus"`
	ESPRateCode                      string                     `json:"espRateCode"`
	HasNominations                   bool                       `json:"hasNominations"`
	HeatSource                       string                     `json:"heatSource"`
	Interactions                     []InteractionResponse      `json:"interactions"`
	InvoiceAdvices                   []InvoiceAdviceResponse    `json:"invoiceAdvices"`
	InvoiceMessage                   string                     `json:"invoiceMessage"`
	InvoiceMessageExternal           string                     `json:"invoiceMessageExternal"`
	IsPendingXBRProcessing           bool                       `json:"isPendingXBRProcessing"`
	LDCAccountId                     uint64                     `json:"ldcAccountId"`
	LDCAccountName                   string                     `json:"ldcAccountName"`
	LDCAcctAttn                      string                     `json:"ldcAcctAttn"`
	LDCAcctNo                        string                     `json:"ldcAcctNo"`
	LDCRateClass                     string                     `json:"ldcRateClass"`
	LDCRateCode                      string                     `json:"ldcRateCode"`
	MonthlyUsages                    []MonthlyUsageResponse     `json:"monthlyUsages"`
	NewCharge                        *TransactionResponse       `json:"newCharge"`
	NewCredit                        *TransactionResponse       `json:"newCredit"`
	Nominations                      []NominationResponse       `json:"nominations"`
	NonPassThruDomain                string                     `json:"nonPassThruDomain"`
	NotificationWaiverIndicator      bool                       `json:"notificationWaiverIndicator"`
	NumberOfMeters                   uint32                     `json:"numberOfMeters"`
	OldLDCAcct1No                    string                     `json:"oldLdcAcct1No"`
	OldLDCAcct2No                    string                     `json:"oldLdcAcct2No"`
	OwnBuilding                      bool                       `json:"ownBuilding"`
	ParticipationPercent             float64                    `json:"participationPercent"`
	PrevInvoiceBalAm                 *float64                   `json:"prevInvoiceBalAm"`
	PricePlans                       []PricePlanResponse        `json:"pricePlans"`
	ProfitCenter                     string                     `json:"profitCenter"`
	ProfitMargin                     float64                    `json:"profitMargin"`
	ProtectionRelates                []ProtectionRelateResponse `json:"protectionRelates"`
	ReadCycle                        uint32                     `json:"readCycle"`
	RenewableEnergy                  bool                       `json:"renewableEnergy"`
	SalesRep                         string                     `json:"salesRep"`
	LDCAccountType                   string                     `json:"ldcAccountType"`
	SICCode                          string                     `json:"sicCode"`
	SquareFootage                    float64                    `json:"squareFootage"`
	StartDate                        coreEntities.FlexibleTime  `json:"startDate"`
	StartTime                        coreEntities.FlexibleTime  `json:"startTime"`
	Status                           string                     `json:"status"`
	StatusHistReason                 string                     `json:"statusHistReason"`
	StoreNumber                      string                     `json:"storeNumber"`
	SysTimeStamp                     coreEntities.FlexibleTime  `json:"sysTimeStamp"`
	TaxExemptPercent                 float64                    `json:"taxExemptPercent"`
	TemperatureZoneId                uint64                     `json:"temperatureZoneId"`
	Term                             uint32                     `json:"term"`
	TimeZone                         string                     `json:"timeZone"`
	UtilityBudgetBill                bool                       `json:"utilityBudgetBill"`
	VendorDBNo                       string                     `json:"vendorDBNo"`
	VendorId                         uint64                     `json:"vendorId"`
	VendorName                       string                     `json:"vendorName"`
	Zone                             string                     `json:"zone"`
}

// FromCoreLdcAccount converts a core LdcAccount entity to a LdcAccountResponse
func FromCoreLdcAccount(ldcAccount *coreEntities.LdcAccount) *LdcAccountResponse {
	if ldcAccount == nil {
		return nil
	}
	return &LdcAccountResponse{
		AcctId:                           ldcAccount.AcctId,
		ActiveIn:                         ldcAccount.ActiveIn,
		Address:                          FromCoreAddress(ldcAccount.Address),
		AddressId:                        ldcAccount.AddressId,
		AlternateId:                      ldcAccount.AlternateId,
		Balance:                          ldcAccount.Balance,
		BillMethod:                       ldcAccount.BillMethod,
		BudgetBill:                       ldcAccount.BudgetBill,
		BudgetBillActualCharges:          ldcAccount.BudgetBillActualCharges,
		BudgetBillBilledAmount:           ldcAccount.BudgetBillBilledAmount,
		BudgetBillPlans:                  FromCoreBudgetBillPlans(ldcAccount.BudgetBillPlans),
		BudgetBillStatus:                 FromCoreReferenceCode(ldcAccount.BudgetBillStatus),
		BudgetBillVariance:               ldcAccount.BudgetBillVariance,
		BudgetBillVarianceDisplay:        ldcAccount.BudgetBillVarianceDisplay,
		BudgetBillVariancePercent:        ldcAccount.BudgetBillVariancePercent,
		BudgetBillVariancePercentDisplay: ldcAccount.BudgetBillVariancePercentDisplay,
		BuildingType:                     ldcAccount.BuildingType,
		BuildYear:                        ldcAccount.BuildYear,
		ClassName:                        ldcAccount.ClassName,
		CollectionScheduleId:             ldcAccount.CollectionScheduleId,
		ContractStartDate:                ldcAccount.ContractStartDate,
		CoolSource:                       ldcAccount.CoolSource,
		County:                           ldcAccount.County,
		CustomerClassType:                ldcAccount.CustomerClassType,
		DepositEscrows:                   FromCoreDepositEscrows(ldcAccount.DepositEscrows),
		DisplayNameAndNumber:             ldcAccount.DisplayNameAndNumber,
		EligibleLoadPercentage:           ldcAccount.EligibleLoadPercentage,
		EndDate:                          ldcAccount.EndDate,
		EquivalentStatus:                 ldcAccount.EquivalentStatus,
		ESPRateCode:                      ldcAccount.ESPRateCode,
		HasNominations:                   ldcAccount.HasNominations,
		HeatSource:                       ldcAccount.HeatSource,
		Interactions:                     FromCoreInteractions(ldcAccount.Interactions),
		InvoiceAdvices:                   FromCoreInvoiceAdvices(ldcAccount.InvoiceAdvices),
		InvoiceMessage:                   ldcAccount.InvoiceMessage,
		InvoiceMessageExternal:           ldcAccount.InvoiceMessageExternal,
		IsPendingXBRProcessing:           ldcAccount.IsPendingXBRProcessing,
		LDCAccountId:                     ldcAccount.LDCAccountId,
		LDCAccountName:                   ldcAccount.LDCAccountName,
		LDCAcctAttn:                      ldcAccount.LDCAcctAttn,
		LDCAcctNo:                        ldcAccount.LDCAcctNo,
		LDCRateClass:                     ldcAccount.LDCRateClass,
		LDCRateCode:                      ldcAccount.LDCRateCode,
		MonthlyUsages:                    FromCoreMonthlyUsages(ldcAccount.MonthlyUsages),
		NewCharge:                        FromCoreTransaction(ldcAccount.NewCharge),
		NewCredit:                        FromCoreTransaction(ldcAccount.NewCredit),
		Nominations:                      FromCoreNominations(ldcAccount.Nominations),
		NonPassThruDomain:                ldcAccount.NonPassThruDomain,
		NotificationWaiverIndicator:      ldcAccount.NotificationWaiverIndicator,
		NumberOfMeters:                   ldcAccount.NumberOfMeters,
		OldLDCAcct1No:                    ldcAccount.OldLDCAcct1No,
		OldLDCAcct2No:                    ldcAccount.OldLDCAcct2No,
		OwnBuilding:                      ldcAccount.OwnBuilding,
		ParticipationPercent:             ldcAccount.ParticipationPercent,
		PrevInvoiceBalAm:                 ldcAccount.PrevInvoiceBalAm,
		PricePlans:                       FromCorePricePlans(ldcAccount.PricePlans),
		ProfitCenter:                     ldcAccount.ProfitCenter,
		ProfitMargin:                     ldcAccount.ProfitMargin,
		ProtectionRelates:                FromCoreProtectionRelates(ldcAccount.ProtectionRelates),
		ReadCycle:                        ldcAccount.ReadCycle,
		RenewableEnergy:                  ldcAccount.RenewableEnergy,
		SalesRep:                         ldcAccount.SalesRep,
		LDCAccountType:                   ldcAccount.LDCAccountType,
		SICCode:                          ldcAccount.SICCode,
		SquareFootage:                    ldcAccount.SquareFootage,
		StartDate:                        ldcAccount.StartDate,
		StartTime:                        ldcAccount.StartTime,
		Status:                           ldcAccount.Status,
		StatusHistReason:                 ldcAccount.StatusHistReason,
		StoreNumber:                      ldcAccount.StoreNumber,
		SysTimeStamp:                     ldcAccount.SysTimeStamp,
		TaxExemptPercent:                 ldcAccount.TaxExemptPercent,
		TemperatureZoneId:                ldcAccount.TemperatureZoneId,
		Term:                             ldcAccount.Term,
		TimeZone:                         ldcAccount.TimeZone,
		UtilityBudgetBill:                ldcAccount.UtilityBudgetBill,
		VendorDBNo:                       ldcAccount.VendorDBNo,
		VendorId:                         ldcAccount.VendorId,
		VendorName:                       ldcAccount.VendorName,
		Zone:                             ldcAccount.Zone,
	}
}

func FromCoreDepositEscrows(depositEscrows []coreEntities.DepositEscrow) []DepositEscrowResponse {
	if depositEscrows == nil {
		return nil
	}
	result := make([]DepositEscrowResponse, len(depositEscrows))
	for i, escrow := range depositEscrows {
		result[i] = *FromCoreDepositEscrow(&escrow)
	}
	return result
}

func FromCoreBudgetBillPlans(budgetBillPlans []coreEntities.BudgetBillPlan) []BudgetBillPlanResponse {
	if budgetBillPlans == nil {
		return nil
	}
	result := make([]BudgetBillPlanResponse, len(budgetBillPlans))
	for i, plan := range budgetBillPlans {
		result[i] = *FromCoreBudgetBillPlan(&plan)
	}
	return result
}

func FromCoreInteractions(interactions []coreEntities.Interaction) []InteractionResponse {
	if interactions == nil {
		return nil
	}
	result := make([]InteractionResponse, len(interactions))
	for i, interaction := range interactions {
		result[i] = *FromCoreInteraction(&interaction)
	}
	return result
}

func FromCoreInvoiceAdvices(invoiceAdvices []coreEntities.InvoiceAdvice) []InvoiceAdviceResponse {
	if invoiceAdvices == nil {
		return nil
	}
	result := make([]InvoiceAdviceResponse, len(invoiceAdvices))
	for i, advice := range invoiceAdvices {
		result[i] = *FromCoreInvoiceAdvice(&advice)
	}
	return result
}

func FromCoreMonthlyUsages(monthlyUsages []coreEntities.MonthlyUsage) []MonthlyUsageResponse {
	if monthlyUsages == nil {
		return nil
	}
	result := make([]MonthlyUsageResponse, len(monthlyUsages))
	for i, usage := range monthlyUsages {
		result[i] = *FromCoreMonthlyUsage(&usage)
	}
	return result
}

func FromCoreNominations(nominations []coreEntities.Nomination) []NominationResponse {
	if nominations == nil {
		return nil
	}
	result := make([]NominationResponse, len(nominations))
	for i, nom := range nominations {
		result[i] = *FromCoreNomination(&nom)
	}
	return result
}

func FromCorePricePlans(pricePlans []coreEntities.PricePlan) []PricePlanResponse {
	if pricePlans == nil {
		return nil
	}
	result := make([]PricePlanResponse, len(pricePlans))
	for i, plan := range pricePlans {
		result[i] = *FromCorePricePlan(&plan)
	}
	return result
}

func FromCoreProtectionRelates(protectionRelates []coreEntities.ProtectionRelate) []ProtectionRelateResponse {
	if protectionRelates == nil {
		return nil
	}
	result := make([]ProtectionRelateResponse, len(protectionRelates))
	for i, relate := range protectionRelates {
		result[i] = *FromCoreProtectionRelate(&relate)
	}
	return result
}
