package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type BudgetBillPlanResponse struct {
	BudgetBillAmount             float64                   `json:"budgetBillAmount"`
	CurrentPriceUsedInCalc       bool                      `json:"currentPriceUsedInCalc"`
	EndDate                      coreEntities.FlexibleTime `json:"endDate"`
	ExtBudgetBillAmount          float64                   `json:"extBudgetBillAmount"`
	ExtRolloverAmt               float64                   `json:"extRolloverAmt"`
	ExtSuggestedBudgetBillAmount float64                   `json:"extSuggestedBudgetBillAmount"`
	HasBeenCalculated            bool                      `json:"hasBeenCalculated"`
	IntBudgetBillAmount          float64                   `json:"intBudgetBillAmount"`
	IntRolloverAmt               float64                   `json:"intRolloverAmt"`
	IntSuggestedBudgetBillAmount float64                   `json:"intSuggestedBudgetBillAmount"`
	IsBudgetAmountAboveMin       bool                      `json:"isBudgetAmountAboveMin"`
	IsSuggestedValid             bool                      `json:"isSuggestedValid"`
	LastBudgetSetDate            coreEntities.FlexibleTime `json:"lastBudgetSetDate"`
	LastReconcileDate            coreEntities.FlexibleTime `json:"lastReconcileDate"`
	LastReviewDate               coreEntities.FlexibleTime `json:"lastReviewDate"`
	LDCAccountId                 uint64                    `json:"ldcAccountId"`
	MinimumAmount                float64                   `json:"minimumAmount"`
	MinimumQuantity              float64                   `json:"minimumQuantity"`
	NumUsageMonths               uint32                    `json:"numUsageMonths"`
	OriginalFlatAmount           float64                   `json:"originalFlatAmount"`
	OverrideCalculation          bool                      `json:"overrideCalculation"`
	Quantity                     float64                   `json:"quantity"`
	Renew                        string                    `json:"renew"`
	RenewBool                    bool                      `json:"renewBool"`
	RoundedAmountDifference      float64                   `json:"roundedAmountDifference"`
	SetReasonCode                string                    `json:"setReasonCode"`
	StartDate                    coreEntities.FlexibleTime `json:"startDate"`
	SuggestedBudgetBillAmount    float64                   `json:"suggestedBudgetBillAmount"`
	SuggestedQuantity            float64                   `json:"suggestedQuantity"`
	SuggestedUOM                 string                    `json:"suggestedUOM"`
	Total                        float64                   `json:"total"`
	TransitionAmount             float64                   `json:"transitionAmount"`
	TransitionDate               coreEntities.FlexibleTime `json:"transitionDate"`
	Type                         string                    `json:"type"`
	TypeDesc                     string                    `json:"typeDesc"`
	UOM                          string                    `json:"uom"`
	UserAmount                   float64                   `json:"userAmount"`
	VendorDBNo                   string                    `json:"vendorDBNo"`
	VendorId                     uint64                    `json:"vendorId"`
}

// FromCoreBudgetBillPlan converts a core BudgetBillPlan entity to a BudgetBillPlanResponse
func FromCoreBudgetBillPlan(plan *coreEntities.BudgetBillPlan) *BudgetBillPlanResponse {
	if plan == nil {
		return nil
	}
	return &BudgetBillPlanResponse{
		BudgetBillAmount:             plan.BudgetBillAmount,
		CurrentPriceUsedInCalc:       plan.CurrentPriceUsedInCalc,
		EndDate:                      plan.EndDate,
		ExtBudgetBillAmount:          plan.ExtBudgetBillAmount,
		ExtRolloverAmt:               plan.ExtRolloverAmt,
		ExtSuggestedBudgetBillAmount: plan.ExtSuggestedBudgetBillAmount,
		HasBeenCalculated:            plan.HasBeenCalculated,
		IntBudgetBillAmount:          plan.IntBudgetBillAmount,
		IntRolloverAmt:               plan.IntRolloverAmt,
		IntSuggestedBudgetBillAmount: plan.IntSuggestedBudgetBillAmount,
		IsBudgetAmountAboveMin:       plan.IsBudgetAmountAboveMin,
		IsSuggestedValid:             plan.IsSuggestedValid,
		LastBudgetSetDate:            plan.LastBudgetSetDate,
		LastReconcileDate:            plan.LastReconcileDate,
		LastReviewDate:               plan.LastReviewDate,
		LDCAccountId:                 plan.LDCAccountId,
		MinimumAmount:                plan.MinimumAmount,
		MinimumQuantity:              plan.MinimumQuantity,
		NumUsageMonths:               plan.NumUsageMonths,
		OriginalFlatAmount:           plan.OriginalFlatAmount,
		OverrideCalculation:          plan.OverrideCalculation,
		Quantity:                     plan.Quantity,
		Renew:                        plan.Renew,
		RenewBool:                    plan.RenewBool,
		RoundedAmountDifference:      plan.RoundedAmountDifference,
		SetReasonCode:                plan.SetReasonCode,
		StartDate:                    plan.StartDate,
		SuggestedBudgetBillAmount:    plan.SuggestedBudgetBillAmount,
		SuggestedQuantity:            plan.SuggestedQuantity,
		SuggestedUOM:                 plan.SuggestedUOM,
		Total:                        plan.Total,
		TransitionAmount:             plan.TransitionAmount,
		TransitionDate:               plan.TransitionDate,
		Type:                         plan.Type,
		TypeDesc:                     plan.TypeDesc,
		UOM:                          plan.UOM,
		UserAmount:                   plan.UserAmount,
		VendorDBNo:                   plan.VendorDBNo,
		VendorId:                     plan.VendorId,
	}
}
