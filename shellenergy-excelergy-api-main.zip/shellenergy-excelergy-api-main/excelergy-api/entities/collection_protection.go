package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type CollectionProtectionResponse struct {
	Active             bool   `json:"active"`
	ActiveIn           bool   `json:"activeIn"`
	Country            string `json:"country"`
	County             string `json:"county"`
	CustomerClassType  string `json:"customerClassType"`
	Duration           uint32 `json:"duration"`
	EBTInclude         bool   `json:"ebtInclude"`
	EndDate            string `json:"endDate"`
	Implied            bool   `json:"implied"`
	Name               string `json:"name"`
	ProtectionTypeCode string `json:"protectionTypeCode"`
	ServiceTypeCode    string `json:"serviceTypeCode"`
	StartDate          string `json:"startDate"`
	State              string `json:"state"`
	VendorDBNo         string `json:"vendorDBNo"`
	VendorId           uint64 `json:"vendorId"`
	VendorName         string `json:"vendorName"`
}

// FromCoreCollectionProtection converts a core CollectionProtection entity to a CollectionProtectionResponse
func FromCoreCollectionProtection(protection *coreEntities.CollectionProtection) *CollectionProtectionResponse {
	if protection == nil {
		return nil
	}
	return &CollectionProtectionResponse{
		Active:             protection.Active,
		ActiveIn:           protection.ActiveIn,
		Country:            protection.Country,
		County:             protection.County,
		CustomerClassType:  protection.CustomerClassType,
		Duration:           protection.Duration,
		EBTInclude:         protection.EBTInclude,
		EndDate:            protection.EndDate,
		Implied:            protection.Implied,
		Name:               protection.Name,
		ProtectionTypeCode: protection.ProtectionTypeCode,
		ServiceTypeCode:    protection.ServiceTypeCode,
		StartDate:          protection.StartDate,
		State:              protection.State,
		VendorDBNo:         protection.VendorDBNo,
		VendorId:           protection.VendorId,
		VendorName:         protection.VendorName,
	}
}
