package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type CancelledInfoResponse struct {
	Value           string `json:"value"`
	InCancel        string `json:"inCancel"`
	InOffset        string `json:"inOffset"`
	InOffsetAdj     string `json:"inOffsetAdj"`
	InBeenOffset    string `json:"inBeenOffset"`
	InBeenOffsetAdj string `json:"inBeenOffsetAdj"`
}

// FromCoreCancelledInfo converts a core CancelledInfo entity to a CancelledInfoResponse
func FromCoreCancelledInfo(info *coreEntities.CancelledInfo) *CancelledInfoResponse {
	if info == nil {
		return nil
	}
	return &CancelledInfoResponse{
		Value:           info.Value,
		InCancel:        info.InCancel,
		InOffset:        info.InOffset,
		InOffsetAdj:     info.InOffsetAdj,
		InBeenOffset:    info.InBeenOffset,
		InBeenOffsetAdj: info.InBeenOffsetAdj,
	}
}
