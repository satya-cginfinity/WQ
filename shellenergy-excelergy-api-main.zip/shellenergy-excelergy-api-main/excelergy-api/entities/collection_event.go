package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type CollectionEventResponse struct {
	CollectionScheduleId uint64                         `json:"collectionScheduleId"`
	DueAmount            float64                        `json:"dueAmount"`
	DueDays              float64                        `json:"dueDays"`
	EventAmount          float64                        `json:"eventAmount"`
	ExtractIn            bool                           `json:"extractIn"`
	FeeAmount            float64                        `json:"feeAmount"`
	FeeMaxAmount         float64                        `json:"feeMaxAmount"`
	FeeMinAmount         float64                        `json:"feeMinAmount"`
	FeePercent           float64                        `json:"feePercent"`
	FeePercentUI         float64                        `json:"feePercentUI"`
	FeeType              string                         `json:"feeType"`
	LateAmount           float64                        `json:"lateAmount"`
	Message              string                         `json:"message"`
	MessageOnInvoiceIn   bool                           `json:"messageOnInvoiceIn"`
	MinWaitDays          float64                        `json:"minWaitDays"`
	OrderNo              uint32                         `json:"orderNo"`
	ProtectionList       []CollectionProtectionResponse `json:"protectionList"`
	ProtectionString     string                         `json:"protectionString"`
	RepeatEveryDaysNo    uint32                         `json:"repeatEveryDaysNo"`
	SubType              string                         `json:"subType"`
	Type                 string                         `json:"type"`
}

// FromCoreCollectionEvent converts a core CollectionEvent entity to a CollectionEventResponse
func FromCoreCollectionEvent(event *coreEntities.CollectionEvent) *CollectionEventResponse {
	if event == nil {
		return nil
	}
	var protectionList []CollectionProtectionResponse
	if event.ProtectionList != nil {
		protectionList = make([]CollectionProtectionResponse, len(event.ProtectionList))
		for i, protection := range event.ProtectionList {
			protectionList[i] = *FromCoreCollectionProtection(&protection)
		}
	}

	return &CollectionEventResponse{
		CollectionScheduleId: event.CollectionScheduleId,
		DueAmount:            event.DueAmount,
		DueDays:              event.DueDays,
		EventAmount:          event.EventAmount,
		ExtractIn:            event.ExtractIn,
		FeeAmount:            event.FeeAmount,
		FeeMaxAmount:         event.FeeMaxAmount,
		FeeMinAmount:         event.FeeMinAmount,
		FeePercent:           event.FeePercent,
		FeePercentUI:         event.FeePercentUI,
		FeeType:              event.FeeType,
		LateAmount:           event.LateAmount,
		Message:              event.Message,
		MessageOnInvoiceIn:   event.MessageOnInvoiceIn,
		MinWaitDays:          event.MinWaitDays,
		OrderNo:              event.OrderNo,
		ProtectionList:       protectionList,
		ProtectionString:     event.ProtectionString,
		RepeatEveryDaysNo:    event.RepeatEveryDaysNo,
		SubType:              event.SubType,
		Type:                 event.Type,
	}
}
