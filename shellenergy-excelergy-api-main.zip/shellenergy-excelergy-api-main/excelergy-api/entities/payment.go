package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type PaymentResponse struct {
	TransactionId      uint64                 `json:"transactionId"`
	Date               string                 `json:"date"`
	Amount             float64                `json:"amount"`
	TransactionSubType string                 `json:"transactionSubType"`
	Cancelled          *CancelledInfoResponse `json:"cancelled"`
}

// FromCorePayment converts a core Payment entity to a PaymentResponse
func FromCorePayment(payment *coreEntities.Payment) *PaymentResponse {
	if payment == nil {
		return nil
	}
	return &PaymentResponse{
		TransactionId:      payment.TransactionId,
		Date:               payment.Date,
		Amount:             payment.Amount,
		TransactionSubType: payment.TransactionSubType,
		Cancelled:          FromCoreCancelledInfo(payment.Cancelled),
	}
}

// FromCorePayments converts a slice of core Payment pointers to PaymentResponse pointers
func FromCorePayments(payments []*coreEntities.Payment) []*PaymentResponse {
	if payments == nil {
		return nil
	}
	result := make([]*PaymentResponse, len(payments))
	for i, p := range payments {
		result[i] = FromCorePayment(p)
	}
	return result
}
