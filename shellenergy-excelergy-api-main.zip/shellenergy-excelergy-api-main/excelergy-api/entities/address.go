package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type AddressResponse struct {
	AddressID  uint64                   `json:"addressID"`
	City       string                   `json:"city"`
	Country    string                   `json:"country"`
	County     string                   `json:"county"`
	Line1      string                   `json:"line1"`
	Line2      string                   `json:"line2"`
	PostalCode string                   `json:"postalCode"`
	State      string                   `json:"state"`
	SysTmStamp coreEntities.FlexibleTime `json:"sysTmStamp"`
}

// FromCoreAddress converts a core Address entity to an AddressResponse
func FromCoreAddress(address *coreEntities.Address) *AddressResponse {
	if address == nil {
		return nil
	}
	return &AddressResponse{
		AddressID:  address.AddressID,
		City:       address.City,
		Country:    address.Country,
		County:     address.County,
		Line1:      address.Line1,
		Line2:      address.Line2,
		PostalCode: address.PostalCode,
		State:      address.State,
		SysTmStamp: address.SysTmStamp,
	}
}
