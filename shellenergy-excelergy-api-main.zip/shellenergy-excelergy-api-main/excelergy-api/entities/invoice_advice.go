package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type InvoiceAdviceResponse struct {
	ActualBudgetChargesAmount  float64                   `json:"actualBudgetChargesAmount"`
	BillMethod                 string                    `json:"billMethod"`
	BillMethodDesc             string                    `json:"billMethodDesc"`
	BudgetBillVarianceAmount   float64                   `json:"budgetBillVarianceAmount"`
	BudgetChargesAmount        float64                   `json:"budgetChargesAmount"`
	CancelIndicator            bool                      `json:"cancelIndicator"`
	ClassName                  string                    `json:"className"`
	DisplayCode                string                    `json:"displayCode"`
	DisplayName                string                    `json:"displayName"`
	DueDate                    coreEntities.FlexibleTime `json:"dueDate"`
	EDIReferenceNumber         string                    `json:"ediReferenceNumber"`
	EndDate                    coreEntities.FlexibleTime `json:"endDate"`
	EspVendorID                uint64                    `json:"espVendorID"`
	InvoicedIndicator          bool                      `json:"invoicedIndicator"`
	InvoiceId                  uint64                    `json:"invoiceId"`
	LateChargeAm               float64                   `json:"lateChargeAm"`
	LdcAccountId               uint64                    `json:"ldcAccountId"`
	NewFee                     float64                   `json:"newFee"`
	NewRatedChargesAm          float64                   `json:"newRatedChargesAm"`
	NewServiceChargesAm        float64                   `json:"newServiceChargesAm"`
	NewTaxesAm                 float64                   `json:"newTaxesAm"`
	OriginalEDIReferenceNumber string                    `json:"originalEDIReferenceNumber"`
	PaymentsReceivedAmount     float64                   `json:"paymentsReceivedAmount"`
	PrevBalAfterAdjAmount      float64                   `json:"prevBalAfterAdjAmount"`
	PrevBalDueAmount           float64                   `json:"prevBalDueAmount"`
	PreviousAmount             float64                   `json:"previousAmount"`
	Skip810867MatchIn          bool                      `json:"skip810867MatchIn"`
	StartDate                  coreEntities.FlexibleTime `json:"startDate"`
	TotalAdjAmount             float64                   `json:"totalAdjAmount"`
	TotalChargeCreditAmount    float64                   `json:"totalChargeCreditAmount"`
	TotalDueAmount             float64                   `json:"totalDueAmount"`
	TotalNewChargesAm          float64                   `json:"totalNewChargesAm"`
	XBRExcludeTaxesCode        string                    `json:"xbrExcludeTaxesCode"`
}

// FromCoreInvoiceAdvice converts a core InvoiceAdvice entity to an InvoiceAdviceResponse
func FromCoreInvoiceAdvice(invoiceAdvice *coreEntities.InvoiceAdvice) *InvoiceAdviceResponse {
	if invoiceAdvice == nil {
		return nil
	}
	return &InvoiceAdviceResponse{
		ActualBudgetChargesAmount:  invoiceAdvice.ActualBudgetChargesAmount,
		BillMethod:                 invoiceAdvice.BillMethod,
		BillMethodDesc:             invoiceAdvice.BillMethodDesc,
		BudgetBillVarianceAmount:   invoiceAdvice.BudgetBillVarianceAmount,
		BudgetChargesAmount:        invoiceAdvice.BudgetChargesAmount,
		CancelIndicator:            invoiceAdvice.CancelIndicator,
		ClassName:                  invoiceAdvice.ClassName,
		DisplayCode:                invoiceAdvice.DisplayCode,
		DisplayName:                invoiceAdvice.DisplayName,
		DueDate:                    invoiceAdvice.DueDate,
		EDIReferenceNumber:         invoiceAdvice.EDIReferenceNumber,
		EndDate:                    invoiceAdvice.EndDate,
		EspVendorID:                invoiceAdvice.EspVendorID,
		InvoicedIndicator:          invoiceAdvice.InvoicedIndicator,
		InvoiceId:                  invoiceAdvice.InvoiceId,
		LateChargeAm:               invoiceAdvice.LateChargeAm,
		LdcAccountId:               invoiceAdvice.LdcAccountId,
		NewFee:                     invoiceAdvice.NewFee,
		NewRatedChargesAm:          invoiceAdvice.NewRatedChargesAm,
		NewServiceChargesAm:        invoiceAdvice.NewServiceChargesAm,
		NewTaxesAm:                 invoiceAdvice.NewTaxesAm,
		OriginalEDIReferenceNumber: invoiceAdvice.OriginalEDIReferenceNumber,
		PaymentsReceivedAmount:     invoiceAdvice.PaymentsReceivedAmount,
		PrevBalAfterAdjAmount:      invoiceAdvice.PrevBalAfterAdjAmount,
		PrevBalDueAmount:           invoiceAdvice.PrevBalDueAmount,
		PreviousAmount:             invoiceAdvice.PreviousAmount,
		Skip810867MatchIn:          invoiceAdvice.Skip810867MatchIn,
		StartDate:                  invoiceAdvice.StartDate,
		TotalAdjAmount:             invoiceAdvice.TotalAdjAmount,
		TotalChargeCreditAmount:    invoiceAdvice.TotalChargeCreditAmount,
		TotalDueAmount:             invoiceAdvice.TotalDueAmount,
		TotalNewChargesAm:          invoiceAdvice.TotalNewChargesAm,
		XBRExcludeTaxesCode:        invoiceAdvice.XBRExcludeTaxesCode,
	}
}
