package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type PaymentArrangementResponse struct {
	AccountBalance    bool    `json:"accountBalance"`
	AcctId            uint64  `json:"acctId"`
	Amount            float64 `json:"amount"`
	ClosedDate        string  `json:"closedDate"`
	CreationDate      string  `json:"creationDate"`
	Duration          uint32  `json:"duration"`
	FirstPaymentDate  string  `json:"firstPaymentDate"`
	GoodwillApplies   bool    `json:"goodwillApplies"`
	Invoiced          bool    `json:"invoiced"`
	InvoiceLookupDate string  `json:"invoiceLookupDate"`
	IsGoodwillEnabled bool    `json:"isGoodwillEnabled"`
	LastPaymentDate   string  `json:"lastPaymentDate"`
	PaidAmount        float64 `json:"paidAmount"`
	PurposeCode       string  `json:"purposeCode"`
	ScheduleAmount    float64 `json:"scheduleAmount"`
	Status            string  `json:"status"`
	TypeCode          string  `json:"typeCode"`
}

// FromCorePaymentArrangements converts a slice of core PaymentArrangement entities to PaymentArrangementResponse items
func FromCorePaymentArrangements(paymentArrangements []coreEntities.PaymentArrangement) []PaymentArrangementResponse {
	if paymentArrangements == nil {
		return nil
	}

	result := make([]PaymentArrangementResponse, len(paymentArrangements))
	for i := range paymentArrangements {
		mapped := FromCorePaymentArrangement(&paymentArrangements[i])
		if mapped != nil {
			result[i] = *mapped
		}
	}

	return result
}

// FromCorePaymentArrangement converts a core PaymentArrangement entity to a PaymentArrangementResponse
func FromCorePaymentArrangement(paymentArrangement *coreEntities.PaymentArrangement) *PaymentArrangementResponse {
	if paymentArrangement == nil {
		return nil
	}
	return &PaymentArrangementResponse{
		AccountBalance:    paymentArrangement.AccountBalance,
		AcctId:            paymentArrangement.AcctId,
		Amount:            paymentArrangement.Amount,
		ClosedDate:        paymentArrangement.ClosedDate,
		CreationDate:      paymentArrangement.CreationDate,
		Duration:          paymentArrangement.Duration,
		FirstPaymentDate:  paymentArrangement.FirstPaymentDate,
		GoodwillApplies:   paymentArrangement.GoodwillApplies,
		Invoiced:          paymentArrangement.Invoiced,
		InvoiceLookupDate: paymentArrangement.InvoiceLookupDate,
		IsGoodwillEnabled: paymentArrangement.IsGoodwillEnabled,
		LastPaymentDate:   paymentArrangement.LastPaymentDate,
		PaidAmount:        paymentArrangement.PaidAmount,
		PurposeCode:       paymentArrangement.PurposeCode,
		ScheduleAmount:    paymentArrangement.ScheduleAmount,
		Status:            paymentArrangement.Status,
		TypeCode:          paymentArrangement.TypeCode,
	}
}
