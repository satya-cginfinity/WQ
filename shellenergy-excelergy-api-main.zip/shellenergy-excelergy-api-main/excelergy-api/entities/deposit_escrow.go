package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type DepositEscrowResponse struct {
	Amount                          float64 `json:"amount"`
	Balance                         float64 `json:"balance"`
	ClosedDate                      string  `json:"closedDate"`
	CreationDate                    string  `json:"creationDate"`
	DepositAmountMaxFormattedLength uint32  `json:"depositAmountMaxFormattedLength"`
	DepositEscrowRuleName           string  `json:"depositEscrowRuleName"`
	DepositId                       uint64  `json:"depositId"`
	DisplayCode                     string  `json:"displayCode"`
	DisplayName                     string  `json:"displayName"`
	LastCalcdate                    string  `json:"lastCalcdate"`
	RelateClassName                 string  `json:"relateClassName"`
	RelateId                        uint64  `json:"relateId"`
	ReviewDate                      string  `json:"reviewDate"`
	RuleId                          uint64  `json:"ruleId"`
	ServiceTypeCode                 string  `json:"serviceTypeCode"`
	ServiceTypeCodeShortDesc        string  `json:"serviceTypeCodeShortDesc"`
	StartDate                       string  `json:"startDate"`
	TotalInterest                   float64 `json:"totalInterest"`
}

// FromCoreDepositEscrow converts a core DepositEscrow entity to a DepositEscrowResponse
func FromCoreDepositEscrow(depositEscrow *coreEntities.DepositEscrow) *DepositEscrowResponse {
	if depositEscrow == nil {
		return nil
	}
	return &DepositEscrowResponse{
		Amount:                          depositEscrow.Amount,
		Balance:                         depositEscrow.Balance,
		ClosedDate:                      depositEscrow.ClosedDate,
		CreationDate:                    depositEscrow.CreationDate,
		DepositAmountMaxFormattedLength: depositEscrow.DepositAmountMaxFormattedLength,
		DepositEscrowRuleName:           depositEscrow.DepositEscrowRuleName,
		DepositId:                       depositEscrow.DepositId,
		DisplayCode:                     depositEscrow.DisplayCode,
		DisplayName:                     depositEscrow.DisplayName,
		LastCalcdate:                    depositEscrow.LastCalcdate,
		RelateClassName:                 depositEscrow.RelateClassName,
		RelateId:                        depositEscrow.RelateId,
		ReviewDate:                      depositEscrow.ReviewDate,
		RuleId:                          depositEscrow.RuleId,
		ServiceTypeCode:                 depositEscrow.ServiceTypeCode,
		ServiceTypeCodeShortDesc:        depositEscrow.ServiceTypeCodeShortDesc,
		StartDate:                       depositEscrow.StartDate,
		TotalInterest:                   depositEscrow.TotalInterest,
	}
}
