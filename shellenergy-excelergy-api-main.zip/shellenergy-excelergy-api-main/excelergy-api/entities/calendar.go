package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type CalendarResponse struct {
	CalendarId   uint64 `json:"calendarId"`
	TypeCode     string `json:"typeCode"`
	Default      bool   `json:"default"`
	Description  string `json:"description"`
	CalendarCode string `json:"calendarCode"`
}

// FromCoreCalendar converts a core Calendar entity to a CalendarResponse
func FromCoreCalendar(calendar *coreEntities.Calendar) *CalendarResponse {
	if calendar == nil {
		return nil
	}
	return &CalendarResponse{
		CalendarId:   calendar.CalendarId,
		TypeCode:     calendar.TypeCode,
		Default:      calendar.Default,
		Description:  calendar.Description,
		CalendarCode: calendar.CalendarCode,
	}
}
