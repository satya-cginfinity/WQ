package entities

import coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"

type AccountCriteriaRequest struct {
	SEPADirectDebitStatuses      []string `json:"sepaDirectDebitStatuses"`
	SEPAMaxMandateExpiration     *string  `json:"sepaMaxMandateExpiration"`
	SEPAMandateReference         *string  `json:"sepaMandateReference"`
	SearchOrderByIDInclusive     *bool    `json:"searchOrderByIdInclusive"`
	SearchOrderByID              *bool    `json:"searchOrderById"`
	SearchLimit                  *int     `json:"searchLimit"`
	SearchAccountsPreviousOrNext *bool    `json:"searchAccountsPreviousOrNext"`
	AccountWithActiveLDCs        *bool    `json:"accountWithActiveLDCs"`
	AccountNumber                *string  `json:"accountNumber"`
	AccountID                    *uint64  `json:"accountId"`
	AcctCreditBalance            *float64 `json:"acctCreditBalance"`
	AccountActiveIndicator       *bool    `json:"accountActiveIndicator"`
	DirectDebitEnabled           *bool    `json:"directDebitEnabled"`
	AccountACHEnabled            *bool    `json:"accountACHEnabled"`
}

func (criteria *AccountCriteriaRequest) ToCoreAccountCriteria() *coreEntities.AccountCriteria {
	if criteria == nil {
		return nil
	}

	return &coreEntities.AccountCriteria{
		SEPADirectDebitStatuses:      criteria.SEPADirectDebitStatuses,
		SEPAMaxMandateExpiration:     criteria.SEPAMaxMandateExpiration,
		SEPAMandateReference:         criteria.SEPAMandateReference,
		SearchOrderByIDInclusive:     criteria.SearchOrderByIDInclusive,
		SearchOrderByID:              criteria.SearchOrderByID,
		SearchLimit:                  criteria.SearchLimit,
		SearchAccountsPreviousOrNext: criteria.SearchAccountsPreviousOrNext,
		AccountWithActiveLDCs:        criteria.AccountWithActiveLDCs,
		AccountNumber:                criteria.AccountNumber,
		AccountID:                    criteria.AccountID,
		AcctCreditBalance:            criteria.AcctCreditBalance,
		AccountActiveIndicator:       criteria.AccountActiveIndicator,
		DirectDebitEnabled:           criteria.DirectDebitEnabled,
		AccountACHEnabled:            criteria.AccountACHEnabled,
	}
}
