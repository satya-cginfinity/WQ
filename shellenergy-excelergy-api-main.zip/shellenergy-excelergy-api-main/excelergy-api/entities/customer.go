package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type CustomerResponse struct {
	Accounts              []AccountResponse         `json:"accounts"`
	ClassName             string                    `json:"className"`
	CoOrLastName          string                    `json:"coOrLastName"`
	CreditLimit           float64                   `json:"creditLimit"`
	CreditRisk            string                    `json:"creditRisk"`
	CreditScore           string                    `json:"creditScore"`
	CreditScoreDate       coreEntities.FlexibleTime `json:"creditScoreDate"`
	CreditScoreSource     string                    `json:"creditScoreSource"`
	CustomerClassType     string                    `json:"customerClassType"`
	CustomerId            uint64                    `json:"customerId"`
	DisplayCode           string                    `json:"displayCode"`
	DisplayName           string                    `json:"displayName"`
	DisplayNameByLastName string                    `json:"displayNameByLastName"`
	DunBradNum            string                    `json:"dunBradNum"`
	FirstName             string                    `json:"firstName"`
	Interactions          []InteractionResponse     `json:"interactions"`
	InternalCreditScore   string                    `json:"internalCreditScore"`
	IsResidential         bool                      `json:"isResidential"`
	MiddleName            string                    `json:"middleName"`
	Phone                 string                    `json:"phone"`
	PhoneNumberRaw        string                    `json:"phoneNumberRaw"`
	Prefix                string                    `json:"prefix"`
	Suffix                string                    `json:"suffix"`
	UnlistedPhoneNum      bool                      `json:"unlistedPhoneNum"`
	UpperCoOrLastName     string                    `json:"upperCoOrLastName"`
}

// FromCoreCustomer converts a core Customer entity to a CustomerResponse
func FromCoreCustomer(customer *coreEntities.Customer) *CustomerResponse {
	if customer == nil {
		return nil
	}
	return &CustomerResponse{
		Accounts:              FromCoreAccounts(customer.Accounts),
		ClassName:             customer.ClassName,
		CoOrLastName:          customer.CoOrLastName,
		CreditLimit:           customer.CreditLimit,
		CreditRisk:            customer.CreditRisk,
		CreditScore:           customer.CreditScore,
		CreditScoreDate:       customer.CreditScoreDate,
		CreditScoreSource:     customer.CreditScoreSource,
		CustomerClassType:     customer.CustomerClassType,
		CustomerId:            customer.CustomerId,
		DisplayCode:           customer.DisplayCode,
		DisplayName:           customer.DisplayName,
		DisplayNameByLastName: customer.DisplayNameByLastName,
		DunBradNum:            customer.DunBradNum,
		FirstName:             customer.FirstName,
		Interactions:          convertInteractions(customer.Interactions),
		InternalCreditScore:   customer.InternalCreditScore,
		IsResidential:         customer.IsResidential,
		MiddleName:            customer.MiddleName,
		Phone:                 customer.Phone,
		PhoneNumberRaw:        customer.PhoneNumberRaw,
		Prefix:                customer.Prefix,
		Suffix:                customer.Suffix,
		UnlistedPhoneNum:      customer.UnlistedPhoneNum,
		UpperCoOrLastName:     customer.UpperCoOrLastName,
	}
}
