package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type InvoiceResponse struct {
	AccountId                               uint64                        `json:"accountId"`
	ActualChargesAmount                     float64                       `json:"actualChargesAmount"`
	ActualChargesBbPlanToDateAmount         float64                       `json:"actualChargesBbPlanToDateAmount"`
	ActualNonBudgetChargesAmountPlanToDate  float64                       `json:"actualNonBudgetChargesAmountPlanToDate"`
	AppliedPaymentCreditAmount              float64                       `json:"appliedPaymentCreditAmount"`
	AppliedPaymentsAmountPlanToDate         float64                       `json:"appliedPaymentsAmountPlanToDate"`
	BudgetBillChargesAmount                 float64                       `json:"budgetBillChargesAmount"`
	BudgetBillChargesBbPaidPlanToDateAmount float64                       `json:"budgetBillChargesBbPaidPlanToDateAmount"`
	BudgetBillChargesBbPlanToDateAmount     float64                       `json:"budgetBillChargesBbPlanToDateAmount"`
	BudgetBillVarianceAmount                float64                       `json:"budgetBillVarianceAmount"`
	BudgetBillVarianceBbPlanToDateAmount    float64                       `json:"budgetBillVarianceBbPlanToDateAmount"`
	CancelIndicator                         bool                          `json:"cancelIndicator"`
	ClassName                               string                        `json:"className"`
	CollectionEventQue                      *CollectionEventQueueResponse `json:"collectionEventQue"`
	CollectionHoldEndDate                   string                        `json:"collectionHoldEndDate"`
	CollectionHoldStartDate                 string                        `json:"collectionHoldStartDate"`
	CollectionHoldTyCd                      string                        `json:"collectionHoldTyCd"`
	CollectionSched                         *CollectionScheduleResponse   `json:"collectionSched"`
	CollectionScheduleId                    uint64                        `json:"collectionScheduleId"`
	DisplayCode                             string                        `json:"displayCode"`
	DisplayName                             string                        `json:"displayName"`
	DueDate                                 string                        `json:"dueDate"`
	EndDate                                 string                        `json:"endDate"`
	InvoiceCreationDate                     string                        `json:"invoiceCreationDate"`
	InvoiceId                               uint64                        `json:"invoiceId"`
	InvoiceName                             string                        `json:"invoiceName"`
	InvoiceNumber                           string                        `json:"invoiceNumber"`
	InvoiceNumberDisplay                    string                        `json:"invoiceNumberDisplay"`
	IsOnHoldStatus                          bool                          `json:"isOnHoldStatus"`
	LastCollectionEventQueueDate            string                        `json:"lastCollectionEventQueueDate"`
	LastCollectionEventQueueID              uint64                        `json:"lastCollectionEventQueueID"`
	LastCollectionEventQueueName            string                        `json:"lastCollectionEventQueueName"`
	LastEventDisplayName                    string                        `json:"lastEventDisplayName"`
	LateChargeAm                            float64                       `json:"lateChargeAm"`
	NewFee                                  float64                       `json:"newFee"`
	NewRatedChargesAm                       float64                       `json:"newRatedChargesAm"`
	NewServiceChargesAm                     float64                       `json:"newServiceChargesAm"`
	NewTaxesAm                              float64                       `json:"newTaxesAm"`
	NextCollectionEventQueueDate            string                        `json:"nextCollectionEventQueueDate"`
	NextCollectionEventQueueID              uint64                        `json:"nextCollectionEventQueueID"`
	NextCollectionEventQueueName            string                        `json:"nextCollectionEventQueueName"`
	NonBudgetBillChargesBbPlanToDateAmount  float64                       `json:"nonBudgetBillChargesBbPlanToDateAmount"`
	OutstandingAmount                       float64                       `json:"outstandingAmount"`
	PaymentsReceivedAmount                  float64                       `json:"paymentsReceivedAmount"`
	PrevBalAfterAdjAmount                   float64                       `json:"prevBalAfterAdjAmount"`
	PrevBalDueAmount                        float64                       `json:"prevBalDueAmount"`
	PreviousAmount                          float64                       `json:"previousAmount"`
	PreviousInvoiceDate                     string                        `json:"previousInvoiceDate"`
	RestrictWebView                         bool                          `json:"restrictWebView"`
	SpecialHandlingCD                       string                        `json:"specialHandlingCD"`
	StartDate                               string                        `json:"startDate"`
	TotalActualChargesAmountPlanToDate      float64                       `json:"totalActualChargesAmountPlanToDate"`
	TotalAdjAmount                          float64                       `json:"totalAdjAmount"`
	TotalBillChargesBbPlanToDateAmount      float64                       `json:"totalBillChargesBbPlanToDateAmount"`
	TotalChargeAmount                       float64                       `json:"totalChargeAmount"`
	TotalChargeCreditAmount                 float64                       `json:"totalChargeCreditAmount"`
	TotalDueAmount                          float64                       `json:"totalDueAmount"`
	TotalIncurredFee                        float64                       `json:"totalIncurredFee"`
	TotalNewChargesAmount                   float64                       `json:"totalNewChargesAmount"`
	VarianceOverBilled                      float64                       `json:"varianceOverBilled"`
	VarianceUnderBilled                     float64                       `json:"varianceUnderBilled"`
}

// FromCoreInvoice converts a core Invoice entity to an InvoiceResponse
func FromCoreInvoice(invoice *coreEntities.Invoice) *InvoiceResponse {
	if invoice == nil {
		return nil
	}
	return &InvoiceResponse{
		AccountId:                               invoice.AccountId,
		ActualChargesAmount:                     invoice.ActualChargesAmount,
		ActualChargesBbPlanToDateAmount:         invoice.ActualChargesBbPlanToDateAmount,
		ActualNonBudgetChargesAmountPlanToDate:  invoice.ActualNonBudgetChargesAmountPlanToDate,
		AppliedPaymentCreditAmount:              invoice.AppliedPaymentCreditAmount,
		AppliedPaymentsAmountPlanToDate:         invoice.AppliedPaymentsAmountPlanToDate,
		BudgetBillChargesAmount:                 invoice.BudgetBillChargesAmount,
		BudgetBillChargesBbPaidPlanToDateAmount: invoice.BudgetBillChargesBbPaidPlanToDateAmount,
		BudgetBillChargesBbPlanToDateAmount:     invoice.BudgetBillChargesBbPlanToDateAmount,
		BudgetBillVarianceAmount:                invoice.BudgetBillVarianceAmount,
		BudgetBillVarianceBbPlanToDateAmount:    invoice.BudgetBillVarianceBbPlanToDateAmount,
		CancelIndicator:                         invoice.CancelIndicator,
		ClassName:                               invoice.ClassName,
		CollectionEventQue:                      FromCoreCollectionEventQueue(invoice.CollectionEventQue),
		CollectionHoldEndDate:                   invoice.CollectionHoldEndDate,
		CollectionHoldStartDate:                 invoice.CollectionHoldStartDate,
		CollectionHoldTyCd:                      invoice.CollectionHoldTyCd,
		CollectionSched:                         FromCoreCollectionSchedule(invoice.CollectionSched),
		CollectionScheduleId:                    invoice.CollectionScheduleId,
		DisplayCode:                             invoice.DisplayCode,
		DisplayName:                             invoice.DisplayName,
		DueDate:                                 invoice.DueDate,
		EndDate:                                 invoice.EndDate,
		InvoiceCreationDate:                     invoice.InvoiceCreationDate,
		InvoiceId:                               invoice.InvoiceId,
		InvoiceName:                             invoice.InvoiceName,
		InvoiceNumber:                           invoice.InvoiceNumber,
		InvoiceNumberDisplay:                    invoice.InvoiceNumberDisplay,
		IsOnHoldStatus:                          invoice.IsOnHoldStatus,
		LastCollectionEventQueueDate:            invoice.LastCollectionEventQueueDate,
		LastCollectionEventQueueID:              invoice.LastCollectionEventQueueID,
		LastCollectionEventQueueName:            invoice.LastCollectionEventQueueName,
		LastEventDisplayName:                    invoice.LastEventDisplayName,
		LateChargeAm:                            invoice.LateChargeAm,
		NewFee:                                  invoice.NewFee,
		NewRatedChargesAm:                       invoice.NewRatedChargesAm,
		NewServiceChargesAm:                     invoice.NewServiceChargesAm,
		NewTaxesAm:                              invoice.NewTaxesAm,
		NextCollectionEventQueueDate:            invoice.NextCollectionEventQueueDate,
		NextCollectionEventQueueID:              invoice.NextCollectionEventQueueID,
		NextCollectionEventQueueName:            invoice.NextCollectionEventQueueName,
		NonBudgetBillChargesBbPlanToDateAmount:  invoice.NonBudgetBillChargesBbPlanToDateAmount,
		OutstandingAmount:                       invoice.OutstandingAmount,
		PaymentsReceivedAmount:                  invoice.PaymentsReceivedAmount,
		PrevBalAfterAdjAmount:                   invoice.PrevBalAfterAdjAmount,
		PrevBalDueAmount:                        invoice.PrevBalDueAmount,
		PreviousAmount:                          invoice.PreviousAmount,
		PreviousInvoiceDate:                     invoice.PreviousInvoiceDate,
		RestrictWebView:                         invoice.RestrictWebView,
		SpecialHandlingCD:                       invoice.SpecialHandlingCD,
		StartDate:                               invoice.StartDate,
		TotalActualChargesAmountPlanToDate:      invoice.TotalActualChargesAmountPlanToDate,
		TotalAdjAmount:                          invoice.TotalAdjAmount,
		TotalBillChargesBbPlanToDateAmount:      invoice.TotalBillChargesBbPlanToDateAmount,
		TotalChargeAmount:                       invoice.TotalChargeAmount,
		TotalChargeCreditAmount:                 invoice.TotalChargeCreditAmount,
		TotalDueAmount:                          invoice.TotalDueAmount,
		TotalIncurredFee:                        invoice.TotalIncurredFee,
		TotalNewChargesAmount:                   invoice.TotalNewChargesAmount,
		VarianceOverBilled:                      invoice.VarianceOverBilled,
		VarianceUnderBilled:                     invoice.VarianceUnderBilled,
	}
}
