package entities

import coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"

type ReferenceAttributeResponse struct {
	Attribute string `json:"attribute"`
	Code      string `json:"code"`
	Domain    string `json:"domain"`
	IsDirty   bool   `json:"isDirty"`
	Value     string `json:"value"`
}

// FromCoreReferenceAttribute converts a core ReferenceAttribute entity to a ReferenceAttributeResponse
func FromCoreReferenceAttribute(attribute *coreEntities.ReferenceAttribute) *ReferenceAttributeResponse {
	if attribute == nil {
		return nil
	}
	return &ReferenceAttributeResponse{
		Attribute: attribute.Attribute,
		Code:      attribute.Code,
		Domain:    attribute.Domain,
		IsDirty:   attribute.IsDirty,
		Value:     attribute.Value,
	}
}
