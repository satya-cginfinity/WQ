package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type NominationResponse struct {
	DisplayCode   string                    `json:"displayCode"`
	DisplayName   string                    `json:"displayName"`
	EndDate       coreEntities.FlexibleTime `json:"endDate"`
	NomId         uint64                    `json:"nomId"`
	QuantityNo    float64                   `json:"quantityNo"`
	StartDate     coreEntities.FlexibleTime `json:"startDate"`
	UnitOfMeasure string                    `json:"unitOfMeasure"`
}

// FromCoreNomination converts a core Nomination entity to a NominationResponse
func FromCoreNomination(nomination *coreEntities.Nomination) *NominationResponse {
	if nomination == nil {
		return nil
	}
	return &NominationResponse{
		DisplayCode:   nomination.DisplayCode,
		DisplayName:   nomination.DisplayName,
		EndDate:       nomination.EndDate,
		NomId:         nomination.NomId,
		QuantityNo:    nomination.QuantityNo,
		StartDate:     nomination.StartDate,
		UnitOfMeasure: nomination.UnitOfMeasure,
	}
}
