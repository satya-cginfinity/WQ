package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type ReferenceCodeResponse struct {
	Code                string                       `json:"code"`
	Default             bool                         `json:"default"`
	DisplayCode         string                       `json:"displayCode"`
	DisplayName         string                       `json:"displayName"`
	DomainName          string                       `json:"domainName"`
	EDICode             string                       `json:"ediCode"`
	IsActive            bool                         `json:"isActive"`
	IsChecked           bool                         `json:"isChecked"`
	LongDescription     string                       `json:"longDescription"`
	MixedCase           bool                         `json:"mixedCase"`
	ReferenceAttributes []ReferenceAttributeResponse `json:"referenceAttributes"`
	ShortDescription    string                       `json:"shortDescription"`
	XMLCode             string                       `json:"xmlCode"`
}

// FromCoreReferenceAttributes converts a slice of core ReferenceAttribute entities to ReferenceAttributeResponse
func FromCoreReferenceAttributes(attributes []coreEntities.ReferenceAttribute) []ReferenceAttributeResponse {
	if attributes == nil {
		return []ReferenceAttributeResponse{}
	}
	result := make([]ReferenceAttributeResponse, len(attributes))
	for i, attr := range attributes {
		result[i] = *FromCoreReferenceAttribute(&attr)
	}
	return result
}

// FromCoreReferenceCodes converts a slice of core ReferenceCode entities to a slice of ReferenceCodeResponse
func FromCoreReferenceCodes(referenceCodes []coreEntities.ReferenceCode) []interface{} {
	if referenceCodes == nil {
		return []interface{}{}
	}
	result := make([]interface{}, len(referenceCodes))
	for i := range referenceCodes {
		result[i] = FromCoreReferenceCode(&referenceCodes[i])
	}
	return result
}

// FromCoreReferenceCode converts a core ReferenceCode entity to a ReferenceCodeResponse
func FromCoreReferenceCode(referenceCode *coreEntities.ReferenceCode) *ReferenceCodeResponse {
	if referenceCode == nil {
		return nil
	}
	return &ReferenceCodeResponse{
		Code:                referenceCode.Code,
		Default:             referenceCode.Default,
		DisplayCode:         referenceCode.DisplayCode,
		DisplayName:         referenceCode.DisplayName,
		DomainName:          referenceCode.DomainName,
		EDICode:             referenceCode.EDICode,
		IsActive:            referenceCode.IsActive,
		IsChecked:           referenceCode.IsChecked,
		LongDescription:     referenceCode.LongDescription,
		MixedCase:           referenceCode.MixedCase,
		ReferenceAttributes: FromCoreReferenceAttributes(referenceCode.ReferenceAttributes),
		ShortDescription:    referenceCode.ShortDescription,
		XMLCode:             referenceCode.XMLCode,
	}
}
