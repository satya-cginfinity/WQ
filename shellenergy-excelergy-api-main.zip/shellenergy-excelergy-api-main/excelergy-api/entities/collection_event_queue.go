package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type CollectionEventQueueResponse struct {
	DisplayCode                  string `json:"displayCode"`
	DisplayName                  string `json:"displayName"`
	EstimatedDropDate            string `json:"estimatedDropDate"`
	LastCollectionEventQueueDate string `json:"lastCollectionEventQueueDate"`
	LastCollectionEventQueueID   uint64 `json:"lastCollectionEventQueueID"`
	LastCollectionEventQueueName string `json:"lastCollectionEventQueueName"`
	NextCollectionEventQueueDate string `json:"nextCollectionEventQueueDate"`
	NextCollectionEventQueueID   uint64 `json:"nextCollectionEventQueueID"`
	NextCollectionEventQueueName string `json:"nextCollectionEventQueueName"`
}

// FromCoreCollectionEventQueue converts a core CollectionEventQueue entity to a CollectionEventQueueResponse
func FromCoreCollectionEventQueue(queue *coreEntities.CollectionEventQueue) *CollectionEventQueueResponse {
	if queue == nil {
		return nil
	}
	return &CollectionEventQueueResponse{
		DisplayCode:                  queue.DisplayCode,
		DisplayName:                  queue.DisplayName,
		EstimatedDropDate:            queue.EstimatedDropDate,
		LastCollectionEventQueueDate: queue.LastCollectionEventQueueDate,
		LastCollectionEventQueueID:   queue.LastCollectionEventQueueID,
		LastCollectionEventQueueName: queue.LastCollectionEventQueueName,
		NextCollectionEventQueueDate: queue.NextCollectionEventQueueDate,
		NextCollectionEventQueueID:   queue.NextCollectionEventQueueID,
		NextCollectionEventQueueName: queue.NextCollectionEventQueueName,
	}
}
