package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type AccountResponse struct {
	ActiveIn                      bool                              `json:"activeIn"`
	AccountBalance                *float64                          `json:"accountBalance"`
	AccountId                     uint64                            `json:"accountId"`
	AccountNo                     string                            `json:"accountNo"`
	AccountNoSeq                  string                            `json:"accountNoSeq"`
	ACHDebitDayofMonth            uint32                            `json:"achDebitDayofMonth"`
	ACHDirectDebitStatus          string                            `json:"achDirectDebitStatus"`
	ACHRequestDateCalcCode        string                            `json:"achRequestDateCalcCode"`
	ACHStatusDate                 string                            `json:"achStatusDate"`
	AlertNote                     string                            `json:"alertNote"`
	BankABA                       string                            `json:"bankABA"`
	BankAcctId                    string                            `json:"bankAcctId"`
	BankAcctType                  string                            `json:"bankAcctType"`
	BankAuthCode                  string                            `json:"bankAuthCode"`
	BankAuthDate                  string                            `json:"bankAuthDate"`
	BankCustomerName              string                            `json:"bankCustomerName"`
	BankName                      string                            `json:"bankName"`
	BankTransitId                 string                            `json:"bankTransitId"`
	BudgetBillStatus              string                            `json:"budgetBillStatus"`
	CalculatedBalance             float64                           `json:"calculatedBalance"`
	CCExpireDate                  string                            `json:"ccExpireDate"`
	CCName                        string                            `json:"ccName"`
	CCNo                          string                            `json:"ccNo"`
	CCSuspendDate                 string                            `json:"ccSuspendDate"`
	CCTypeCode                    string                            `json:"ccTypeCode"`
	CCTypeCodeDesc                string                            `json:"ccTypeCodeDesc"`
	ClassName                     string                            `json:"className"`
	ContainsBudgetBillLdcAccounts bool                              `json:"containsBudgetBillLdcAccounts"`
	CurrentUsage                  bool                              `json:"currentUsage"`
	Creation                      string                            `json:"creation"`
	CreationDate                  string                            `json:"creationDate"`
	CreditBalance                 float64                           `json:"creditBalance"`
	CreditandCollectionRuleName   string                            `json:"creditandCollectionRuleName"`
	CreditCollectionRuleId        uint64                            `json:"creditCollectionRuleId"`
	CreditCollectRule             *CreditCollectionRuleResponse     `json:"creditCollectRule"`
	CustomerClassType             string                            `json:"customerClassType"`
	CustomerId                    uint64                            `json:"customerId"`
	DepositEscrows                []DepositEscrowResponse           `json:"depositEscrows"`
	DisplayCode                   string                            `json:"displayCode"`
	DisplayName                   string                            `json:"displayName"`
	Do810867MatchIn               bool                              `json:"do810867MatchIn"`
	EstimationWaitPer             float64                           `json:"estimationWaitPer"`
	EventLDCAcctId                uint64                            `json:"eventLdcAcctId"`
	FirstName                     string                            `json:"firstName"`
	Interactions                  []InteractionResponse             `json:"interactions"`
	InvDistInfos                  []InvoiceDistributionInfoResponse `json:"invDistInfos"`
	InvoiceAdviceRequirement      string                            `json:"invoiceAdviceRequirement"`
	InvoiceHold                   bool                              `json:"invoiceHold"`
	InvoiceCreationEventRule      string                            `json:"invoiceCreationEventRule"`
	InvoiceMessage                string                            `json:"invoiceMessage"`
	InvoiceQueueStatusDescription string                            `json:"invoiceQueueStatusDescription"`
	InvoiceCycle                  uint32                            `json:"invoiceCycle"`
	Invoices                      []InvoiceResponse                 `json:"invoices"`
	IsACHDirectDebit              bool                              `json:"isAchDirectDebit"`
	IsDirectCreditStatusActive    bool                              `json:"isDirectCreditStatusActive"`
	IsOnPaymentArrangement        bool                              `json:"isOnPaymentArrangement"`
	IsSEPADirectDebit             bool                              `json:"isSepaDirectDebit"`
	LdcAccounts                   []LdcAccountResponse              `json:"ldcAccounts"`
	LastName                      string                            `json:"lastName"`
	LPCSuspendDate                string                            `json:"lpcSuspendDate"`
	MiddleName                    string                            `json:"middleName"`
	Name                          string                            `json:"name"`
	NewCharge                     *TransactionResponse              `json:"newCharge"`
	NewCredit                     *TransactionResponse              `json:"newCredit"`
	NextInvoiceDate               string                            `json:"nextInvoiceDate"`
	NumberOfLDCAccounts           uint32                            `json:"numberOfLdcAccounts"`
	PhoneNo                       string                            `json:"phoneNo"`
	PreviousInvoiceDate           string                            `json:"previousInvoiceDate"`
	PreviousInvoiceDueDate        string                            `json:"previousInvoiceDueDate"`
	PrevInvoiceBalAm              float64                           `json:"prevInvoiceBalAm"`
	PricePlans                    []PricePlanResponse               `json:"pricePlans"`
	SEPADirectDebitStatus         string                            `json:"sepaDirectDebitStatus"`
	SEPADaysOverride              bool                              `json:"sepaDaysOverride"`
	SEPAFirstDays                 uint32                            `json:"sepaFirstDays"`
	SEPAMandateExpiration         string                            `json:"sepaMandateExpiration"`
	SEPAMandateReference          string                            `json:"sepaMandateReference"`
	SEPAMandateSignature          string                            `json:"sepaMandateSignature"`
	SEPARecurrentDays             uint32                            `json:"sepaRecurrentDays"`
	SpecialHandling               string                            `json:"specialHandling"`
	SuspendCC                     bool                              `json:"suspendCC"`
	SuspendLPC                    bool                              `json:"suspendLPC"`
	TaxID                         string                            `json:"taxID"`
	TaxIDState                    string                            `json:"taxIDState"`
	Transactions                  []TransactionResponse             `json:"transactions"`
	VendorAliasDbNumber           string                            `json:"vendorAliasDbNumber"`
	VendorAliasName               string                            `json:"vendorAliasName"`
	VendorBank                    string                            `json:"vendorBank"`
	VendorDBNo                    string                            `json:"vendorDBNo"`
	VendorDisplayDBNumber         string                            `json:"vendorDisplayDBNumber"`
	VendorDisplayName             string                            `json:"vendorDisplayName"`
	VendorId                      uint64                            `json:"vendorId"`
}

// FromCoreAccounts converts a slice of core Account entities to AccountResponse items
func FromCoreAccounts(accounts []coreEntities.Account) []AccountResponse {
	if accounts == nil {
		return nil
	}

	result := make([]AccountResponse, len(accounts))
	for i := range accounts {
		mapped := FromCoreAccount(&accounts[i])
		if mapped != nil {
			result[i] = *mapped
		}
	}

	return result
}

func convertTransactions(transactions []coreEntities.Transaction) []TransactionResponse {
	if transactions == nil {
		return nil
	}
	result := make([]TransactionResponse, len(transactions))
	for i, t := range transactions {
		result[i] = *FromCoreTransaction(&t)
	}
	return result
}

func convertDepositEscrows(escrows []coreEntities.DepositEscrow) []DepositEscrowResponse {
	if escrows == nil {
		return nil
	}
	result := make([]DepositEscrowResponse, len(escrows))
	for i, e := range escrows {
		result[i] = *FromCoreDepositEscrow(&e)
	}
	return result
}

func convertInteractions(interactions []coreEntities.Interaction) []InteractionResponse {
	if interactions == nil {
		return nil
	}
	result := make([]InteractionResponse, len(interactions))
	for i, interaction := range interactions {
		result[i] = *FromCoreInteraction(&interaction)
	}
	return result
}

func convertInvoiceDistributionInfos(infos []coreEntities.InvoiceDistributionInfo) []InvoiceDistributionInfoResponse {
	if infos == nil {
		return nil
	}
	result := make([]InvoiceDistributionInfoResponse, len(infos))
	for i, info := range infos {
		result[i] = *FromCoreInvoiceDistributionInfo(&info)
	}
	return result
}

func convertInvoices(invoices []coreEntities.Invoice) []InvoiceResponse {
	if invoices == nil {
		return nil
	}
	result := make([]InvoiceResponse, len(invoices))
	for i, invoice := range invoices {
		result[i] = *FromCoreInvoice(&invoice)
	}
	return result
}

func convertLdcAccounts(accounts []coreEntities.LdcAccount) []LdcAccountResponse {
	if accounts == nil {
		return nil
	}
	result := make([]LdcAccountResponse, len(accounts))
	for i, account := range accounts {
		result[i] = *FromCoreLdcAccount(&account)
	}
	return result
}

func convertPricePlans(plans []coreEntities.PricePlan) []PricePlanResponse {
	if plans == nil {
		return nil
	}
	result := make([]PricePlanResponse, len(plans))
	for i, plan := range plans {
		result[i] = *FromCorePricePlan(&plan)
	}
	return result
}

// FromCoreAccount converts a core Account entity to a AccountResponse
func FromCoreAccount(account *coreEntities.Account) *AccountResponse {
	if account == nil {
		return nil
	}
	return &AccountResponse{
		ActiveIn:                      account.ActiveIn,
		AccountBalance:                account.AccountBalance,
		AccountId:                     account.AccountId,
		AccountNo:                     account.AccountNo,
		AccountNoSeq:                  account.AccountNoSeq,
		ACHDebitDayofMonth:            account.ACHDebitDayofMonth,
		ACHDirectDebitStatus:          account.ACHDirectDebitStatus,
		ACHRequestDateCalcCode:        account.ACHRequestDateCalcCode,
		ACHStatusDate:                 account.ACHStatusDate,
		AlertNote:                     account.AlertNote,
		BankABA:                       account.BankABA,
		BankAcctId:                    account.BankAcctId,
		BankAcctType:                  account.BankAcctType,
		BankAuthCode:                  account.BankAuthCode,
		BankAuthDate:                  account.BankAuthDate,
		BankCustomerName:              account.BankCustomerName,
		BankName:                      account.BankName,
		BankTransitId:                 account.BankTransitId,
		BudgetBillStatus:              account.BudgetBillStatus,
		CalculatedBalance:             account.CalculatedBalance,
		CCExpireDate:                  account.CCExpireDate,
		CCName:                        account.CCName,
		CCNo:                          account.CCNo,
		CCSuspendDate:                 account.CCSuspendDate,
		CCTypeCode:                    account.CCTypeCode,
		CCTypeCodeDesc:                account.CCTypeCodeDesc,
		ClassName:                     account.ClassName,
		ContainsBudgetBillLdcAccounts: account.ContainsBudgetBillLdcAccounts,
		CurrentUsage:                  account.CurrentUsage,
		Creation:                      account.Creation,
		CreationDate:                  account.CreationDate,
		CreditBalance:                 account.CreditBalance,
		CreditandCollectionRuleName:   account.CreditandCollectionRuleName,
		CreditCollectionRuleId:        account.CreditCollectionRuleId,
		CreditCollectRule:             FromCoreCreditCollectionRule(account.CreditCollectRule),
		CustomerClassType:             account.CustomerClassType,
		CustomerId:                    account.CustomerId,
		DepositEscrows:                convertDepositEscrows(account.DepositEscrows),
		DisplayCode:                   account.DisplayCode,
		DisplayName:                   account.DisplayName,
		Do810867MatchIn:               account.Do810867MatchIn,
		EstimationWaitPer:             account.EstimationWaitPer,
		EventLDCAcctId:                account.EventLDCAcctId,
		FirstName:                     account.FirstName,
		Interactions:                  convertInteractions(account.Interactions),
		InvDistInfos:                  convertInvoiceDistributionInfos(account.InvDistInfos),
		InvoiceAdviceRequirement:      account.InvoiceAdviceRequirement,
		InvoiceHold:                   account.InvoiceHold,
		InvoiceCreationEventRule:      account.InvoiceCreationEventRule,
		InvoiceMessage:                account.InvoiceMessage,
		InvoiceQueueStatusDescription: account.InvoiceQueueStatusDescription,
		InvoiceCycle:                  account.InvoiceCycle,
		Invoices:                      convertInvoices(account.Invoices),
		IsACHDirectDebit:              account.IsACHDirectDebit,
		IsDirectCreditStatusActive:    account.IsDirectCreditStatusActive,
		IsOnPaymentArrangement:        account.IsOnPaymentArrangement,
		IsSEPADirectDebit:             account.IsSEPADirectDebit,
		LdcAccounts:                   convertLdcAccounts(account.LdcAccounts),
		LastName:                      account.LastName,
		LPCSuspendDate:                account.LPCSuspendDate,
		MiddleName:                    account.MiddleName,
		Name:                          account.Name,
		NewCharge:                     FromCoreTransaction(account.NewCharge),
		NewCredit:                     FromCoreTransaction(account.NewCredit),
		NextInvoiceDate:               account.NextInvoiceDate,
		NumberOfLDCAccounts:           account.NumberOfLDCAccounts,
		PhoneNo:                       account.PhoneNo,
		PreviousInvoiceDate:           account.PreviousInvoiceDate,
		PreviousInvoiceDueDate:        account.PreviousInvoiceDueDate,
		PrevInvoiceBalAm:              account.PrevInvoiceBalAm,
		PricePlans:                    convertPricePlans(account.PricePlans),
		SEPADirectDebitStatus:         account.SEPADirectDebitStatus,
		SEPADaysOverride:              account.SEPADaysOverride,
		SEPAFirstDays:                 account.SEPAFirstDays,
		SEPAMandateExpiration:         account.SEPAMandateExpiration,
		SEPAMandateReference:          account.SEPAMandateReference,
		SEPAMandateSignature:          account.SEPAMandateSignature,
		SEPARecurrentDays:             account.SEPARecurrentDays,
		SpecialHandling:               account.SpecialHandling,
		SuspendCC:                     account.SuspendCC,
		SuspendLPC:                    account.SuspendLPC,
		TaxID:                         account.TaxID,
		TaxIDState:                    account.TaxIDState,
		Transactions:                  convertTransactions(account.Transactions),
		VendorAliasDbNumber:           account.VendorAliasDbNumber,
		VendorAliasName:               account.VendorAliasName,
		VendorBank:                    account.VendorBank,
		VendorDBNo:                    account.VendorDBNo,
		VendorDisplayDBNumber:         account.VendorDisplayDBNumber,
		VendorDisplayName:             account.VendorDisplayName,
		VendorId:                      account.VendorId,
	}
}
