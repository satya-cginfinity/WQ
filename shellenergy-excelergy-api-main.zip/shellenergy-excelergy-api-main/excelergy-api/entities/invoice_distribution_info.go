package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type InvoiceDistributionInfoResponse struct {
	AddressID       uint64                    `json:"addressID"`
	Attn            string                    `json:"attn"`
	City            string                    `json:"city"`
	Country         string                    `json:"country"`
	County          string                    `json:"county"`
	DistType        string                    `json:"distType"`
	EmailAddr       string                    `json:"emailAddr"`
	FormatType      string                    `json:"formatType"`
	InvDistType     string                    `json:"invDistType"`
	Line1           string                    `json:"line1"`
	Line2           string                    `json:"line2"`
	Name            string                    `json:"name"`
	PostalCode      string                    `json:"postalCode"`
	RelateClassName string                    `json:"relateClassName"`
	RelateId        uint64                    `json:"relateId"`
	State           string                    `json:"state"`
	SysTmStamp      coreEntities.FlexibleTime `json:"sysTmStamp"`
}

// FromCoreInvoiceDistributionInfo converts a core InvoiceDistributionInfo entity to a InvoiceDistributionInfoResponse
func FromCoreInvoiceDistributionInfo(info *coreEntities.InvoiceDistributionInfo) *InvoiceDistributionInfoResponse {
	if info == nil {
		return nil
	}
	return &InvoiceDistributionInfoResponse{
		AddressID:       info.AddressID,
		Attn:            info.Attn,
		City:            info.City,
		Country:         info.Country,
		County:          info.County,
		DistType:        info.DistType,
		EmailAddr:       info.EmailAddr,
		FormatType:      info.FormatType,
		InvDistType:     info.InvDistType,
		Line1:           info.Line1,
		Line2:           info.Line2,
		Name:            info.Name,
		PostalCode:      info.PostalCode,
		RelateClassName: info.RelateClassName,
		RelateId:        info.RelateId,
		State:           info.State,
		SysTmStamp:      info.SysTmStamp,
	}
}

// FromCoreInvoiceDistributionInfos converts a slice of core InvoiceDistributionInfo entities to InvoiceDistributionInfoResponse slice
func FromCoreInvoiceDistributionInfos(infos []coreEntities.InvoiceDistributionInfo) []InvoiceDistributionInfoResponse {
	result := make([]InvoiceDistributionInfoResponse, 0, len(infos))
	for i := range infos {
		if r := FromCoreInvoiceDistributionInfo(&infos[i]); r != nil {
			result = append(result, *r)
		}
	}
	return result
}
