package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type PaymentHistoryResponse struct {
	TotalFound    int                `json:"totalFound"`
	TotalReturned int                `json:"totalReturned"`
	AccountNumber string             `json:"accountNumber"`
	Payments      []*PaymentResponse `json:"payments"`
}

// FromCorePaymentHistory converts a core PaymentHistory entity to a PaymentHistoryResponse
func FromCorePaymentHistory(history *coreEntities.PaymentHistory) *PaymentHistoryResponse {
	if history == nil {
		return nil
	}
	return &PaymentHistoryResponse{
		TotalFound:    history.TotalFound,
		TotalReturned: history.TotalReturned,
		AccountNumber: history.AccountNumber,
		Payments:      FromCorePayments(history.Payments),
	}
}
