package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type HolidayResponse struct {
	HolidayId   uint64 `json:"holidayId"`
	CalendarId  uint64 `json:"calendarId"`
	HolidayDate string `json:"holidayDate"`
	HolidayType string `json:"holidayType"`
	Description string `json:"description"`
}

// FromCoreHoliday converts a core Holiday entity to a HolidayResponse
func FromCoreHoliday(holiday *coreEntities.Holiday) *HolidayResponse {
	if holiday == nil {
		return nil
	}
	return &HolidayResponse{
		HolidayId:   holiday.HolidayId,
		CalendarId:  holiday.CalendarId,
		HolidayDate: holiday.HolidayDate,
		HolidayType: holiday.HolidayType,
		Description: holiday.Description,
	}
}

// FromCoreHolidays converts a slice of core Holiday entities to a slice of HolidayResponse
func FromCoreHolidays(holidays []coreEntities.Holiday) []HolidayResponse {
	if holidays == nil {
		return nil
	}
	responses := make([]HolidayResponse, len(holidays))
	for i, holiday := range holidays {
		responses[i] = *FromCoreHoliday(&holiday)
	}
	return responses
}
