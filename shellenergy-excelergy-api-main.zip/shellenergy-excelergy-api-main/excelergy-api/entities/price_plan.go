package entities

import coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"

type PricePlanResponse struct {
	AccountPricePlan      bool    `json:"accountPricePlan"`
	BreakPointPricing     bool    `json:"breakPointPricing"`
	Description           string  `json:"description"`
	DisplayCode           string  `json:"displayCode"`
	DisplayName           string  `json:"displayName"`
	DisplayNameEx         string  `json:"displayNameEx"`
	EndDate               string  `json:"endDate"`
	ExternalRateCode      string  `json:"externalRateCode"`
	ExternalUOMCd         string  `json:"externalUOMCd"`
	ExternalVendorPPU     float64 `json:"externalVendorPPU"`
	IsDistributionType    bool    `json:"isDistributionType"`
	IsSupplyType          bool    `json:"isSupplyType"`
	NonPassThruDomain     string  `json:"nonPassThruDomain"`
	PricePlanCode         string  `json:"pricePlanCode"`
	PricePlanId           uint64  `json:"pricePlanId"`
	Restricted            bool    `json:"restricted"`
	SeasonGroupId         uint64  `json:"seasonGroupId"`
	ServiceType           string  `json:"serviceType"`
	SignificanceProfileId uint64  `json:"significanceProfileId"`
	StartDate             string  `json:"startDate"`
	TypeCd                string  `json:"typeCd"`
	VendorDBNumber        string  `json:"vendorDBNumber"`
	VendorId              uint64  `json:"vendorId"`
	VendorName            string  `json:"vendorName"`
}

// FromCorePricePlan converts a core PricePlan entity to a PricePlanResponse
func FromCorePricePlan(pricePlan *coreEntities.PricePlan) *PricePlanResponse {
	if pricePlan == nil {
		return nil
	}
	return &PricePlanResponse{
		AccountPricePlan:      pricePlan.AccountPricePlan,
		BreakPointPricing:     pricePlan.BreakPointPricing,
		Description:           pricePlan.Description,
		DisplayCode:           pricePlan.DisplayCode,
		DisplayName:           pricePlan.DisplayName,
		DisplayNameEx:         pricePlan.DisplayNameEx,
		EndDate:               pricePlan.EndDate,
		ExternalRateCode:      pricePlan.ExternalRateCode,
		ExternalUOMCd:         pricePlan.ExternalUOMCd,
		ExternalVendorPPU:     pricePlan.ExternalVendorPPU,
		IsDistributionType:    pricePlan.IsDistributionType,
		IsSupplyType:          pricePlan.IsSupplyType,
		NonPassThruDomain:     pricePlan.NonPassThruDomain,
		PricePlanCode:         pricePlan.PricePlanCode,
		PricePlanId:           pricePlan.PricePlanId,
		Restricted:            pricePlan.Restricted,
		SeasonGroupId:         pricePlan.SeasonGroupId,
		ServiceType:           pricePlan.ServiceType,
		SignificanceProfileId: pricePlan.SignificanceProfileId,
		StartDate:             pricePlan.StartDate,
		TypeCd:                pricePlan.TypeCd,
		VendorDBNumber:        pricePlan.VendorDBNumber,
		VendorId:              pricePlan.VendorId,
		VendorName:            pricePlan.VendorName,
	}
}
