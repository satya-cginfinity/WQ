package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type AccountBalanceResponse struct {
	BudgetBillVariance      float64 `json:"budgetBillVariance"`
	Current                 float64 `json:"current"`
	Over0                   float64 `json:"over0"`
	Over30                  float64 `json:"over30"`
	Over60                  float64 `json:"over60"`
	Over90                  float64 `json:"over90"`
	Total                   float64 `json:"total"`
	TransactionGroupingType string  `json:"transactionGroupingType"`
	UnappliedCredits        float64 `json:"unappliedCredits"`
	Unbilled                float64 `json:"unbilled"`
	VendorName              string  `json:"vendorName"`
}

// FromCoreAccountBalance converts a core AccountBalance entity to an AccountBalanceResponse
func FromCoreAccountBalance(ab *coreEntities.AccountBalance) *AccountBalanceResponse {
	if ab == nil {
		return nil
	}
	return &AccountBalanceResponse{
		BudgetBillVariance:      ab.BudgetBillVariance,
		Current:                 ab.Current,
		Over0:                   ab.Over0,
		Over30:                  ab.Over30,
		Over60:                  ab.Over60,
		Over90:                  ab.Over90,
		Total:                   ab.Total,
		TransactionGroupingType: ab.TransactionGroupingType,
		UnappliedCredits:        ab.UnappliedCredits,
		Unbilled:                ab.Unbilled,
		VendorName:              ab.VendorName,
	}
}
