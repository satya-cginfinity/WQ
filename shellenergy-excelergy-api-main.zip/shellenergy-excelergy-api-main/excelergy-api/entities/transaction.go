package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type TransactionResponse struct {
	AccountId                     uint64   `json:"accountId"`
	AccountNumber                 string   `json:"accountNumber"`
	AddressId                     uint64   `json:"addressId"`
	AppliedAmount                 *float64 `json:"appliedAmount"`
	ApplyToInvoiceID              uint64   `json:"applyToInvoiceID"`
	ApplyToInvoiceNo              uint64   `json:"applyToInvoiceNo"`
	BillMethodCD                  string   `json:"billMethodCD"`
	BudgetBillActual              bool     `json:"budgetBillActual"`
	BudgetBillPlanId              uint64   `json:"budgetBillPlanId"`
	BudgetBillTypeDesc            string   `json:"budgetBillTypeDesc"`
	ClassName                     string   `json:"className"`
	CollectionHoldExpDt           string   `json:"collectionHoldExpDt"`
	CollectionHoldStartDt         string   `json:"collectionHoldStartDt"`
	CollectionHoldTyCd            string   `json:"collectionHoldTyCd"`
	Comment                       string   `json:"comment"`
	CreditChargeAmount            float64  `json:"creditChargeAmount"`
	CreditChargeOutstandingAmount *float64 `json:"creditChargeOutstandingAmount"`
	CustomerClassType             string   `json:"customerClassType"`
	DisplayCode                   string   `json:"displayCode"`
	DisplayName                   string   `json:"displayName"`
	DueDate                       string   `json:"dueDate"`
	ExcludeFromAR                 bool     `json:"excludeFromAR"`
	Generic1Date                  string   `json:"generic1Date"`
	Generic2Date                  string   `json:"generic2Date"`
	GLCreditCD                    string   `json:"glCreditCD"`
	GLDebitCD                     string   `json:"glDebitCD"`
	GLPostedDt                    string   `json:"glPostedDt"`
	HoldStatus                    string   `json:"holdStatus"`
	InAuditTrans                  bool     `json:"inAuditTrans"`
	InBeenOffset                  bool     `json:"inBeenOffset"`
	InBeenOffsetAdj               bool     `json:"inBeenOffsetAdj"`
	InCancel                      bool     `json:"inCancel"`
	InOffsetAdj                   bool     `json:"inOffsetAdj"`
	InOffsetTrans                 bool     `json:"inOffsetTrans"`
	InvoiceHoldExpiration         string   `json:"invoiceHoldExpiration"`
	InvoiceInclusion              string   `json:"invoiceInclusion"`
	InvoiceInclusionExclude       bool     `json:"invoiceInclusionExclude"`
	InvoiceInclusionInclude       bool     `json:"invoiceInclusionInclude"`
	InvoiceInclusionWithUsage     bool     `json:"invoiceInclusionWithUsage"`
	InvoiceNumber                 string   `json:"invoiceNumber"`
	InvoiceNumberDisplay          string   `json:"invoiceNumberDisplay"`
	IsACHDirectCredit             bool     `json:"isAchDirectCredit"`
	IsCancelled                   bool     `json:"isCancelled"`
	IsCharge                      bool     `json:"isCharge"`
	IsCreatedFromUsage            bool     `json:"isCreatedFromUsage"`
	IsCredit                      bool     `json:"isCredit"`
	LDCAccountId                  uint64   `json:"ldcAccountId"`
	LDCAccountNumber              string   `json:"ldcAccountNumber"`
	OriginCode                    string   `json:"originCode"`
	OutstandingAmount             *float64 `json:"outstandingAmount"`
	PPA                           bool     `json:"ppa"`
	PPADesc                       string   `json:"ppaDesc"`
	PricePerUnitAmount            float64  `json:"pricePerUnitAmount"`
	ReferenceNo                   string   `json:"referenceNo"`
	ServiceType                   string   `json:"serviceType"`
	TransactionAmount             float64  `json:"transactionAmount"`
	TransactionDate               string   `json:"transactionDate"`
	TransactionId                 uint64   `json:"transactionId"`
	TransactionQuantity           float64  `json:"transactionQuantity"`
	TransactionSubTypeCode        string   `json:"transactionSubTypeCode"`
	TransactionSubTypeCodeDesc    string   `json:"transactionSubTypeCodeDesc"`
	TransactionTypeCode           string   `json:"transactionTypeCode"`
	TransactionTypeCodeDesc       string   `json:"transactionTypeCodeDesc"`
	TransCreateDate               string   `json:"transCreateDate"`
	UnitTypeCode                  string   `json:"unitTypeCode"`
	UsageGroupId                  uint64   `json:"usageGroupId"`
	VendorDBNo                    string   `json:"vendorDBNo"`
	VendorId                      uint64   `json:"vendorId"`
	VendorName                    string   `json:"vendorName"`
}

// FromCoreTransaction converts a core Transaction entity to a TransactionResponse
func FromCoreTransaction(transaction *coreEntities.Transaction) *TransactionResponse {
	if transaction == nil {
		return nil
	}
	return &TransactionResponse{
		AccountId:                     transaction.AccountId,
		AccountNumber:                 transaction.AccountNumber,
		AddressId:                     transaction.AddressId,
		AppliedAmount:                 transaction.AppliedAmount,
		ApplyToInvoiceID:              transaction.ApplyToInvoiceID,
		ApplyToInvoiceNo:              transaction.ApplyToInvoiceNo,
		BillMethodCD:                  transaction.BillMethodCD,
		BudgetBillActual:              transaction.BudgetBillActual,
		BudgetBillPlanId:              transaction.BudgetBillPlanId,
		BudgetBillTypeDesc:            transaction.BudgetBillTypeDesc,
		ClassName:                     transaction.ClassName,
		CollectionHoldExpDt:           transaction.CollectionHoldExpDt,
		CollectionHoldStartDt:         transaction.CollectionHoldStartDt,
		CollectionHoldTyCd:            transaction.CollectionHoldTyCd,
		Comment:                       transaction.Comment,
		CreditChargeAmount:            transaction.CreditChargeAmount,
		CreditChargeOutstandingAmount: transaction.CreditChargeOutstandingAmount,
		CustomerClassType:             transaction.CustomerClassType,
		DisplayCode:                   transaction.DisplayCode,
		DisplayName:                   transaction.DisplayName,
		DueDate:                       transaction.DueDate,
		ExcludeFromAR:                 transaction.ExcludeFromAR,
		Generic1Date:                  transaction.Generic1Date,
		Generic2Date:                  transaction.Generic2Date,
		GLCreditCD:                    transaction.GLCreditCD,
		GLDebitCD:                     transaction.GLDebitCD,
		GLPostedDt:                    transaction.GLPostedDt,
		HoldStatus:                    transaction.HoldStatus,
		InAuditTrans:                  transaction.InAuditTrans,
		InBeenOffset:                  transaction.InBeenOffset,
		InBeenOffsetAdj:               transaction.InBeenOffsetAdj,
		InCancel:                      transaction.InCancel,
		InOffsetAdj:                   transaction.InOffsetAdj,
		InOffsetTrans:                 transaction.InOffsetTrans,
		InvoiceHoldExpiration:         transaction.InvoiceHoldExpiration,
		InvoiceInclusion:              transaction.InvoiceInclusion,
		InvoiceInclusionExclude:       transaction.InvoiceInclusionExclude,
		InvoiceInclusionInclude:       transaction.InvoiceInclusionInclude,
		InvoiceInclusionWithUsage:     transaction.InvoiceInclusionWithUsage,
		InvoiceNumber:                 transaction.InvoiceNumber,
		InvoiceNumberDisplay:          transaction.InvoiceNumberDisplay,
		IsACHDirectCredit:             transaction.IsACHDirectCredit,
		IsCancelled:                   transaction.IsCancelled,
		IsCharge:                      transaction.IsCharge,
		IsCreatedFromUsage:            transaction.IsCreatedFromUsage,
		IsCredit:                      transaction.IsCredit,
		LDCAccountId:                  transaction.LDCAccountId,
		LDCAccountNumber:              transaction.LDCAccountNumber,
		OriginCode:                    transaction.OriginCode,
		OutstandingAmount:             transaction.OutstandingAmount,
		PPA:                           transaction.PPA,
		PPADesc:                       transaction.PPADesc,
		PricePerUnitAmount:            transaction.PricePerUnitAmount,
		ReferenceNo:                   transaction.ReferenceNo,
		ServiceType:                   transaction.ServiceType,
		TransactionAmount:             transaction.TransactionAmount,
		TransactionDate:               transaction.TransactionDate,
		TransactionId:                 transaction.TransactionId,
		TransactionQuantity:           transaction.TransactionQuantity,
		TransactionSubTypeCode:        transaction.TransactionSubTypeCode,
		TransactionSubTypeCodeDesc:    transaction.TransactionSubTypeCodeDesc,
		TransactionTypeCode:           transaction.TransactionTypeCode,
		TransactionTypeCodeDesc:       transaction.TransactionTypeCodeDesc,
		TransCreateDate:               transaction.TransCreateDate,
		UnitTypeCode:                  transaction.UnitTypeCode,
		UsageGroupId:                  transaction.UsageGroupId,
		VendorDBNo:                    transaction.VendorDBNo,
		VendorId:                      transaction.VendorId,
		VendorName:                    transaction.VendorName,
	}
}
