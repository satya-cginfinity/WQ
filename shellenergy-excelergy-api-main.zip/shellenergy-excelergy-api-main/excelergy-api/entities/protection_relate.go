package entities

import (
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type ProtectionRelateResponse struct {
	DisplayCode               string                    `json:"displayCode"`
	DisplayName               string                    `json:"displayName"`
	EndDate                   coreEntities.FlexibleTime `json:"endDate"`
	LdcAcctId                 uint64                    `json:"ldcAcctId"`
	ProtectionId              uint64                    `json:"protectionId"`
	ProtectionIdSetDatesIfNew uint64                    `json:"protectionIdSetDatesIfNew"`
	ProtectionName            string                    `json:"protectionName"`
	StartDate                 coreEntities.FlexibleTime `json:"startDate"`
}

// FromCoreProtectionRelate converts a core ProtectionRelate entity to a ProtectionRelateResponse
func FromCoreProtectionRelate(protectionRelate *coreEntities.ProtectionRelate) *ProtectionRelateResponse {
	if protectionRelate == nil {
		return nil
	}
	return &ProtectionRelateResponse{
		DisplayCode:               protectionRelate.DisplayCode,
		DisplayName:               protectionRelate.DisplayName,
		EndDate:                   protectionRelate.EndDate,
		LdcAcctId:                 protectionRelate.LdcAcctId,
		ProtectionId:              protectionRelate.ProtectionId,
		ProtectionIdSetDatesIfNew: protectionRelate.ProtectionIdSetDatesIfNew,
		ProtectionName:            protectionRelate.ProtectionName,
		StartDate:                 protectionRelate.StartDate,
	}
}
