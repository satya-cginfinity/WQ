package logger

type ILoggerConfig interface {
	IsDevelopment() bool
}
