package logger

import (
	core_logger "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

// zapLogger is a zap-based implementation of the Logger interface
type zapLogger struct {
	zap *zap.SugaredLogger
}

// NewLogger creates a new logger instance with the specified configuration
func NewLogger(config ILoggerConfig) (core_logger.ILogger, error) {
	var zapConfig zap.Config

	if config.IsDevelopment() {
		zapConfig = zap.NewDevelopmentConfig()
		zapConfig.EncoderConfig.EncodeLevel = zapcore.CapitalColorLevelEncoder
	} else {
		zapConfig = zap.NewProductionConfig()
	}

	zapLog, err := zapConfig.Build()
	if err != nil {
		return nil, err
	}

	return &zapLogger{
		zap: zapLog.Sugar(),
	}, nil
}

// Debug logs a message at debug level with optional structured fields
func (l *zapLogger) Debug(msg string, fields ...interface{}) {
	l.zap.Debugw(msg, fields...)
}

// Info logs a message at info level with optional structured fields
func (l *zapLogger) Info(msg string, fields ...interface{}) {
	l.zap.Infow(msg, fields...)
}

// Warn logs a message at warn level with optional structured fields
func (l *zapLogger) Warn(msg string, fields ...interface{}) {
	l.zap.Warnw(msg, fields...)
}

// Error logs a message at error level with optional structured fields
func (l *zapLogger) Error(msg string, fields ...interface{}) {
	l.zap.Errorw(msg, fields...)
}

// Fatal logs a message at fatal level and terminates the application
func (l *zapLogger) Fatal(msg string, fields ...interface{}) {
	l.zap.Fatalw(msg, fields...)
}

// With creates a child logger with additional context fields
func (l *zapLogger) With(fields ...interface{}) core_logger.ILogger {
	return &zapLogger{
		zap: l.zap.With(fields...),
	}
}

// Sync flushes any buffered log entries
func (l *zapLogger) Sync() error {
	return l.zap.Sync()
}
