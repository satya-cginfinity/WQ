package config

import (
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/logger"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/middleware"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/router"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
)

type IConfig interface {
	logger.ILoggerConfig
	router.IRouterConfig
	client.IClientConfig
	middleware.IAuthConfig
}
