package config

import (
	"fmt"
	"os"
	"strconv"
	"strings"

	"github.com/joho/godotenv"
)

type Config struct {
	development        bool
	allowCORS          bool
	allowedCORSOrigins []string
	routerPort         int
	httpBaseURL        string
	httpTimeout        int
	httpToken          string
	apiKey             string
}

func NewConfig() (IConfig, error) {
	if err := godotenv.Load(); err != nil {
		return nil, err
	}

	config := &Config{
		development:        false,
		allowCORS:          false,
		allowedCORSOrigins: []string{},
		routerPort:         50000,
	}

	developmentValue := os.Getenv("DEVELOPMENT")
	if developmentValue == "true" {
		config.development = true
	}

	allowCORSValue := os.Getenv("ALLOW_CORS")
	if allowCORSValue == "true" {
		config.allowCORS = true
	}

	allowedCORSOriginsValue := os.Getenv("ALLOWED_CORS_ORIGINS")
	if allowedCORSOriginsValue != "" {
		config.allowedCORSOrigins = strings.Split(allowedCORSOriginsValue, ",")
	}

	routerPortValue := os.Getenv("ROUTER_PORT")
	if routerPortValue != "" {
		if port, err := strconv.Atoi(routerPortValue); err == nil {
			config.routerPort = port
		}
	}

	httpBaseURLValue := os.Getenv("HTTP_BASE_URL")
	if httpBaseURLValue != "" {
		config.httpBaseURL = httpBaseURLValue
	} else {
		return nil, fmt.Errorf("HTTP_BASE_URL environment variable is required")
	}

	httpTimeoutValue := os.Getenv("HTTP_TIMEOUT")
	if httpTimeoutValue != "" {
		if timeout, err := strconv.Atoi(httpTimeoutValue); err == nil {
			config.httpTimeout = timeout
		} else {
			config.httpTimeout = 30
		}
	} else {
		config.httpTimeout = 30
	}

	httpTokenValue := os.Getenv("HTTP_TOKEN")
	if httpTokenValue != "" {
		config.httpToken = httpTokenValue
	} else {
		return nil, fmt.Errorf("HTTP_TOKEN environment variable is required")
	}

	apiKeyValue := os.Getenv("API_KEY")
	if apiKeyValue != "" {
		config.apiKey = apiKeyValue
	} else {
		return nil, fmt.Errorf("API_KEY environment variable is required")
	}

	return config, nil
}

// IsDevelopment implements IConfig.
func (c *Config) IsDevelopment() bool {
	return c.development
}

// AllowCORS implements IRouterConfig.
func (c *Config) AllowCORS() bool {
	return c.allowCORS
}

// AllowedCORSOrigins implements IRouterConfig.
func (c *Config) AllowedCORSOrigins() []string {
	return c.allowedCORSOrigins
}

// RouterPort implements IRouterConfig.
func (c *Config) RouterPort() int {
	return c.routerPort
}

// GetHTTPBaseURL implements IClientConfig.
func (c *Config) GetHTTPBaseURL() string {
	return c.httpBaseURL
}

// GetTimeout implements IClientConfig.
func (c *Config) GetHTTPTimeout() int {
	return c.httpTimeout
}

// GetHTTPToken implements IClientConfig.
func (c *Config) GetHTTPToken() string {
	return c.httpToken
}

// GetAPIKey implements IAuthConfig.
func (c *Config) GetAPIKey() string {
	return c.apiKey
}
