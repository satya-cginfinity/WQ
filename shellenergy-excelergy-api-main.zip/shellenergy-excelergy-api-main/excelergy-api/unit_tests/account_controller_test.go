package unit_tests

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/controllers"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/unit_tests/mocks"
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"

	"go.uber.org/mock/gomock"
)

// helper: build an *http.Request with the given query string.
func newGetRequest(t *testing.T, query string) *http.Request {
	t.Helper()
	req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, "/account"+query, nil)
	if err != nil {
		t.Fatalf("failed to create request: %v", err)
	}
	return req
}

// sampleCoreAccount returns a minimal core Account used in success scenarios.
func sampleCoreAccount() *coreEntities.Account {
	balance := 123.45
	return &coreEntities.Account{
		AccountId:      42,
		AccountNo:      "ACC-001",
		AccountBalance: &balance,
		Name:           "Test Account",
		FirstName:      "John",
		LastName:       "Doe",
	}
}

// newTestAccountController creates an AccountController via the exported
// constructor using mock dependencies (Dependency Injection).
func newTestAccountController(
	t *testing.T,
	mockRepo *mocks.MockIAccountRepository,
	mockLogger *mocks.MockILogger,
	isDevelopment bool,
) controllers.IAccountController {
	t.Helper()

	ctrl := gomock.NewController(t)
	mockCfg := mocks.NewMockIClientConfig(ctrl)
	mockCfg.EXPECT().IsDevelopment().Return(isDevelopment).AnyTimes()

	// NewAccountController returns IController; the underlying type also
	// satisfies IAccountController, so the type-assertion is safe.
	c := controllers.NewAccountController(mockLogger, mockRepo, nil, mockCfg)
	accountCtrl, ok := c.(controllers.IAccountController)
	if !ok {
		t.Fatal("NewAccountController did not return an IAccountController")
	}
	return accountCtrl
}

func TestGetAccountById(t *testing.T) {
	tests := []struct {
		name               string
		query              string // query string appended to /account
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, body []byte)
	}{
		{
			name:          "missing accountId query parameter returns 400",
			query:         "",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "accountId query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty accountId query parameter returns 400",
			query:         "?accountId=",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "non-numeric accountId returns 400",
			query:         "?accountId=abc",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "accountId must be a valid positive integer" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "negative accountId returns 400",
			query:         "?accountId=-1",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 502",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountById(gomock.Any(), uint64(42)).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 401 unauthorized",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountById(gomock.Any(), uint64(42)).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - context deadline exceeded",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountById(gomock.Any(), uint64(42)).
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns generic error - 500",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountById(gomock.Any(), uint64(42)).
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns nil account - 404",
			query:         "?accountId=999",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountById(gomock.Any(), uint64(999)).
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "account not found" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "valid accountId returns 200 with account data",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetAccountById(gomock.Any(), uint64(42)).
					Return(sampleCoreAccount(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.AccountResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 1 {
					t.Fatalf("expected 1 item in data array, got %d", len(wrapper.Data))
				}
				resp := wrapper.Data[0]
				if resp.AccountId != 42 {
					t.Errorf("expected AccountId 42, got %d", resp.AccountId)
				}
				if resp.AccountNo != "ACC-001" {
					t.Errorf("expected AccountNo ACC-001, got %s", resp.AccountNo)
				}
				if resp.Name != "Test Account" {
					t.Errorf("expected Name 'Test Account', got %s", resp.Name)
				}
				if resp.AccountBalance == nil || *resp.AccountBalance != 123.45 {
					t.Errorf("expected AccountBalance 123.45, got %v", resp.AccountBalance)
				}
			},
		},
		{
			name:          "development mode includes error details on 400",
			query:         "?accountId=abc",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountById(gomock.Any(), uint64(42)).
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
		{
			name:          "development mode includes error details on repository error",
			query:         "?accountId=42",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountById(gomock.Any(), uint64(42)).
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "upstream 429 rate limit returns 429",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountById(gomock.Any(), uint64(42)).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "float accountId returns 400",
			query:         "?accountId=3.14",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "zero accountId is valid and calls repository",
			query:         "?accountId=0",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountById(gomock.Any(), uint64(0)).
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockIAccountRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			// Setup mock expectations for this test case
			tt.setupMocks(mockRepo, mockLogger)

			// Construct the controller via the exported constructor (DI)
			accountCtrl := newTestAccountController(t, mockRepo, mockLogger, tt.isDevelopment)

			// Build request and recorder
			req := newGetRequest(t, tt.query)
			rr := httptest.NewRecorder()

			// Execute
			accountCtrl.GetAccountById(rr, req)

			// Assert status code
			if rr.Code != tt.expectedStatusCode {
				t.Errorf("expected status %d, got %d", tt.expectedStatusCode, rr.Code)
			}

			// Assert Content-Type header
			contentType := rr.Header().Get("Content-Type")
			if contentType != "application/json" {
				t.Errorf("expected Content-Type application/json, got %s", contentType)
			}

			// Run custom body validations
			if tt.validateBody != nil {
				tt.validateBody(t, rr.Body.Bytes())
			}
		})
	}
}

// helper: build a POST *http.Request with the given JSON body string.
func newPostRequest(t *testing.T, body string) *http.Request {
	t.Helper()
	req, err := http.NewRequestWithContext(context.Background(), http.MethodPost, "/account", strings.NewReader(body))
	if err != nil {
		t.Fatalf("failed to create request: %v", err)
	}
	req.Header.Set("Content-Type", "application/json")
	return req
}

// sampleCoreAccounts returns a slice of core Accounts used in success scenarios.
func sampleCoreAccounts() []coreEntities.Account {
	balance := 500.00
	return []coreEntities.Account{
		{
			AccountId:      10,
			AccountNo:      "ACC-010",
			AccountBalance: &balance,
			Name:           "Alpha Account",
			FirstName:      "Alice",
			LastName:       "Smith",
		},
		{
			AccountId: 11,
			AccountNo: "ACC-011",
			Name:      "Beta Account",
			FirstName: "Bob",
			LastName:  "Jones",
		},
	}
}

// sampleCoreAccountBalance returns a minimal core AccountBalance used in success scenarios.
func sampleCoreAccountBalance() *coreEntities.AccountBalance {
	return &coreEntities.AccountBalance{
		Total:                   250.75,
		Current:                 100.00,
		Over0:                   50.25,
		Over30:                  60.00,
		Over60:                  30.50,
		Over90:                  10.00,
		Unbilled:                0.00,
		UnappliedCredits:        0.00,
		BudgetBillVariance:      0.00,
		TransactionGroupingType: "STANDARD",
		VendorName:              "Test Vendor",
	}
}

// sampleCorePaymentArrangements returns a slice of core PaymentArrangement used in success scenarios.
func sampleCorePaymentArrangements() []coreEntities.PaymentArrangement {
	return []coreEntities.PaymentArrangement{
		{
			AccountBalance:    true,
			AcctId:            42,
			Amount:            500.00,
			ClosedDate:        "2025-12-01",
			CreationDate:      "2025-01-15",
			Duration:          12,
			FirstPaymentDate:  "2025-02-01",
			GoodwillApplies:   false,
			Invoiced:          true,
			InvoiceLookupDate: "2025-01-20",
			IsGoodwillEnabled: true,
			LastPaymentDate:   "2025-12-01",
			PaidAmount:        250.00,
			PurposeCode:       "PAY",
			ScheduleAmount:    41.67,
			Status:            "ACTIVE",
			TypeCode:          "INSTALLMENT",
		},
		{
			AccountBalance:    false,
			AcctId:            42,
			Amount:            200.00,
			ClosedDate:        "",
			CreationDate:      "2025-06-01",
			Duration:          6,
			FirstPaymentDate:  "2025-07-01",
			GoodwillApplies:   true,
			Invoiced:          false,
			InvoiceLookupDate: "2025-06-15",
			IsGoodwillEnabled: false,
			LastPaymentDate:   "2025-12-01",
			PaidAmount:        100.00,
			PurposeCode:       "DEF",
			ScheduleAmount:    33.33,
			Status:            "PENDING",
			TypeCode:          "DEFERRED",
		},
	}
}

func TestGetAccount(t *testing.T) {
	tests := []struct {
		name               string
		body               string // JSON body sent in the POST request
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, body []byte)
	}{
		{
			name:          "invalid JSON body returns 400",
			body:          `not-json`,
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "request body must be a valid accountCriteria JSON object" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty body returns 400",
			body:          ``,
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 502",
			body:          `{}`,
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccount(gomock.Any(), gomock.Any()).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 401 unauthorized",
			body:          `{}`,
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccount(gomock.Any(), gomock.Any()).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - context deadline exceeded",
			body:          `{}`,
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccount(gomock.Any(), gomock.Any()).
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns generic error - 500",
			body:          `{}`,
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccount(gomock.Any(), gomock.Any()).
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns empty accounts - 404",
			body:          `{}`,
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccount(gomock.Any(), gomock.Any()).
					Return([]coreEntities.Account{}, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "account not found" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "valid criteria returns 200 with account data",
			body:          `{"accountId": 10}`,
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetAccount(gomock.Any(), gomock.Any()).
					Return(sampleCoreAccounts(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.AccountResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 2 {
					t.Fatalf("expected 2 items in data array, got %d", len(wrapper.Data))
				}
				if wrapper.Data[0].AccountId != 10 {
					t.Errorf("expected AccountId 10, got %d", wrapper.Data[0].AccountId)
				}
				if wrapper.Data[0].AccountNo != "ACC-010" {
					t.Errorf("expected AccountNo ACC-010, got %s", wrapper.Data[0].AccountNo)
				}
			},
		},
		{
			name:          "development mode includes error details on invalid body",
			body:          `bad-json`,
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			body:          `{}`,
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccount(gomock.Any(), gomock.Any()).
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
		{
			name:          "development mode includes error details on repository error",
			body:          `{}`,
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccount(gomock.Any(), gomock.Any()).
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "upstream 429 rate limit returns 429",
			body:          `{}`,
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccount(gomock.Any(), gomock.Any()).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "nil repository return treated as empty - 404",
			body:          `{}`,
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccount(gomock.Any(), gomock.Any()).
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockIAccountRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			tt.setupMocks(mockRepo, mockLogger)

			accountCtrl := newTestAccountController(t, mockRepo, mockLogger, tt.isDevelopment)

			req := newPostRequest(t, tt.body)
			rr := httptest.NewRecorder()

			accountCtrl.GetAccount(rr, req)

			if rr.Code != tt.expectedStatusCode {
				t.Errorf("expected status %d, got %d", tt.expectedStatusCode, rr.Code)
			}

			contentType := rr.Header().Get("Content-Type")
			if contentType != "application/json" {
				t.Errorf("expected Content-Type application/json, got %s", contentType)
			}

			if tt.validateBody != nil {
				tt.validateBody(t, rr.Body.Bytes())
			}
		})
	}
}

func TestGetAccountBalance(t *testing.T) {
	tests := []struct {
		name               string
		query              string // query string appended to /account/accountBalance
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, body []byte)
	}{
		{
			name:          "missing accountId query parameter returns 400",
			query:         "",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "accountId query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty accountId query parameter returns 400",
			query:         "?accountId=",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "non-numeric accountId returns 400",
			query:         "?accountId=abc",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "accountId must be a valid positive integer" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "negative accountId returns 400",
			query:         "?accountId=-1",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "float accountId returns 400",
			query:         "?accountId=3.14",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 502",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountBalance(gomock.Any(), uint64(42)).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 401 unauthorized",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountBalance(gomock.Any(), uint64(42)).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - context deadline exceeded",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountBalance(gomock.Any(), uint64(42)).
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns generic error - 500",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountBalance(gomock.Any(), uint64(42)).
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns nil account balance - 404",
			query:         "?accountId=999",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountBalance(gomock.Any(), uint64(999)).
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "account balance not found" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "valid accountId returns 200 with account balance data",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetAccountBalance(gomock.Any(), uint64(42)).
					Return(sampleCoreAccountBalance(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.AccountBalanceResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 1 {
					t.Fatalf("expected 1 item in data array, got %d", len(wrapper.Data))
				}
				resp := wrapper.Data[0]
				if resp.Total != 250.75 {
					t.Errorf("expected Total 250.75, got %f", resp.Total)
				}
				if resp.Current != 100.00 {
					t.Errorf("expected Current 100.00, got %f", resp.Current)
				}
				if resp.VendorName != "Test Vendor" {
					t.Errorf("expected VendorName 'Test Vendor', got %s", resp.VendorName)
				}
				if resp.TransactionGroupingType != "STANDARD" {
					t.Errorf("expected TransactionGroupingType 'STANDARD', got %s", resp.TransactionGroupingType)
				}
			},
		},
		{
			name:          "development mode includes error details on 400",
			query:         "?accountId=abc",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountBalance(gomock.Any(), uint64(42)).
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
		{
			name:          "development mode includes error details on repository error",
			query:         "?accountId=42",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountBalance(gomock.Any(), uint64(42)).
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "upstream 429 rate limit returns 429",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountBalance(gomock.Any(), uint64(42)).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "zero accountId is valid and calls repository",
			query:         "?accountId=0",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetAccountBalance(gomock.Any(), uint64(0)).
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockIAccountRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			tt.setupMocks(mockRepo, mockLogger)

			accountCtrl := newTestAccountController(t, mockRepo, mockLogger, tt.isDevelopment)

			req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, "/account/accountBalance"+tt.query, nil)
			if err != nil {
				t.Fatalf("failed to create request: %v", err)
			}
			rr := httptest.NewRecorder()

			accountCtrl.GetAccountBalance(rr, req)

			if rr.Code != tt.expectedStatusCode {
				t.Errorf("expected status %d, got %d", tt.expectedStatusCode, rr.Code)
			}

			contentType := rr.Header().Get("Content-Type")
			if contentType != "application/json" {
				t.Errorf("expected Content-Type application/json, got %s", contentType)
			}

			if tt.validateBody != nil {
				tt.validateBody(t, rr.Body.Bytes())
			}
		})
	}
}

func TestGetPaymentArrangement(t *testing.T) {
	tests := []struct {
		name               string
		query              string // query string appended to /account/paymentArrangement
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, body []byte)
	}{
		{
			name:          "missing accountId query parameter returns 400",
			query:         "",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "accountId query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty accountId query parameter returns 400",
			query:         "?accountId=",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "non-numeric accountId returns 400",
			query:         "?accountId=abc",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "accountId must be a valid positive integer" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "negative accountId returns 400",
			query:         "?accountId=-1",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "float accountId returns 400",
			query:         "?accountId=3.14",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 502",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentArrangement(gomock.Any(), uint64(42)).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 401 unauthorized",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentArrangement(gomock.Any(), uint64(42)).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - context deadline exceeded",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentArrangement(gomock.Any(), uint64(42)).
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns generic error - 500",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentArrangement(gomock.Any(), uint64(42)).
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns empty list - 404",
			query:         "?accountId=999",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentArrangement(gomock.Any(), uint64(999)).
					Return([]coreEntities.PaymentArrangement{}, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "payment arrangement not found" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "repository returns nil list - 404",
			query:         "?accountId=999",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentArrangement(gomock.Any(), uint64(999)).
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "valid accountId returns 200 with payment arrangement data",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetPaymentArrangement(gomock.Any(), uint64(42)).
					Return(sampleCorePaymentArrangements(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.PaymentArrangementResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 2 {
					t.Fatalf("expected 2 items in data array, got %d", len(wrapper.Data))
				}
				resp := wrapper.Data[0]
				if resp.AcctId != 42 {
					t.Errorf("expected AcctId 42, got %d", resp.AcctId)
				}
				if resp.Amount != 500.00 {
					t.Errorf("expected Amount 500.00, got %f", resp.Amount)
				}
				if resp.Status != "ACTIVE" {
					t.Errorf("expected Status 'ACTIVE', got %s", resp.Status)
				}
				if resp.TypeCode != "INSTALLMENT" {
					t.Errorf("expected TypeCode 'INSTALLMENT', got %s", resp.TypeCode)
				}
				if resp.Duration != 12 {
					t.Errorf("expected Duration 12, got %d", resp.Duration)
				}
				if resp.PaidAmount != 250.00 {
					t.Errorf("expected PaidAmount 250.00, got %f", resp.PaidAmount)
				}
				if resp.ScheduleAmount != 41.67 {
					t.Errorf("expected ScheduleAmount 41.67, got %f", resp.ScheduleAmount)
				}
			},
		},
		{
			name:          "development mode includes error details on 400",
			query:         "?accountId=abc",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentArrangement(gomock.Any(), uint64(42)).
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
		{
			name:          "development mode includes error details on repository error",
			query:         "?accountId=42",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentArrangement(gomock.Any(), uint64(42)).
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "upstream 429 rate limit returns 429",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentArrangement(gomock.Any(), uint64(42)).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "zero accountId is valid and calls repository",
			query:         "?accountId=0",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentArrangement(gomock.Any(), uint64(0)).
					Return([]coreEntities.PaymentArrangement{}, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockIAccountRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			tt.setupMocks(mockRepo, mockLogger)

			accountCtrl := newTestAccountController(t, mockRepo, mockLogger, tt.isDevelopment)

			req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, "/account/paymentArrangement"+tt.query, nil)
			if err != nil {
				t.Fatalf("failed to create request: %v", err)
			}
			rr := httptest.NewRecorder()

			accountCtrl.GetPaymentArrangement(rr, req)

			if rr.Code != tt.expectedStatusCode {
				t.Errorf("expected status %d, got %d", tt.expectedStatusCode, rr.Code)
			}

			contentType := rr.Header().Get("Content-Type")
			if contentType != "application/json" {
				t.Errorf("expected Content-Type application/json, got %s", contentType)
			}

			if tt.validateBody != nil {
				tt.validateBody(t, rr.Body.Bytes())
			}
		})
	}
}

// sampleCoreInvoiceDistributionInfos returns a slice of core InvoiceDistributionInfo used in success scenarios.
func sampleCoreInvoiceDistributionInfos() []coreEntities.InvoiceDistributionInfo {
	return []coreEntities.InvoiceDistributionInfo{
		{
			AddressID:       10,
			Attn:            "John Doe",
			City:            "Houston",
			Country:         "US",
			County:          "Harris",
			DistType:        "MAIL",
			EmailAddr:       "john.doe@example.com",
			FormatType:      "PDF",
			InvDistType:     "PRIMARY",
			Line1:           "123 Main St",
			Line2:           "Suite 100",
			Name:            "John Doe",
			PostalCode:      "77001",
			RelateClassName: "Account",
			RelateId:        42,
			State:           "TX",
		},
		{
			AddressID:       11,
			Attn:            "Jane Smith",
			City:            "Dallas",
			Country:         "US",
			County:          "Dallas",
			DistType:        "EMAIL",
			EmailAddr:       "jane.smith@example.com",
			FormatType:      "PDF",
			InvDistType:     "SECONDARY",
			Line1:           "456 Oak Ave",
			Line2:           "",
			Name:            "Jane Smith",
			PostalCode:      "75201",
			RelateClassName: "Account",
			RelateId:        42,
			State:           "TX",
		},
	}
}

func TestGetInvoiceDistribution(t *testing.T) {
	tests := []struct {
		name               string
		query              string
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, body []byte)
	}{
		{
			name:          "missing accountId query parameter returns 400",
			query:         "",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "accountId query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty accountId query parameter returns 400",
			query:         "?accountId=",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "non-numeric accountId returns 400",
			query:         "?accountId=abc",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "accountId must be a valid positive integer" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "negative accountId returns 400",
			query:         "?accountId=-1",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "float accountId returns 400",
			query:         "?accountId=3.14",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 502",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoiceDistribution(gomock.Any(), uint64(42)).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 401 unauthorized",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoiceDistribution(gomock.Any(), uint64(42)).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - context deadline exceeded returns 504",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoiceDistribution(gomock.Any(), uint64(42)).
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns generic error - 500",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoiceDistribution(gomock.Any(), uint64(42)).
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns empty list - 404",
			query:         "?accountId=999",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoiceDistribution(gomock.Any(), uint64(999)).
					Return([]coreEntities.InvoiceDistributionInfo{}, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "invoice distribution not found" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "repository returns nil list - 404",
			query:         "?accountId=999",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoiceDistribution(gomock.Any(), uint64(999)).
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "valid accountId returns 200 with invoice distribution data",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetInvoiceDistribution(gomock.Any(), uint64(42)).
					Return(sampleCoreInvoiceDistributionInfos(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.InvoiceDistributionInfoResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 2 {
					t.Fatalf("expected 2 items in data array, got %d", len(wrapper.Data))
				}
				first := wrapper.Data[0]
				if first.AddressID != 10 {
					t.Errorf("expected AddressID 10, got %d", first.AddressID)
				}
				if first.City != "Houston" {
					t.Errorf("expected City 'Houston', got %s", first.City)
				}
				if first.State != "TX" {
					t.Errorf("expected State 'TX', got %s", first.State)
				}
				if first.DistType != "MAIL" {
					t.Errorf("expected DistType 'MAIL', got %s", first.DistType)
				}
				if first.InvDistType != "PRIMARY" {
					t.Errorf("expected InvDistType 'PRIMARY', got %s", first.InvDistType)
				}
				if first.EmailAddr != "john.doe@example.com" {
					t.Errorf("expected EmailAddr 'john.doe@example.com', got %s", first.EmailAddr)
				}
				if first.PostalCode != "77001" {
					t.Errorf("expected PostalCode '77001', got %s", first.PostalCode)
				}
				if first.RelateId != 42 {
					t.Errorf("expected RelateId 42, got %d", first.RelateId)
				}
				if first.Name != "John Doe" {
					t.Errorf("expected Name 'John Doe', got %s", first.Name)
				}
			},
		},
		{
			name:          "upstream 429 rate limit returns 429",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoiceDistribution(gomock.Any(), uint64(42)).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "development mode includes error details on 400",
			query:         "?accountId=abc",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoiceDistribution(gomock.Any(), uint64(42)).
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
		{
			name:          "development mode includes error details on repository error",
			query:         "?accountId=42",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoiceDistribution(gomock.Any(), uint64(42)).
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "zero accountId is valid and calls repository",
			query:         "?accountId=0",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoiceDistribution(gomock.Any(), uint64(0)).
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "upstream 403 forbidden maps to 404 not found",
			query:         "?accountId=42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoiceDistribution(gomock.Any(), uint64(42)).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusForbidden,
						Message:    "forbidden",
						Err:        errors.New("access denied"),
					})
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockIAccountRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			tt.setupMocks(mockRepo, mockLogger)

			accountCtrl := newTestAccountController(t, mockRepo, mockLogger, tt.isDevelopment)

			req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, "/account/getInvoiceDistribution"+tt.query, nil)
			if err != nil {
				t.Fatalf("failed to create request: %v", err)
			}
			rr := httptest.NewRecorder()

			accountCtrl.GetInvoiceDistribution(rr, req)

			if rr.Code != tt.expectedStatusCode {
				t.Errorf("expected status %d, got %d", tt.expectedStatusCode, rr.Code)
			}

			contentType := rr.Header().Get("Content-Type")
			if contentType != "application/json" {
				t.Errorf("expected Content-Type application/json, got %s", contentType)
			}

			if tt.validateBody != nil {
				tt.validateBody(t, rr.Body.Bytes())
			}
		})
	}
}
