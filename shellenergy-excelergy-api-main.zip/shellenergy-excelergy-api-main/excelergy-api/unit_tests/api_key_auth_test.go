package unit_tests

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/middleware"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/unit_tests/mocks"

	"go.uber.org/mock/gomock"
)

const testAPIKey = "test-secret-key-12345"

// newAPIKeyAuthMiddleware creates an APIKeyAuth middleware for testing.
func newAPIKeyAuthMiddleware(
	t *testing.T,
	apiKey string,
	isDevelopment bool,
) middleware.IAPIKeyAuth {
	t.Helper()

	ctrl := gomock.NewController(t)
	mockCfg := mocks.NewMockIAuthConfig(ctrl)
	mockCfg.EXPECT().GetAPIKey().Return(apiKey).AnyTimes()
	mockCfg.EXPECT().IsDevelopment().Return(isDevelopment).AnyTimes()

	mockLogger := mocks.NewMockILogger(ctrl)
	mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()

	return middleware.NewAPIKeyAuth(mockCfg, mockLogger)
}

// dummyHandler is a simple handler that returns 200 OK when reached.
var dummyHandler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
})

func TestAPIKeyAuthMiddleware(t *testing.T) {
	tests := []struct {
		name               string
		path               string
		apiKeyHeader       string // value for X-API-Key header; empty means omit header
		isDevelopment      bool
		expectedStatusCode int
		validateBody       func(t *testing.T, body []byte)
	}{
		{
			name:               "missing X-API-Key header returns 401",
			path:               "/account?accountId=1",
			apiKeyHeader:       "",
			isDevelopment:      false,
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "API key is required. Provide a valid key via the X-API-Key header." {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:               "invalid X-API-Key header returns 401",
			path:               "/account?accountId=1",
			apiKeyHeader:       "wrong-key",
			isDevelopment:      false,
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "invalid API key" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:               "valid X-API-Key header passes through to handler",
			path:               "/account?accountId=1",
			apiKeyHeader:       testAPIKey,
			isDevelopment:      false,
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var resp map[string]string
				if err := json.Unmarshal(body, &resp); err != nil {
					t.Fatalf("failed to unmarshal response: %v", err)
				}
				if resp["status"] != "ok" {
					t.Errorf("expected status 'ok', got %s", resp["status"])
				}
			},
		},
		{
			name:               "health endpoint is exempt - no API key required",
			path:               "/health",
			apiKeyHeader:       "",
			isDevelopment:      false,
			expectedStatusCode: http.StatusOK,
			validateBody:       nil,
		},
		{
			name:               "health/ready endpoint is exempt",
			path:               "/health/ready",
			apiKeyHeader:       "",
			isDevelopment:      false,
			expectedStatusCode: http.StatusOK,
			validateBody:       nil,
		},
		{
			name:               "health/live endpoint is exempt",
			path:               "/health/live",
			apiKeyHeader:       "",
			isDevelopment:      false,
			expectedStatusCode: http.StatusOK,
			validateBody:       nil,
		},
		{
			name:               "swagger endpoint is exempt - no API key required",
			path:               "/swagger/index.html",
			apiKeyHeader:       "",
			isDevelopment:      false,
			expectedStatusCode: http.StatusOK,
			validateBody:       nil,
		},
		{
			name:               "customer endpoint without key returns 401",
			path:               "/customer?customerId=1",
			apiKeyHeader:       "",
			isDevelopment:      false,
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:               "customer endpoint with valid key returns 200",
			path:               "/customer?customerId=1",
			apiKeyHeader:       testAPIKey,
			isDevelopment:      false,
			expectedStatusCode: http.StatusOK,
			validateBody:       nil,
		},
		{
			name:               "empty string API key in header is treated as missing",
			path:               "/account?accountId=1",
			apiKeyHeader:       "",
			isDevelopment:      false,
			expectedStatusCode: http.StatusUnauthorized,
			validateBody:       nil,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			auth := newAPIKeyAuthMiddleware(t, testAPIKey, tt.isDevelopment)

			// Wrap the dummy handler with the middleware
			handler := auth.Middleware(dummyHandler)

			req := httptest.NewRequest(http.MethodGet, tt.path, nil)
			if tt.apiKeyHeader != "" {
				req.Header.Set("X-API-Key", tt.apiKeyHeader)
			}
			rr := httptest.NewRecorder()

			handler.ServeHTTP(rr, req)

			// Assert status code
			if rr.Code != tt.expectedStatusCode {
				t.Errorf("expected status %d, got %d", tt.expectedStatusCode, rr.Code)
			}

			// Assert Content-Type
			contentType := rr.Header().Get("Content-Type")
			if contentType != "application/json" {
				t.Errorf("expected Content-Type application/json, got %s", contentType)
			}

			// Run custom body validations
			if tt.validateBody != nil {
				tt.validateBody(t, rr.Body.Bytes())
			}
		})
	}
}
