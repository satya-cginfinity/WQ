package unit_tests

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/controllers"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/unit_tests/mocks"
	core_entities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"

	"go.uber.org/mock/gomock"
)

// newInvoiceGetRequest builds an *http.Request for the /invoice/downloadPdf endpoint
// with the provided query string appended.
func newInvoiceGetRequest(t *testing.T, query string) *http.Request {
	t.Helper()
	req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, "/api/v1/invoice/downloadPdf"+query, nil)
	if err != nil {
		t.Fatalf("failed to create request: %v", err)
	}
	return req
}

// newTestInvoiceController creates an InvoiceController through the exported
// constructor, wiring in the provided mock dependencies.
func newTestInvoiceController(
	t *testing.T,
	mockRepo *mocks.MockIInvoiceRepository,
	mockLogger *mocks.MockILogger,
	isDevelopment bool,
) controllers.IInvoiceController {
	t.Helper()

	ctrl := gomock.NewController(t)
	mockCfg := mocks.NewMockIClientConfig(ctrl)
	mockCfg.EXPECT().IsDevelopment().Return(isDevelopment).AnyTimes()

	c := controllers.NewInvoiceController(mockLogger, mockRepo, nil, mockCfg)
	invoiceCtrl, ok := c.(controllers.IInvoiceController)
	if !ok {
		t.Fatal("NewInvoiceController did not return an IInvoiceController")
	}
	return invoiceCtrl
}

func TestDownloadInvoicePdf(t *testing.T) {
	tests := []struct {
		name               string
		query              string
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, rr *httptest.ResponseRecorder)
	}{
		// ---------------------------------------------------------------
		// 400 – Missing / empty query parameters
		// ---------------------------------------------------------------
		{
			name:          "missing billingAccountNo returns 400",
			query:         "?billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "billingAccountNo query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty billingAccountNo returns 400",
			query:         "?billingAccountNo=&billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "billingAccountNo query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "missing billingMonth returns 400",
			query:         "?billingAccountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "billingMonth query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty billingMonth returns 400",
			query:         "?billingAccountNo=ACC-001&billingMonth=",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "billingMonth query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "both parameters missing returns 400 for billingAccountNo first",
			query:         "",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "billingAccountNo query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},

		// ---------------------------------------------------------------
		// 404 – PDF not found (empty byte slice returned by repository)
		// ---------------------------------------------------------------
		{
			name:          "repository returns empty bytes - 404",
			query:         "?billingAccountNo=ACC-001&billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-001", "2024-01").
					Return([]byte{}, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "invoice PDF not found" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "repository returns nil bytes - 404",
			query:         "?billingAccountNo=ACC-001&billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-001", "2024-01").
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},

		// ---------------------------------------------------------------
		// 200 – Successful PDF download
		// ---------------------------------------------------------------
		{
			name:          "valid request returns 200 with PDF content",
			query:         "?billingAccountNo=ACC-001&billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-001", "2024-01").
					Return([]byte("%PDF-1.4 sample content"), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				if rr.Header().Get("Content-Type") != "application/pdf" {
					t.Errorf("expected Content-Type application/pdf, got %s", rr.Header().Get("Content-Type"))
				}
				expectedFilename := `attachment; filename="invoice_ACC-001_2024-01.pdf"`
				if rr.Header().Get("Content-Disposition") != expectedFilename {
					t.Errorf("expected Content-Disposition %q, got %q", expectedFilename, rr.Header().Get("Content-Disposition"))
				}
				body := rr.Body.Bytes()
				if len(body) == 0 {
					t.Error("expected non-empty PDF body")
				}
				expectedLength := fmt.Sprintf("%d", len(body))
				if rr.Header().Get("Content-Length") != expectedLength {
					t.Errorf("expected Content-Length %s, got %s", expectedLength, rr.Header().Get("Content-Length"))
				}
			},
		},
		{
			name:          "response body matches repository bytes exactly",
			query:         "?billingAccountNo=ACC-999&billingMonth=2023-12",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-999", "2023-12").
					Return([]byte{0x25, 0x50, 0x44, 0x46}, nil) // %PDF magic bytes
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				expected := []byte{0x25, 0x50, 0x44, 0x46}
				if !bytes.Equal(rr.Body.Bytes(), expected) {
					t.Errorf("response body does not match expected PDF bytes")
				}
			},
		},
		{
			name:          "filename includes billingAccountNo and billingMonth",
			query:         "?billingAccountNo=BILL-123&billingMonth=2025-06",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "BILL-123", "2025-06").
					Return([]byte("pdf data"), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				expected := `attachment; filename="invoice_BILL-123_2025-06.pdf"`
				if rr.Header().Get("Content-Disposition") != expected {
					t.Errorf("expected Content-Disposition %q, got %q", expected, rr.Header().Get("Content-Disposition"))
				}
			},
		},

		// ---------------------------------------------------------------
		// Repository error cases
		// ---------------------------------------------------------------
		{
			name:          "repository returns generic error - 500",
			query:         "?billingAccountNo=ACC-001&billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-001", "2024-01").
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns upstream 401 unauthorized - 401",
			query:         "?billingAccountNo=ACC-001&billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-001", "2024-01").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns upstream 403 forbidden - 404 (classified as not found)",
			query:         "?billingAccountNo=ACC-001&billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-001", "2024-01").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusForbidden,
						Message:    "forbidden",
						Err:        errors.New("access denied"),
					})
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns upstream 404 not found - 404",
			query:         "?billingAccountNo=ACC-001&billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-001", "2024-01").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusNotFound,
						Message:    "not found in upstream",
						Err:        errors.New("resource missing"),
					})
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns upstream 429 rate limit - 429",
			query:         "?billingAccountNo=ACC-001&billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-001", "2024-01").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns upstream 502 bad gateway - 502",
			query:         "?billingAccountNo=ACC-001&billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-001", "2024-01").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns context deadline exceeded - 504",
			query:         "?billingAccountNo=ACC-001&billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-001", "2024-01").
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns context canceled - 504",
			query:         "?billingAccountNo=ACC-001&billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-001", "2024-01").
					Return(nil, context.Canceled)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},

		// ---------------------------------------------------------------
		// Development mode error details
		// ---------------------------------------------------------------
		{
			name:          "development mode includes error details on repository error",
			query:         "?billingAccountNo=ACC-001&billingMonth=2024-01",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-001", "2024-01").
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			query:         "?billingAccountNo=ACC-001&billingMonth=2024-01",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					DownloadInvoicePdf(gomock.Any(), "ACC-001", "2024-01").
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockIInvoiceRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			tc.setupMocks(mockRepo, mockLogger)

			invoiceCtrl := newTestInvoiceController(t, mockRepo, mockLogger, tc.isDevelopment)

			req := newInvoiceGetRequest(t, tc.query)
			rr := httptest.NewRecorder()

			invoiceCtrl.DownloadInvoicePdf(rr, req)

			if rr.Code != tc.expectedStatusCode {
				t.Errorf("expected status code %d, got %d", tc.expectedStatusCode, rr.Code)
			}

			tc.validateBody(t, rr)
		})
	}
}

// newGetInvoicesRequest builds an *http.Request for the /api/v1/invoice/getInvoices endpoint.
func newGetInvoicesRequest(t *testing.T, query string) *http.Request {
	t.Helper()
	req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, "/api/v1/invoice/getInvoices"+query, nil)
	if err != nil {
		t.Fatalf("failed to create request: %v", err)
	}
	return req
}

func TestGetInvoices(t *testing.T) {
	tests := []struct {
		name               string
		query              string
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, rr *httptest.ResponseRecorder)
	}{
		// ---------------------------------------------------------------
		// 400 – Missing / empty required parameter
		// ---------------------------------------------------------------
		{
			name:          "missing accountNo returns 400",
			query:         "",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "accountNo query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty accountNo returns 400",
			query:         "?accountNo=",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "accountNo query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},

		// ---------------------------------------------------------------
		// 200 – Successful responses
		// ---------------------------------------------------------------
		{
			name:          "valid accountNo returns 200 with invoices",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetInvoices(gomock.Any(), "ACC-001", "").
					Return([]core_entities.Invoice{{InvoiceId: 1, InvoiceNumber: "INV-001"}}, nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				if rr.Header().Get("Content-Type") != "application/json" {
					t.Errorf("expected Content-Type application/json, got %s", rr.Header().Get("Content-Type"))
				}
				var resp map[string]interface{}
				if err := json.Unmarshal(rr.Body.Bytes(), &resp); err != nil {
					t.Fatalf("failed to unmarshal response: %v", err)
				}
				data, ok := resp["data"]
				if !ok {
					t.Fatal("expected 'data' key in response")
				}
				invoices, ok := data.([]interface{})
				if !ok || len(invoices) == 0 {
					t.Error("expected at least one invoice in data array")
				}
			},
		},
		{
			name:          "valid accountNo with invoiceNo returns 200",
			query:         "?accountNo=ACC-001&invoiceNo=INV-42",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetInvoices(gomock.Any(), "ACC-001", "INV-42").
					Return([]core_entities.Invoice{{InvoiceId: 42, InvoiceNumber: "INV-42"}}, nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var resp map[string]interface{}
				if err := json.Unmarshal(rr.Body.Bytes(), &resp); err != nil {
					t.Fatalf("failed to unmarshal response: %v", err)
				}
				data, ok := resp["data"].([]interface{})
				if !ok || len(data) != 1 {
					t.Errorf("expected exactly 1 invoice in data, got %v", resp["data"])
				}
			},
		},
		{
			name:          "repository returns empty slice - 200 with empty data",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetInvoices(gomock.Any(), "ACC-001", "").
					Return([]core_entities.Invoice{}, nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var resp map[string]interface{}
				if err := json.Unmarshal(rr.Body.Bytes(), &resp); err != nil {
					t.Fatalf("failed to unmarshal response: %v", err)
				}
				data, ok := resp["data"].([]interface{})
				if !ok || len(data) != 0 {
					t.Errorf("expected empty data array, got %v", resp["data"])
				}
			},
		},

		// ---------------------------------------------------------------
		// Repository error cases
		// ---------------------------------------------------------------
		{
			name:          "repository returns generic error - 500",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoices(gomock.Any(), "ACC-001", "").
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns upstream 401 unauthorized - 401",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoices(gomock.Any(), "ACC-001", "").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns upstream 404 not found - 404",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoices(gomock.Any(), "ACC-001", "").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusNotFound,
						Message:    "not found",
						Err:        errors.New("resource missing"),
					})
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns upstream 429 rate limit - 429",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoices(gomock.Any(), "ACC-001", "").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns upstream 502 bad gateway - 502",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoices(gomock.Any(), "ACC-001", "").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns context deadline exceeded - 504",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoices(gomock.Any(), "ACC-001", "").
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},

		// ---------------------------------------------------------------
		// Development mode
		// ---------------------------------------------------------------
		{
			name:          "development mode includes error details on repository error",
			query:         "?accountNo=ACC-001",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoices(gomock.Any(), "ACC-001", "").
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetInvoices(gomock.Any(), "ACC-001", "").
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockIInvoiceRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			tc.setupMocks(mockRepo, mockLogger)

			invoiceCtrl := newTestInvoiceController(t, mockRepo, mockLogger, tc.isDevelopment)

			req := newGetInvoicesRequest(t, tc.query)
			rr := httptest.NewRecorder()

			invoiceCtrl.GetInvoices(rr, req)

			if rr.Code != tc.expectedStatusCode {
				t.Errorf("expected status code %d, got %d", tc.expectedStatusCode, rr.Code)
			}

			tc.validateBody(t, rr)
		})
	}
}

// newGetPaymentHistoryRequest builds an *http.Request for the /api/v1/invoice/getPaymentHistory endpoint.
func newGetPaymentHistoryRequest(t *testing.T, query string) *http.Request {
	t.Helper()
	req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, "/api/v1/invoice/getPaymentHistory"+query, nil)
	if err != nil {
		t.Fatalf("failed to create request: %v", err)
	}
	return req
}

func TestGetPaymentHistory(t *testing.T) {
	tests := []struct {
		name               string
		query              string
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, rr *httptest.ResponseRecorder)
	}{
		// ---------------------------------------------------------------
		// 400 – Missing / empty required parameter
		// ---------------------------------------------------------------
		{
			name:          "missing accountNo returns 400",
			query:         "",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "accountNo query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty accountNo returns 400",
			query:         "?accountNo=",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "accountNo query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "invalid returnLimit returns 400",
			query:         "?accountNo=ACC-001&returnLimit=abc",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "returnLimit must be a valid integer" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},

		// ---------------------------------------------------------------
		// 404 – Payment history not found (nil returned by repository)
		// ---------------------------------------------------------------
		{
			name:          "repository returns nil - 404",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentHistory(gomock.Any(), "ACC-001", "", "", "", 100).
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "payment history not found" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},

		// ---------------------------------------------------------------
		// 200 – Successful responses
		// ---------------------------------------------------------------
		{
			name:          "valid accountNo with default returnLimit returns 200",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetPaymentHistory(gomock.Any(), "ACC-001", "", "", "", 100).
					Return(&core_entities.PaymentHistory{
						TotalFound:    1,
						TotalReturned: 1,
						AccountNumber: "ACC-001",
						Payments: []*core_entities.Payment{
							{TransactionId: 1001, Date: "2024-01-15", Amount: 150.00, TransactionSubType: "PAYMENT"},
						},
					}, nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				if rr.Header().Get("Content-Type") != "application/json" {
					t.Errorf("expected Content-Type application/json, got %s", rr.Header().Get("Content-Type"))
				}
				var resp map[string]interface{}
				if err := json.Unmarshal(rr.Body.Bytes(), &resp); err != nil {
					t.Fatalf("failed to unmarshal response: %v", err)
				}
				data, ok := resp["data"]
				if !ok {
					t.Fatal("expected 'data' key in response")
				}
				items, ok := data.([]interface{})
				if !ok || len(items) == 0 {
					t.Error("expected at least one item in data array")
				}
			},
		},
		{
			name:          "valid request with all optional parameters returns 200",
			query:         "?accountNo=ACC-001&transactionType=PAYMENT&fromDate=2024-01-01&toDate=2024-12-31&returnLimit=50",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetPaymentHistory(gomock.Any(), "ACC-001", "PAYMENT", "2024-01-01", "2024-12-31", 50).
					Return(&core_entities.PaymentHistory{
						TotalFound:    2,
						TotalReturned: 2,
						AccountNumber: "ACC-001",
						Payments: []*core_entities.Payment{
							{TransactionId: 1001, Date: "2024-01-15", Amount: 150.00, TransactionSubType: "PAYMENT"},
							{TransactionId: 1002, Date: "2024-06-20", Amount: 200.00, TransactionSubType: "PAYMENT"},
						},
					}, nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var resp map[string]interface{}
				if err := json.Unmarshal(rr.Body.Bytes(), &resp); err != nil {
					t.Fatalf("failed to unmarshal response: %v", err)
				}
				data, ok := resp["data"].([]interface{})
				if !ok || len(data) != 1 {
					t.Errorf("expected exactly 1 payment history in data, got %v", resp["data"])
				}
			},
		},
		{
			name:          "response includes payment history fields correctly",
			query:         "?accountNo=ACC-002&returnLimit=10",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetPaymentHistory(gomock.Any(), "ACC-002", "", "", "", 10).
					Return(&core_entities.PaymentHistory{
						TotalFound:    1,
						TotalReturned: 1,
						AccountNumber: "ACC-002",
						Payments: []*core_entities.Payment{
							{
								TransactionId:      2001,
								Date:               "2024-03-10",
								Amount:             99.99,
								TransactionSubType: "CREDIT",
								Cancelled: &core_entities.CancelledInfo{
									Value:    "Y",
									InCancel: "N",
								},
							},
						},
					}, nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var resp map[string]interface{}
				if err := json.Unmarshal(rr.Body.Bytes(), &resp); err != nil {
					t.Fatalf("failed to unmarshal response: %v", err)
				}
				data, ok := resp["data"].([]interface{})
				if !ok || len(data) != 1 {
					t.Fatalf("expected 1 item in data, got %v", resp["data"])
				}
				history, ok := data[0].(map[string]interface{})
				if !ok {
					t.Fatal("expected payment history object in data")
				}
				if history["accountNumber"] != "ACC-002" {
					t.Errorf("expected accountNumber ACC-002, got %v", history["accountNumber"])
				}
				payments, ok := history["payments"].([]interface{})
				if !ok || len(payments) != 1 {
					t.Fatalf("expected 1 payment, got %v", history["payments"])
				}
				payment, ok := payments[0].(map[string]interface{})
				if !ok {
					t.Fatal("expected payment object")
				}
				if payment["transactionSubType"] != "CREDIT" {
					t.Errorf("expected transactionSubType CREDIT, got %v", payment["transactionSubType"])
				}
				cancelled, ok := payment["cancelled"].(map[string]interface{})
				if !ok {
					t.Fatal("expected cancelled object in payment")
				}
				if cancelled["value"] != "Y" {
					t.Errorf("expected cancelled value Y, got %v", cancelled["value"])
				}
			},
		},

		// ---------------------------------------------------------------
		// Repository error cases
		// ---------------------------------------------------------------
		{
			name:          "repository returns generic error - 500",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentHistory(gomock.Any(), "ACC-001", "", "", "", 100).
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns upstream 401 unauthorized - 401",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentHistory(gomock.Any(), "ACC-001", "", "", "", 100).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns upstream 404 not found - 404",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentHistory(gomock.Any(), "ACC-001", "", "", "", 100).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusNotFound,
						Message:    "not found",
						Err:        errors.New("resource missing"),
					})
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns upstream 429 rate limit - 429",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentHistory(gomock.Any(), "ACC-001", "", "", "", 100).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns upstream 502 bad gateway - 502",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentHistory(gomock.Any(), "ACC-001", "", "", "", 100).
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns context deadline exceeded - 504",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentHistory(gomock.Any(), "ACC-001", "", "", "", 100).
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns context canceled - 504",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentHistory(gomock.Any(), "ACC-001", "", "", "", 100).
					Return(nil, context.Canceled)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},

		// ---------------------------------------------------------------
		// Development mode
		// ---------------------------------------------------------------
		{
			name:          "development mode includes error details on repository error",
			query:         "?accountNo=ACC-001",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentHistory(gomock.Any(), "ACC-001", "", "", "", 100).
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			query:         "?accountNo=ACC-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIInvoiceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetPaymentHistory(gomock.Any(), "ACC-001", "", "", "", 100).
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, rr *httptest.ResponseRecorder) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(rr.Body.Bytes(), &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockIInvoiceRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			tc.setupMocks(mockRepo, mockLogger)

			invoiceCtrl := newTestInvoiceController(t, mockRepo, mockLogger, tc.isDevelopment)

			req := newGetPaymentHistoryRequest(t, tc.query)
			rr := httptest.NewRecorder()

			invoiceCtrl.GetPaymentHistory(rr, req)

			if rr.Code != tc.expectedStatusCode {
				t.Errorf("expected status code %d, got %d", tc.expectedStatusCode, rr.Code)
			}

			tc.validateBody(t, rr)
		})
	}
}
