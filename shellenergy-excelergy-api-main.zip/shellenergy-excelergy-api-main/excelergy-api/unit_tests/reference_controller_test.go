package unit_tests

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/controllers"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/unit_tests/mocks"
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"

	"go.uber.org/mock/gomock"
)

// helper: build an *http.Request with the given query string for reference endpoints.
func newReferenceGetRequest(t *testing.T, query string) *http.Request {
	t.Helper()
	req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, "/reference"+query, nil)
	if err != nil {
		t.Fatalf("failed to create request: %v", err)
	}
	return req
}

// sampleCoreReferenceCodes returns a slice of core ReferenceCode used in success scenarios.
func sampleCoreReferenceCodes() []coreEntities.ReferenceCode {
	return []coreEntities.ReferenceCode{
		{
			Code:             "REF-001",
			Default:          true,
			DisplayCode:      "R001",
			DisplayName:      "Reference One",
			DomainName:       "BILLING",
			EDICode:          "EDI001",
			IsActive:         true,
			IsChecked:        false,
			LongDescription:  "First reference code for billing",
			MixedCase:        false,
			ShortDescription: "Ref One",
			XMLCode:          "XML001",
		},
		{
			Code:             "REF-002",
			Default:          false,
			DisplayCode:      "R002",
			DisplayName:      "Reference Two",
			DomainName:       "BILLING",
			EDICode:          "EDI002",
			IsActive:         true,
			IsChecked:        true,
			LongDescription:  "Second reference code for billing",
			MixedCase:        true,
			ShortDescription: "Ref Two",
			XMLCode:          "XML002",
		},
	}
}

// newTestReferenceController creates a ReferenceController via the exported
// constructor using mock dependencies (Dependency Injection).
func newTestReferenceController(
	t *testing.T,
	mockRepo *mocks.MockIReferenceRepository,
	mockLogger *mocks.MockILogger,
	isDevelopment bool,
) controllers.IReferenceController {
	t.Helper()

	ctrl := gomock.NewController(t)
	mockCfg := mocks.NewMockIClientConfig(ctrl)
	mockCfg.EXPECT().IsDevelopment().Return(isDevelopment).AnyTimes()

	// NewReferenceController returns IController; the underlying type also
	// satisfies IReferenceController, so the type-assertion is safe.
	c := controllers.NewReferenceController(mockLogger, mockRepo, nil, mockCfg)
	referenceCtrl, ok := c.(controllers.IReferenceController)
	if !ok {
		t.Fatal("NewReferenceController did not return an IReferenceController")
	}
	return referenceCtrl
}

func TestGetReferenceCode(t *testing.T) {
	tests := []struct {
		name               string
		query              string // query string appended to /reference
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, body []byte)
	}{
		{
			name:          "missing both code and domainName query parameters returns 400",
			query:         "",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "code query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "missing code query parameter returns 400",
			query:         "?domainName=BILLING",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "code query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty code query parameter returns 400",
			query:         "?code=&domainName=BILLING",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "missing domainName query parameter returns 400",
			query:         "?code=REF-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "domainName query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty domainName query parameter returns 400",
			query:         "?code=REF-001&domainName=",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 502",
			query:         "?code=REF-001&domainName=BILLING",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetReferenceCode(gomock.Any(), "REF-001", "BILLING").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 401 unauthorized",
			query:         "?code=REF-001&domainName=BILLING",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetReferenceCode(gomock.Any(), "REF-001", "BILLING").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - context deadline exceeded",
			query:         "?code=REF-001&domainName=BILLING",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetReferenceCode(gomock.Any(), "REF-001", "BILLING").
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns generic error - 500",
			query:         "?code=REF-001&domainName=BILLING",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetReferenceCode(gomock.Any(), "REF-001", "BILLING").
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns empty slice - 404",
			query:         "?code=NONEXISTENT&domainName=BILLING",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetReferenceCode(gomock.Any(), "NONEXISTENT", "BILLING").
					Return([]coreEntities.ReferenceCode{}, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "reference codes not found" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "repository returns nil slice - 404",
			query:         "?code=NONEXISTENT&domainName=UNKNOWN",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetReferenceCode(gomock.Any(), "NONEXISTENT", "UNKNOWN").
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "valid code and domainName returns 200 with reference code data",
			query:         "?code=REF-001&domainName=BILLING",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetReferenceCode(gomock.Any(), "REF-001", "BILLING").
					Return(sampleCoreReferenceCodes(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.ReferenceCodeResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 2 {
					t.Fatalf("expected 2 items in data array, got %d", len(wrapper.Data))
				}
				first := wrapper.Data[0]
				if first.Code != "REF-001" {
					t.Errorf("expected Code REF-001, got %s", first.Code)
				}
				if first.DomainName != "BILLING" {
					t.Errorf("expected DomainName BILLING, got %s", first.DomainName)
				}
				if first.DisplayName != "Reference One" {
					t.Errorf("expected DisplayName 'Reference One', got %s", first.DisplayName)
				}
				if !first.IsActive {
					t.Error("expected IsActive true, got false")
				}
				if !first.Default {
					t.Error("expected Default true, got false")
				}
				second := wrapper.Data[1]
				if second.Code != "REF-002" {
					t.Errorf("expected Code REF-002, got %s", second.Code)
				}
				if !second.MixedCase {
					t.Error("expected MixedCase true for second item, got false")
				}
			},
		},
		{
			name:          "valid request returns single reference code",
			query:         "?code=SINGLE&domainName=DOMAIN",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetReferenceCode(gomock.Any(), "SINGLE", "DOMAIN").
					Return([]coreEntities.ReferenceCode{
						{
							Code:             "SINGLE",
							DisplayName:      "Single Ref",
							DomainName:       "DOMAIN",
							IsActive:         true,
							ShortDescription: "Single",
						},
					}, nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.ReferenceCodeResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 1 {
					t.Fatalf("expected 1 item in data array, got %d", len(wrapper.Data))
				}
				if wrapper.Data[0].Code != "SINGLE" {
					t.Errorf("expected Code SINGLE, got %s", wrapper.Data[0].Code)
				}
			},
		},
		{
			name:          "development mode includes error details on 400",
			query:         "?code=&domainName=BILLING",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			query:         "?code=REF-001&domainName=BILLING",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetReferenceCode(gomock.Any(), "REF-001", "BILLING").
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
		{
			name:          "development mode includes error details on repository error",
			query:         "?code=REF-001&domainName=BILLING",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetReferenceCode(gomock.Any(), "REF-001", "BILLING").
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "upstream 429 rate limit returns 429",
			query:         "?code=REF-001&domainName=BILLING",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetReferenceCode(gomock.Any(), "REF-001", "BILLING").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "special characters in code and domainName are passed through",
			query:         "?code=REF%2F001&domainName=BILLING%20DOMAIN",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockIReferenceRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetReferenceCode(gomock.Any(), "REF/001", "BILLING DOMAIN").
					Return([]coreEntities.ReferenceCode{
						{
							Code:       "REF/001",
							DomainName: "BILLING DOMAIN",
							IsActive:   true,
						},
					}, nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.ReferenceCodeResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 1 {
					t.Fatalf("expected 1 item in data array, got %d", len(wrapper.Data))
				}
				if wrapper.Data[0].Code != "REF/001" {
					t.Errorf("expected Code 'REF/001', got %s", wrapper.Data[0].Code)
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockIReferenceRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			// Setup mock expectations for this test case
			tt.setupMocks(mockRepo, mockLogger)

			// Construct the controller via the exported constructor (DI)
			referenceCtrl := newTestReferenceController(t, mockRepo, mockLogger, tt.isDevelopment)

			// Build request and recorder
			req := newReferenceGetRequest(t, tt.query)
			rr := httptest.NewRecorder()

			// Execute
			referenceCtrl.GetReferenceCode(rr, req)

			// Assert status code
			if rr.Code != tt.expectedStatusCode {
				t.Errorf("expected status %d, got %d", tt.expectedStatusCode, rr.Code)
			}

			// Assert Content-Type header
			contentType := rr.Header().Get("Content-Type")
			if contentType != "application/json" {
				t.Errorf("expected Content-Type application/json, got %s", contentType)
			}

			// Run custom body validations
			if tt.validateBody != nil {
				tt.validateBody(t, rr.Body.Bytes())
			}
		})
	}
}
