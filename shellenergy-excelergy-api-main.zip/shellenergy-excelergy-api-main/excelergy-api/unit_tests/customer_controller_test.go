package unit_tests

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/controllers"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/unit_tests/mocks"
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"

	"go.uber.org/mock/gomock"
)

// helper: build a GET *http.Request with the given query string for customer endpoints.
func newCustomerGetRequest(t *testing.T, query string) *http.Request {
	t.Helper()
	req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, "/customer/getCustomer"+query, nil)
	if err != nil {
		t.Fatalf("failed to create request: %v", err)
	}
	return req
}

// sampleCoreCustomer returns a minimal core Customer used in success scenarios.
func sampleCoreCustomer() *coreEntities.Customer {
	return &coreEntities.Customer{
		CustomerId:        100,
		FirstName:         "John",
		CoOrLastName:      "Doe",
		MiddleName:        "M",
		DisplayName:       "John Doe",
		DisplayCode:       "JD",
		CustomerClassType: "RESIDENTIAL",
		IsResidential:     true,
		CreditScore:       "750",
		CreditRisk:        "LOW",
		Phone:             "555-1234",
	}
}

// sampleCoreCustomerAccounts returns a slice of core Accounts for customer tests.
func sampleCoreCustomerAccounts() []coreEntities.Account {
	balance := 300.00
	return []coreEntities.Account{
		{
			AccountId:      20,
			AccountNo:      "ACC-020",
			AccountBalance: &balance,
			Name:           "Jane Primary",
			FirstName:      "Jane",
			LastName:       "Doe",
		},
		{
			AccountId: 21,
			AccountNo: "ACC-021",
			Name:      "Jane Secondary",
			FirstName: "Jane",
			LastName:  "Doe",
		},
	}
}

// newTestCustomerController creates a CustomerController via the exported
// constructor using mock dependencies (Dependency Injection).
func newTestCustomerController(
	t *testing.T,
	mockRepo *mocks.MockICustomerRepository,
	mockLogger *mocks.MockILogger,
	isDevelopment bool,
) controllers.ICustomerController {
	t.Helper()

	ctrl := gomock.NewController(t)
	mockCfg := mocks.NewMockIClientConfig(ctrl)
	mockCfg.EXPECT().IsDevelopment().Return(isDevelopment).AnyTimes()

	// NewCustomerController returns IController; the underlying type also
	// satisfies ICustomerController, so the type-assertion is safe.
	c := controllers.NewCustomerController(mockLogger, mockRepo, nil, mockCfg)
	customerCtrl, ok := c.(controllers.ICustomerController)
	if !ok {
		t.Fatal("NewCustomerController did not return an ICustomerController")
	}
	return customerCtrl
}

func TestGetCustomer(t *testing.T) {
	tests := []struct {
		name               string
		query              string // query string appended to /customer/getCustomer
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, body []byte)
	}{
		{
			name:          "missing both customerId and username returns 400",
			query:         "",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "customerId query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty customerId query parameter returns 400",
			query:         "?customerId=",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "customerId query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "missing username query parameter returns 400",
			query:         "?customerId=100",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "username query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty username query parameter returns 400",
			query:         "?customerId=100&username=",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "username query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "non-numeric customerId returns 400",
			query:         "?customerId=abc&username=testuser",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "customerId must be a valid positive integer" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "negative customerId returns 400",
			query:         "?customerId=-1&username=testuser",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "float customerId returns 400",
			query:         "?customerId=3.14&username=testuser",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 502",
			query:         "?customerId=100&username=testuser",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomer(gomock.Any(), uint64(100), "testuser").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 401 unauthorized",
			query:         "?customerId=100&username=testuser",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomer(gomock.Any(), uint64(100), "testuser").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - context deadline exceeded",
			query:         "?customerId=100&username=testuser",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomer(gomock.Any(), uint64(100), "testuser").
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns generic error - 500",
			query:         "?customerId=100&username=testuser",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomer(gomock.Any(), uint64(100), "testuser").
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns nil customer - 404",
			query:         "?customerId=999&username=testuser",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomer(gomock.Any(), uint64(999), "testuser").
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "customer not found" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "upstream 429 rate limit returns 429",
			query:         "?customerId=100&username=testuser",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomer(gomock.Any(), uint64(100), "testuser").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "valid customerId and username returns 200 with customer data",
			query:         "?customerId=100&username=testuser",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetCustomer(gomock.Any(), uint64(100), "testuser").
					Return(sampleCoreCustomer(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.CustomerResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 1 {
					t.Fatalf("expected 1 item in data array, got %d", len(wrapper.Data))
				}
				resp := wrapper.Data[0]
				if resp.CustomerId != 100 {
					t.Errorf("expected CustomerId 100, got %d", resp.CustomerId)
				}
				if resp.FirstName != "John" {
					t.Errorf("expected FirstName 'John', got %s", resp.FirstName)
				}
				if resp.CoOrLastName != "Doe" {
					t.Errorf("expected CoOrLastName 'Doe', got %s", resp.CoOrLastName)
				}
				if resp.DisplayName != "John Doe" {
					t.Errorf("expected DisplayName 'John Doe', got %s", resp.DisplayName)
				}
				if resp.CustomerClassType != "RESIDENTIAL" {
					t.Errorf("expected CustomerClassType 'RESIDENTIAL', got %s", resp.CustomerClassType)
				}
				if !resp.IsResidential {
					t.Error("expected IsResidential to be true")
				}
				if resp.CreditScore != "750" {
					t.Errorf("expected CreditScore '750', got %s", resp.CreditScore)
				}
				if resp.Phone != "555-1234" {
					t.Errorf("expected Phone '555-1234', got %s", resp.Phone)
				}
			},
		},
		{
			name:          "development mode includes error details on 400",
			query:         "?customerId=abc&username=testuser",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			query:         "?customerId=100&username=testuser",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomer(gomock.Any(), uint64(100), "testuser").
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
		{
			name:          "development mode includes error details on repository error",
			query:         "?customerId=100&username=testuser",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomer(gomock.Any(), uint64(100), "testuser").
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "zero customerId is valid and calls repository",
			query:         "?customerId=0&username=testuser",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomer(gomock.Any(), uint64(0), "testuser").
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockICustomerRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			// Setup mock expectations for this test case
			tt.setupMocks(mockRepo, mockLogger)

			// Construct the controller via the exported constructor (DI)
			customerCtrl := newTestCustomerController(t, mockRepo, mockLogger, tt.isDevelopment)

			// Build request and recorder
			req := newCustomerGetRequest(t, tt.query)
			rr := httptest.NewRecorder()

			// Execute
			customerCtrl.GetCustomer(rr, req)

			// Assert status code
			if rr.Code != tt.expectedStatusCode {
				t.Errorf("expected status %d, got %d", tt.expectedStatusCode, rr.Code)
			}

			// Assert Content-Type header
			contentType := rr.Header().Get("Content-Type")
			if contentType != "application/json" {
				t.Errorf("expected Content-Type application/json, got %s", contentType)
			}

			// Run custom body validations
			if tt.validateBody != nil {
				tt.validateBody(t, rr.Body.Bytes())
			}
		})
	}
}

func TestGetCustomerAccounts(t *testing.T) {
	tests := []struct {
		name               string
		query              string
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, body []byte)
	}{
		{
			name:          "missing customerId query parameter returns 400",
			query:         "?username=jdoe",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "customerId query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "missing username query parameter returns 400",
			query:         "?customerId=99",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "username query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty customerId query parameter returns 400",
			query:         "?customerId=&username=jdoe",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "non-numeric customerId returns 400",
			query:         "?customerId=abc&username=jdoe",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "customerId must be a valid positive integer" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "negative customerId returns 400",
			query:         "?customerId=-5&username=jdoe",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 502",
			query:         "?customerId=99&username=jdoe",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomerAccounts(gomock.Any(), uint64(99), "jdoe").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 401 unauthorized",
			query:         "?customerId=99&username=jdoe",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomerAccounts(gomock.Any(), uint64(99), "jdoe").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - context deadline exceeded",
			query:         "?customerId=99&username=jdoe",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomerAccounts(gomock.Any(), uint64(99), "jdoe").
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns generic error - 500",
			query:         "?customerId=99&username=jdoe",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomerAccounts(gomock.Any(), uint64(99), "jdoe").
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "upstream 429 rate limit returns 429",
			query:         "?customerId=99&username=jdoe",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomerAccounts(gomock.Any(), uint64(99), "jdoe").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns empty accounts - 200 with empty array",
			query:         "?customerId=99&username=jdoe",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetCustomerAccounts(gomock.Any(), uint64(99), "jdoe").
					Return([]coreEntities.Account{}, nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.AccountResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 0 {
					t.Errorf("expected empty data array, got %d items", len(wrapper.Data))
				}
			},
		},
		{
			name:          "repository returns nil accounts - 200 with empty array",
			query:         "?customerId=99&username=jdoe",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetCustomerAccounts(gomock.Any(), uint64(99), "jdoe").
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.AccountResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if wrapper.Data == nil {
					t.Error("expected non-nil data array (empty), got nil")
				}
			},
		},
		{
			name:          "valid request returns 200 with account data",
			query:         "?customerId=99&username=jdoe",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetCustomerAccounts(gomock.Any(), uint64(99), "jdoe").
					Return(sampleCoreCustomerAccounts(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.AccountResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 2 {
					t.Fatalf("expected 2 items in data array, got %d", len(wrapper.Data))
				}
				if wrapper.Data[0].AccountId != 20 {
					t.Errorf("expected AccountId 20, got %d", wrapper.Data[0].AccountId)
				}
				if wrapper.Data[0].AccountNo != "ACC-020" {
					t.Errorf("expected AccountNo ACC-020, got %s", wrapper.Data[0].AccountNo)
				}
				if wrapper.Data[1].AccountId != 21 {
					t.Errorf("expected AccountId 21, got %d", wrapper.Data[1].AccountId)
				}
			},
		},
		{
			name:          "development mode includes error details on repository error",
			query:         "?customerId=99&username=jdoe",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomerAccounts(gomock.Any(), uint64(99), "jdoe").
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			query:         "?customerId=99&username=jdoe",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICustomerRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCustomerAccounts(gomock.Any(), uint64(99), "jdoe").
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockICustomerRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			tt.setupMocks(mockRepo, mockLogger)

			customerCtrl := newTestCustomerController(t, mockRepo, mockLogger, tt.isDevelopment)

			req := newCustomerGetRequest(t, tt.query)
			rr := httptest.NewRecorder()

			customerCtrl.GetCustomerAccounts(rr, req)

			if rr.Code != tt.expectedStatusCode {
				t.Errorf("expected status %d, got %d", tt.expectedStatusCode, rr.Code)
			}

			contentType := rr.Header().Get("Content-Type")
			if contentType != "application/json" {
				t.Errorf("expected Content-Type application/json, got %s", contentType)
			}

			if tt.validateBody != nil {
				tt.validateBody(t, rr.Body.Bytes())
			}
		})
	}
}
