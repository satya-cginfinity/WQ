// Code generated manually following the gomock pattern.
// Mocks middleware.IAuthConfig for unit tests.

package mocks

import (
	reflect "reflect"

	gomock "go.uber.org/mock/gomock"
)

// MockIAuthConfig is a mock of IAuthConfig interface.
type MockIAuthConfig struct {
	ctrl     *gomock.Controller
	recorder *MockIAuthConfigMockRecorder
	isgomock struct{}
}

// MockIAuthConfigMockRecorder is the mock recorder for MockIAuthConfig.
type MockIAuthConfigMockRecorder struct {
	mock *MockIAuthConfig
}

// NewMockIAuthConfig creates a new mock instance.
func NewMockIAuthConfig(ctrl *gomock.Controller) *MockIAuthConfig {
	mock := &MockIAuthConfig{ctrl: ctrl}
	mock.recorder = &MockIAuthConfigMockRecorder{mock}
	return mock
}

// EXPECT returns an object that allows the caller to indicate expected use.
func (m *MockIAuthConfig) EXPECT() *MockIAuthConfigMockRecorder {
	return m.recorder
}

// GetAPIKey mocks base method.
func (m *MockIAuthConfig) GetAPIKey() string {
	m.ctrl.T.Helper()
	ret := m.ctrl.Call(m, "GetAPIKey")
	ret0, _ := ret[0].(string)
	return ret0
}

// GetAPIKey indicates an expected call of GetAPIKey.
func (mr *MockIAuthConfigMockRecorder) GetAPIKey() *gomock.Call {
	mr.mock.ctrl.T.Helper()
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "GetAPIKey", reflect.TypeOf((*MockIAuthConfig)(nil).GetAPIKey))
}

// IsDevelopment mocks base method.
func (m *MockIAuthConfig) IsDevelopment() bool {
	m.ctrl.T.Helper()
	ret := m.ctrl.Call(m, "IsDevelopment")
	ret0, _ := ret[0].(bool)
	return ret0
}

// IsDevelopment indicates an expected call of IsDevelopment.
func (mr *MockIAuthConfigMockRecorder) IsDevelopment() *gomock.Call {
	mr.mock.ctrl.T.Helper()
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "IsDevelopment", reflect.TypeOf((*MockIAuthConfig)(nil).IsDevelopment))
}
