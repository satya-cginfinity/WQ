package unit_tests

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/controllers"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/unit_tests/mocks"
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"

	"go.uber.org/mock/gomock"
)

// helper: build an *http.Request with the given query string for LDC account endpoints.
func newLdcAccountGetRequest(t *testing.T, query string) *http.Request {
	t.Helper()
	req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, "/ldcAccount"+query, nil)
	if err != nil {
		t.Fatalf("failed to create request: %v", err)
	}
	return req
}

// sampleCoreLdcAccount returns a minimal core LdcAccount entity used in success scenarios.
func sampleCoreLdcAccount() *coreEntities.LdcAccount {
	balance := 150.75
	return &coreEntities.LdcAccount{
		LDCAccountId:   74,
		LDCAccountName: "Test LDC Account",
		AcctId:         100,
		LDCAcctNo:      "LDC-001",
		Status:         "Active",
		Balance:        &balance,
	}
}

// newTestLdcAccountController creates a LdcAccountController via the exported
// constructor using mock dependencies (Dependency Injection).
func newTestLdcAccountController(
	t *testing.T,
	mockRepo *mocks.MockILdcAccountRepository,
	mockLogger *mocks.MockILogger,
	isDevelopment bool,
) controllers.ILdcAccountController {
	t.Helper()

	ctrl := gomock.NewController(t)
	mockCfg := mocks.NewMockIClientConfig(ctrl)
	mockCfg.EXPECT().IsDevelopment().Return(isDevelopment).AnyTimes()

	// NewLdcAccountController returns IController; the underlying type also
	// satisfies ILdcAccountController, so the type-assertion is safe.
	c := controllers.NewLdcAccountController(mockLogger, mockRepo, nil, mockCfg)
	ldcAccountCtrl, ok := c.(controllers.ILdcAccountController)
	if !ok {
		t.Fatal("NewLdcAccountController did not return an ILdcAccountController")
	}
	return ldcAccountCtrl
}

// uint64Ptr is a helper that returns a pointer to the given uint64 value.
func uint64Ptr(v uint64) *uint64 {
	return &v
}

// validLdcAccountQuery returns a query string with all params provided.
func validLdcAccountQuery() string {
	return "?customerId=1&ldcAccountId=74&accountId=74&userName=testUser"
}

func TestGetLdcAccount(t *testing.T) {
	tests := []struct {
		name               string
		query              string
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, body []byte)
	}{
		// --- Validation: at least one ID required ---
		{
			name:          "no ID parameters returns 400",
			query:         "",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "at least one of customerId, ldcAccountId, or accountId must be provided" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "only userName without any ID returns 400",
			query:         "?userName=testUser",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		// --- Validation: format checks on individual params ---
		{
			name:          "invalid customerId returns 400",
			query:         "?customerId=abc",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "customerId must be a valid positive integer" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "invalid ldcAccountId returns 400",
			query:         "?ldcAccountId=abc",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "ldcAccountId must be a valid positive integer" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "invalid accountId returns 400",
			query:         "?accountId=abc",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "accountId must be a valid positive integer" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		// --- Partial params: only one ID provided ---
		{
			name:          "only customerId provided calls repository and returns 200",
			query:         "?customerId=1",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetLdcAccount(gomock.Any(), uint64Ptr(1), (*uint64)(nil), (*uint64)(nil), "").
					Return(sampleCoreLdcAccount(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.LdcAccountResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 1 {
					t.Fatalf("expected 1 LDC account in data array, got %d", len(wrapper.Data))
				}
			},
		},
		{
			name:          "only ldcAccountId provided calls repository and returns 200",
			query:         "?ldcAccountId=74",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetLdcAccount(gomock.Any(), (*uint64)(nil), uint64Ptr(74), (*uint64)(nil), "").
					Return(sampleCoreLdcAccount(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.LdcAccountResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 1 {
					t.Fatalf("expected 1 LDC account in data array, got %d", len(wrapper.Data))
				}
			},
		},
		{
			name:          "only accountId provided calls repository and returns 200",
			query:         "?accountId=74",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetLdcAccount(gomock.Any(), (*uint64)(nil), (*uint64)(nil), uint64Ptr(74), "").
					Return(sampleCoreLdcAccount(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.LdcAccountResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 1 {
					t.Fatalf("expected 1 LDC account in data array, got %d", len(wrapper.Data))
				}
			},
		},
		// --- All params provided: success scenario ---
		{
			name:          "all parameters returns 200 with LDC account data",
			query:         validLdcAccountQuery(),
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetLdcAccount(gomock.Any(), uint64Ptr(1), uint64Ptr(74), uint64Ptr(74), "testUser").
					Return(sampleCoreLdcAccount(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.LdcAccountResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 1 {
					t.Fatalf("expected 1 LDC account in data array, got %d", len(wrapper.Data))
				}
				if wrapper.Data[0].LDCAccountId != 74 {
					t.Errorf("expected LDCAccountId 74, got %d", wrapper.Data[0].LDCAccountId)
				}
				if wrapper.Data[0].LDCAccountName != "Test LDC Account" {
					t.Errorf("expected LDCAccountName 'Test LDC Account', got %s", wrapper.Data[0].LDCAccountName)
				}
				if wrapper.Data[0].AcctId != 100 {
					t.Errorf("expected AcctId 100, got %d", wrapper.Data[0].AcctId)
				}
				if wrapper.Data[0].LDCAcctNo != "LDC-001" {
					t.Errorf("expected LDCAcctNo 'LDC-001', got %s", wrapper.Data[0].LDCAcctNo)
				}
				if wrapper.Data[0].Status != "Active" {
					t.Errorf("expected Status 'Active', got %s", wrapper.Data[0].Status)
				}
			},
		},
		{
			name:          "all parameters returns 200 with correct content-type",
			query:         validLdcAccountQuery(),
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetLdcAccount(gomock.Any(), uint64Ptr(1), uint64Ptr(74), uint64Ptr(74), "testUser").
					Return(sampleCoreLdcAccount(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				// validated via header check in main test loop
			},
		},
		// --- Repository error scenarios ---
		{
			name:          "repository returns error - upstream 502",
			query:         validLdcAccountQuery(),
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetLdcAccount(gomock.Any(), uint64Ptr(1), uint64Ptr(74), uint64Ptr(74), "testUser").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 401 unauthorized",
			query:         validLdcAccountQuery(),
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetLdcAccount(gomock.Any(), uint64Ptr(1), uint64Ptr(74), uint64Ptr(74), "testUser").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - context deadline exceeded",
			query:         validLdcAccountQuery(),
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetLdcAccount(gomock.Any(), uint64Ptr(1), uint64Ptr(74), uint64Ptr(74), "testUser").
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns generic error - 500",
			query:         validLdcAccountQuery(),
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetLdcAccount(gomock.Any(), uint64Ptr(1), uint64Ptr(74), uint64Ptr(74), "testUser").
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns nil LDC account - 404",
			query:         validLdcAccountQuery(),
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetLdcAccount(gomock.Any(), uint64Ptr(1), uint64Ptr(74), uint64Ptr(74), "testUser").
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "LDC account not found" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "upstream 429 rate limit returns 429",
			query:         validLdcAccountQuery(),
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetLdcAccount(gomock.Any(), uint64Ptr(1), uint64Ptr(74), uint64Ptr(74), "testUser").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		// --- Dev / non-dev mode ---
		{
			name:          "development mode returns 400 for no IDs",
			query:         "",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			query:         validLdcAccountQuery(),
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetLdcAccount(gomock.Any(), uint64Ptr(1), uint64Ptr(74), uint64Ptr(74), "testUser").
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
		{
			name:          "development mode includes error details on repository error",
			query:         validLdcAccountQuery(),
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockILdcAccountRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetLdcAccount(gomock.Any(), uint64Ptr(1), uint64Ptr(74), uint64Ptr(74), "testUser").
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockILdcAccountRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			// Setup mock expectations for this test case
			tt.setupMocks(mockRepo, mockLogger)

			// Construct the controller via the exported constructor (DI)
			ldcAccountCtrl := newTestLdcAccountController(t, mockRepo, mockLogger, tt.isDevelopment)

			// Build request and recorder
			req := newLdcAccountGetRequest(t, tt.query)
			rr := httptest.NewRecorder()

			// Execute
			ldcAccountCtrl.GetLdcAccount(rr, req)

			// Assert status code
			if rr.Code != tt.expectedStatusCode {
				t.Errorf("expected status %d, got %d", tt.expectedStatusCode, rr.Code)
			}

			// Assert Content-Type header
			contentType := rr.Header().Get("Content-Type")
			if contentType != "application/json" {
				t.Errorf("expected Content-Type application/json, got %s", contentType)
			}

			// Run custom body validations
			if tt.validateBody != nil {
				tt.validateBody(t, rr.Body.Bytes())
			}
		})
	}
}
