package unit_tests

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/controllers"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/unit_tests/mocks"
	coreEntities "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"

	"go.uber.org/mock/gomock"
)

// helper: build an *http.Request with the given query string for calendar endpoints.
func newCalendarGetRequest(t *testing.T, query string) *http.Request {
	t.Helper()
	req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, "/calendar/holidays"+query, nil)
	if err != nil {
		t.Fatalf("failed to create request: %v", err)
	}
	return req
}

// helper: build an *http.Request with the given query string for GetCalendarByCode.
func newCalendarByCodeGetRequest(t *testing.T, query string) *http.Request {
	t.Helper()
	req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, "/calendar"+query, nil)
	if err != nil {
		t.Fatalf("failed to create request: %v", err)
	}
	return req
}

// sampleCoreHolidays returns a minimal slice of core Holiday entities used in success scenarios.
func sampleCoreHolidays() []coreEntities.Holiday {
	return []coreEntities.Holiday{
		{
			HolidayId:   1,
			CalendarId:  10,
			HolidayDate: "2026-01-01",
			HolidayType: "PUBLIC",
			Description: "New Year's Day",
		},
		{
			HolidayId:   2,
			CalendarId:  10,
			HolidayDate: "2026-12-25",
			HolidayType: "PUBLIC",
			Description: "Christmas Day",
		},
	}
}

// newTestCalendarController creates a CalendarController via the exported
// constructor using mock dependencies (Dependency Injection).
func newTestCalendarController(
	t *testing.T,
	mockRepo *mocks.MockICalendarRepository,
	mockLogger *mocks.MockILogger,
	isDevelopment bool,
) controllers.ICalendarController {
	t.Helper()

	ctrl := gomock.NewController(t)
	mockCfg := mocks.NewMockIClientConfig(ctrl)
	mockCfg.EXPECT().IsDevelopment().Return(isDevelopment).AnyTimes()

	// NewCalendarController returns IController; the underlying type also
	// satisfies ICalendarController, so the type-assertion is safe.
	c := controllers.NewCalendarController(mockLogger, mockRepo, nil, mockCfg)
	calendarCtrl, ok := c.(controllers.ICalendarController)
	if !ok {
		t.Fatal("NewCalendarController did not return an ICalendarController")
	}
	return calendarCtrl
}

func TestGetCalendarHolidays(t *testing.T) {
	tests := []struct {
		name               string
		query              string // query string appended to /calendar/holidays
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, body []byte)
	}{
		{
			name:          "missing calendarCode query parameter returns 400",
			query:         "",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "calendarCode query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty calendarCode query parameter returns 400",
			query:         "?calendarCode=",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 502",
			query:         "?calendarCode=10",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarHolidays(gomock.Any(), "10").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 401 unauthorized",
			query:         "?calendarCode=10",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarHolidays(gomock.Any(), "10").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - context deadline exceeded",
			query:         "?calendarCode=10",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarHolidays(gomock.Any(), "10").
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns generic error - 500",
			query:         "?calendarCode=10",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarHolidays(gomock.Any(), "10").
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns nil holidays - 404",
			query:         "?calendarCode=999",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarHolidays(gomock.Any(), "999").
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "calendar holidays not found" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "repository returns empty holidays slice - 404",
			query:         "?calendarCode=999",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarHolidays(gomock.Any(), "999").
					Return([]coreEntities.Holiday{}, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "valid calendarCode returns 200 with holiday list",
			query:         "?calendarCode=10",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetCalendarHolidays(gomock.Any(), "10").
					Return(sampleCoreHolidays(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.HolidayResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 2 {
					t.Fatalf("expected 2 items in data array, got %d", len(wrapper.Data))
				}
				resp := wrapper.Data[0]
				if resp.HolidayId != 1 {
					t.Errorf("expected HolidayId 1, got %d", resp.HolidayId)
				}
				if resp.CalendarId != 10 {
					t.Errorf("expected CalendarId 10, got %d", resp.CalendarId)
				}
				if resp.HolidayDate != "2026-01-01" {
					t.Errorf("expected HolidayDate '2026-01-01', got %s", resp.HolidayDate)
				}
				if resp.Description != "New Year's Day" {
					t.Errorf("expected Description 'New Year's Day', got %s", resp.Description)
				}
			},
		},
		{
			name:          "valid calendarCode returns 200 with correct content-type",
			query:         "?calendarCode=10",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetCalendarHolidays(gomock.Any(), "10").
					Return(sampleCoreHolidays(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				// validated via header check in main test loop
			},
		},
		{
			name:          "development mode returns 400 without details for missing calendarCode",
			query:         "",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			query:         "?calendarCode=10",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarHolidays(gomock.Any(), "10").
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
		{
			name:          "development mode includes error details on repository error",
			query:         "?calendarCode=10",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarHolidays(gomock.Any(), "10").
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "upstream 429 rate limit returns 429",
			query:         "?calendarCode=10",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarHolidays(gomock.Any(), "10").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "string calendarCode is valid and calls repository",
			query:         "?calendarCode=CAL-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarHolidays(gomock.Any(), "CAL-001").
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockICalendarRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			// Setup mock expectations for this test case
			tt.setupMocks(mockRepo, mockLogger)

			// Construct the controller via the exported constructor (DI)
			calendarCtrl := newTestCalendarController(t, mockRepo, mockLogger, tt.isDevelopment)

			// Build request and recorder
			req := newCalendarGetRequest(t, tt.query)
			rr := httptest.NewRecorder()

			// Execute
			calendarCtrl.GetCalendarHolidays(rr, req)

			// Assert status code
			if rr.Code != tt.expectedStatusCode {
				t.Errorf("expected status %d, got %d", tt.expectedStatusCode, rr.Code)
			}

			// Assert Content-Type header
			contentType := rr.Header().Get("Content-Type")
			if contentType != "application/json" {
				t.Errorf("expected Content-Type application/json, got %s", contentType)
			}

			// Run custom body validations
			if tt.validateBody != nil {
				tt.validateBody(t, rr.Body.Bytes())
			}
		})
	}
}

// sampleCoreCalendar returns a core Calendar entity used in success scenarios.
func sampleCoreCalendar() *coreEntities.Calendar {
	return &coreEntities.Calendar{
		CalendarId:   141,
		TypeCode:     "SYS",
		Default:      false,
		Description:  "Bank Holiday",
		CalendarCode: "BH",
	}
}

func TestGetCalendarByCode(t *testing.T) {
	tests := []struct {
		name               string
		query              string // query string appended to /calendar
		isDevelopment      bool
		setupMocks         func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger)
		expectedStatusCode int
		validateBody       func(t *testing.T, body []byte)
	}{
		{
			name:          "missing calendarCode query parameter returns 400",
			query:         "",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "calendarCode query parameter is required" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "empty calendarCode query parameter returns 400",
			query:         "?calendarCode=",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 502",
			query:         "?calendarCode=BH",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarByCode(gomock.Any(), "BH").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusBadGateway,
						Message:    "upstream failure",
						Err:        errors.New("connection refused"),
					})
			},
			expectedStatusCode: http.StatusBadGateway,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UPSTREAM_ERROR" {
					t.Errorf("expected error code UPSTREAM_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - upstream 401 unauthorized",
			query:         "?calendarCode=BH",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarByCode(gomock.Any(), "BH").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusUnauthorized,
						Message:    "unauthorized",
						Err:        errors.New("invalid token"),
					})
			},
			expectedStatusCode: http.StatusUnauthorized,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "UNAUTHORIZED" {
					t.Errorf("expected error code UNAUTHORIZED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns error - context deadline exceeded",
			query:         "?calendarCode=BH",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarByCode(gomock.Any(), "BH").
					Return(nil, context.DeadlineExceeded)
			},
			expectedStatusCode: http.StatusGatewayTimeout,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "TIMEOUT" {
					t.Errorf("expected error code TIMEOUT, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns generic error - 500",
			query:         "?calendarCode=BH",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarByCode(gomock.Any(), "BH").
					Return(nil, errors.New("unexpected database error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "INTERNAL_ERROR" {
					t.Errorf("expected error code INTERNAL_ERROR, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "repository returns nil calendar - 404",
			query:         "?calendarCode=UNKNOWN",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarByCode(gomock.Any(), "UNKNOWN").
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
				if errResp.Error.Message != "calendar not found" {
					t.Errorf("unexpected error message: %s", errResp.Error.Message)
				}
			},
		},
		{
			name:          "valid calendarCode returns 200 with calendar data",
			query:         "?calendarCode=BH",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetCalendarByCode(gomock.Any(), "BH").
					Return(sampleCoreCalendar(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var wrapper struct {
					Data []entities.CalendarResponse `json:"data"`
				}
				if err := json.Unmarshal(body, &wrapper); err != nil {
					t.Fatalf("failed to unmarshal data response: %v", err)
				}
				if len(wrapper.Data) != 1 {
					t.Fatalf("expected 1 calendar in data array, got %d", len(wrapper.Data))
				}
				if wrapper.Data[0].CalendarId != 141 {
					t.Errorf("expected CalendarId 141, got %d", wrapper.Data[0].CalendarId)
				}
				if wrapper.Data[0].CalendarCode != "BH" {
					t.Errorf("expected CalendarCode 'BH', got %s", wrapper.Data[0].CalendarCode)
				}
				if wrapper.Data[0].TypeCode != "SYS" {
					t.Errorf("expected TypeCode 'SYS', got %s", wrapper.Data[0].TypeCode)
				}
				if wrapper.Data[0].Default != false {
					t.Errorf("expected Default false, got %v", wrapper.Data[0].Default)
				}
				if wrapper.Data[0].Description != "Bank Holiday" {
					t.Errorf("expected Description 'Bank Holiday', got %s", wrapper.Data[0].Description)
				}
			},
		},
		{
			name:          "valid calendarCode returns 200 with correct content-type",
			query:         "?calendarCode=BH",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockRepo.EXPECT().
					GetCalendarByCode(gomock.Any(), "BH").
					Return(sampleCoreCalendar(), nil)
			},
			expectedStatusCode: http.StatusOK,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				// validated via header check in main test loop
			},
		},
		{
			name:          "development mode returns 400 without details for missing calendarCode",
			query:         "",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
			},
			expectedStatusCode: http.StatusBadRequest,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "BAD_REQUEST" {
					t.Errorf("expected error code BAD_REQUEST, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "non-development mode omits error details on repository error",
			query:         "?calendarCode=BH",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarByCode(gomock.Any(), "BH").
					Return(nil, errors.New("some error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details != nil {
					t.Error("expected no error details in non-development mode")
				}
			},
		},
		{
			name:          "development mode includes error details on repository error",
			query:         "?calendarCode=BH",
			isDevelopment: true,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarByCode(gomock.Any(), "BH").
					Return(nil, errors.New("detailed internal error"))
			},
			expectedStatusCode: http.StatusInternalServerError,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Details == nil {
					t.Error("expected error details in development mode, got nil")
				}
			},
		},
		{
			name:          "upstream 429 rate limit returns 429",
			query:         "?calendarCode=BH",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Error(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarByCode(gomock.Any(), "BH").
					Return(nil, &repository.UpstreamError{
						StatusCode: http.StatusTooManyRequests,
						Message:    "rate limited",
						Err:        errors.New("429 from upstream"),
					})
			},
			expectedStatusCode: http.StatusTooManyRequests,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "RATE_LIMIT_EXCEEDED" {
					t.Errorf("expected error code RATE_LIMIT_EXCEEDED, got %s", errResp.Error.Code)
				}
			},
		},
		{
			name:          "string calendarCode is valid and calls repository",
			query:         "?calendarCode=CAL-001",
			isDevelopment: false,
			setupMocks: func(mockRepo *mocks.MockICalendarRepository, mockLogger *mocks.MockILogger) {
				mockLogger.EXPECT().Info(gomock.Any(), gomock.Any()).AnyTimes()
				mockRepo.EXPECT().
					GetCalendarByCode(gomock.Any(), "CAL-001").
					Return(nil, nil)
			},
			expectedStatusCode: http.StatusNotFound,
			validateBody: func(t *testing.T, body []byte) {
				t.Helper()
				var errResp apierrors.ErrorResponse
				if err := json.Unmarshal(body, &errResp); err != nil {
					t.Fatalf("failed to unmarshal error response: %v", err)
				}
				if errResp.Error.Code != "NOT_FOUND" {
					t.Errorf("expected error code NOT_FOUND, got %s", errResp.Error.Code)
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			mockRepo := mocks.NewMockICalendarRepository(ctrl)
			mockLogger := mocks.NewMockILogger(ctrl)

			// Setup mock expectations for this test case
			tt.setupMocks(mockRepo, mockLogger)

			// Construct the controller via the exported constructor (DI)
			calendarCtrl := newTestCalendarController(t, mockRepo, mockLogger, tt.isDevelopment)

			// Build request and recorder
			req := newCalendarByCodeGetRequest(t, tt.query)
			rr := httptest.NewRecorder()

			// Execute
			calendarCtrl.GetCalendarByCode(rr, req)

			// Assert status code
			if rr.Code != tt.expectedStatusCode {
				t.Errorf("expected status %d, got %d", tt.expectedStatusCode, rr.Code)
			}

			// Assert Content-Type header
			contentType := rr.Header().Get("Content-Type")
			if contentType != "application/json" {
				t.Errorf("expected Content-Type application/json, got %s", contentType)
			}

			// Run custom body validations
			if tt.validateBody != nil {
				tt.validateBody(t, rr.Body.Bytes())
			}
		})
	}
}
