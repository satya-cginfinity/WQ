package middleware

import (
	"net/http"
	"strings"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	core_logger "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
)

// APIKeyAuth implements IAPIKeyAuth and validates incoming requests
// against a configured API key sent via the X-API-Key header.
type APIKeyAuth struct {
	apiKey        string
	isDevelopment bool
	logger        core_logger.ILogger
}

// NewAPIKeyAuth creates a new APIKeyAuth instance.
func NewAPIKeyAuth(config IAuthConfig, logger core_logger.ILogger) IAPIKeyAuth {
	return &APIKeyAuth{
		apiKey:        config.GetAPIKey(),
		isDevelopment: config.IsDevelopment(),
		logger:        logger,
	}
}

// Middleware returns an HTTP middleware that validates the X-API-Key header.
// Health-check and Swagger documentation endpoints are exempt from authentication.
func (a *APIKeyAuth) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Skip authentication for exempt paths (health checks, swagger docs)
		if isExemptPath(r.URL.Path) {
			next.ServeHTTP(w, r)
			return
		}

		apiKey := r.Header.Get("X-API-Key")
		if apiKey == "" {
			a.logger.Error("Missing API key in request", "path", r.URL.Path)
			apierrors.WriteJSON(w, apierrors.NewUnauthorized("API key is required. Provide a valid key via the X-API-Key header.", nil), a.isDevelopment)
			return
		}

		if apiKey != a.apiKey {
			a.logger.Error("Invalid API key provided", "path", r.URL.Path)
			apierrors.WriteJSON(w, apierrors.NewUnauthorized("invalid API key", nil), a.isDevelopment)
			return
		}

		next.ServeHTTP(w, r)
	})
}

// isExemptPath returns true for paths that do not require API key authentication.
func isExemptPath(path string) bool {
	return strings.HasPrefix(path, "/health") || strings.HasPrefix(path, "/swagger")
}
