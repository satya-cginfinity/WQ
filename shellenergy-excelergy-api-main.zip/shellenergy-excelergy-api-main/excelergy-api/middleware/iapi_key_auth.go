package middleware

import "net/http"

// IAPIKeyAuth defines the interface for API key authentication middleware.
type IAPIKeyAuth interface {
	// Middleware returns an HTTP middleware that validates the X-API-Key header.
	Middleware(next http.Handler) http.Handler
}
