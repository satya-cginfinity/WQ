package middleware

// IAuthConfig defines the configuration interface for API key authentication.
type IAuthConfig interface {
	GetAPIKey() string
	IsDevelopment() bool
}
