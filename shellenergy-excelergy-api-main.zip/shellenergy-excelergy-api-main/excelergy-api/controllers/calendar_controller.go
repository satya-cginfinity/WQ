package controllers

import (
	"encoding/json"
	"net/http"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/entities"
	router "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/router"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
	core_logger "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"
)

// CalendarController implements the ICalendarController interface
type CalendarController struct {
	logger        core_logger.ILogger
	repository    repository.ICalendarRepository
	isDevelopment bool
}

// NewCalendarController creates a new CalendarController instance
func NewCalendarController(logger core_logger.ILogger, repository repository.ICalendarRepository, router router.IRouter, cfg client.IClientConfig) IController {
	controller := &CalendarController{
		logger:        logger,
		repository:    repository,
		isDevelopment: cfg.IsDevelopment(),
	}

	return controller
}

// GetCalendarHolidays godoc
//
//	@Summary		Get calendar holidays by calendar Code
//	@Description	Retrieves the list of holidays for a given calendar Code
//	@Tags			calendar
//	@Accept			json
//	@Produce		json
//	@Param			calendarCode	query		string	true	"calendar Code"
//	@Success		200			{object}	entities.DataResponse{data=[]entities.HolidayResponse}
//	@Failure		400			{object}	apierrors.ErrorResponse
//	@Failure		401			{object}	apierrors.ErrorResponse
//	@Failure		403			{object}	apierrors.ErrorResponse
//	@Failure		404			{object}	apierrors.ErrorResponse
//	@Failure		429			{object}	apierrors.ErrorResponse
//	@Failure		500			{object}	apierrors.ErrorResponse
//	@Failure		502			{object}	apierrors.ErrorResponse
//	@Failure		504			{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/calendar/holidays [get]
func (c *CalendarController) GetCalendarHolidays(w http.ResponseWriter, r *http.Request) {
	// --- 400: Validate request parameters ---
	calendarCode := r.URL.Query().Get("calendarCode")
	if calendarCode == "" {
		c.logger.Error("calendarCode parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("calendarCode query parameter is required", nil), c.isDevelopment)
		return
	}

	// --- Call repository ---
	holidays, err := c.repository.GetCalendarHolidays(r.Context(), calendarCode)
	if err != nil {
		c.logger.Error("Failed to get calendar holidays", "calendarCode", calendarCode, "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	// --- 404: Holidays not found ---
	if holidays == nil || len(holidays) == 0 {
		c.logger.Info("Calendar holidays not found", "calendarCode", calendarCode)
		apierrors.WriteJSON(w, apierrors.NewNotFound("calendar holidays not found", nil), c.isDevelopment)
		return
	}

	holidayResponses := entities.FromCoreHolidays(holidays)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(entities.NewDataResponse(holidayResponses))
}

// GetCalendarByCode godoc
//
//	@Summary		Get calendar by calendar Code
//	@Description	Retrieves a calendar for a given calendar Code
//	@Tags			calendar
//	@Accept			json
//	@Produce		json
//	@Param			calendarCode	query		string	true	"calendar Code"
//	@Success		200			{object}	entities.DataResponse{data=[]entities.CalendarResponse}
//	@Failure		400			{object}	apierrors.ErrorResponse
//	@Failure		401			{object}	apierrors.ErrorResponse
//	@Failure		403			{object}	apierrors.ErrorResponse
//	@Failure		404			{object}	apierrors.ErrorResponse
//	@Failure		429			{object}	apierrors.ErrorResponse
//	@Failure		500			{object}	apierrors.ErrorResponse
//	@Failure		502			{object}	apierrors.ErrorResponse
//	@Failure		504			{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/calendar/code [get]
func (c *CalendarController) GetCalendarByCode(w http.ResponseWriter, r *http.Request) {
	// --- 400: Validate request parameters ---
	calendarCode := r.URL.Query().Get("calendarCode")
	if calendarCode == "" {
		c.logger.Error("calendarCode parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("calendarCode query parameter is required", nil), c.isDevelopment)
		return
	}

	// --- Call repository ---
	calendar, err := c.repository.GetCalendarByCode(r.Context(), calendarCode)
	if err != nil {
		c.logger.Error("Failed to get calendar by code", "calendarCode", calendarCode, "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	// --- 404: Calendar not found ---
	if calendar == nil {
		c.logger.Info("Calendar not found", "calendarCode", calendarCode)
		apierrors.WriteJSON(w, apierrors.NewNotFound("calendar not found", nil), c.isDevelopment)
		return
	}

	calendarResponse := entities.FromCoreCalendar(calendar)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(entities.NewDataResponse([]interface{}{calendarResponse}))
}

// RegisterRoutes registers all calendar routes with the router
func (c *CalendarController) RegisterRoutes(router router.IRouter) {
	calendarGroup := router.Group("/api/v1/calendar")
	calendarGroup.GET("/holidays", c.GetCalendarHolidays)
	calendarGroup.GET("/code", c.GetCalendarByCode)
}
