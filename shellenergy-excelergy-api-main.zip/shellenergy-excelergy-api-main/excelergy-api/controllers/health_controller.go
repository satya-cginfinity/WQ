package controllers

import (
	"encoding/json"
	"net/http"

	router "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/router"
	core_logger "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
)

// HealthController implements the IHealthController interface
type HealthController struct {
	// Add dependencies here (e.g., database, cache, services) these should be
	// interfaces with IsReady State.
	logger core_logger.ILogger
}

// NewHealthController creates a new HealthController instance
func NewHealthController(logger core_logger.ILogger, router router.IRouter) IController {
	controller := &HealthController{
		logger: logger,
	}

	return controller
}

// HealthResponse represents the health check response
type HealthResponse struct {
	Status  string `json:"status"`
	Message string `json:"message"`
}

// DataResponse wraps all successful responses in a normalised envelope.
type DataResponse struct {
	Data interface{} `json:"data"`
}

//	@Summary		Health endpoint
//	@Description	Returns a health status message
//	@Tags			Health
//	@Accept			json
//	@Produce		json
//	@Router			/health [get]
//	@Success		200	{object}	HealthResponse
//
// HealthCheck returns the health status of the application
func (h *HealthController) HealthCheck(w http.ResponseWriter, r *http.Request) {
	response := HealthResponse{
		Status:  "ok",
		Message: "Service is healthy",
	}

	h.logger.Info("Health check accessed")

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(DataResponse{Data: []HealthResponse{response}})
}

// ReadinessCheck returns whether the application is ready to accept traffic
func (h *HealthController) ReadinessCheck(w http.ResponseWriter, r *http.Request) {
	// Add checks for dependencies (database, external services, etc.)
	// For now, we'll just return ready
	response := HealthResponse{
		Status:  "ready",
		Message: "Service is ready to accept traffic",
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(DataResponse{Data: []HealthResponse{response}})
}

// LivenessCheck returns whether the application is alive
func (h *HealthController) LivenessCheck(w http.ResponseWriter, r *http.Request) {
	response := HealthResponse{
		Status:  "alive",
		Message: "Service is alive",
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(DataResponse{Data: []HealthResponse{response}})
}

// RegisterRoutes registers all health check routes with the router
func (h *HealthController) RegisterRoutes(router router.IRouter) {
	healthGroup := router.Group("/health")
	healthGroup.GET("", h.HealthCheck)
	healthGroup.GET("/ready", h.ReadinessCheck)
	healthGroup.GET("/live", h.LivenessCheck)
}
