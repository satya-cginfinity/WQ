package controllers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/entities"
	router "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/router"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
	core_logger "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"
)

// InvoiceController implements the IInvoiceController interface
type InvoiceController struct {
	logger        core_logger.ILogger
	repository    repository.IInvoiceRepository
	isDevelopment bool
}

// NewInvoiceController creates a new InvoiceController instance
func NewInvoiceController(logger core_logger.ILogger, repository repository.IInvoiceRepository, router router.IRouter, cfg client.IClientConfig) IController {
	controller := &InvoiceController{
		logger:        logger,
		repository:    repository,
		isDevelopment: cfg.IsDevelopment(),
	}

	return controller
}

// DownloadInvoicePdf godoc
//
//	@Summary		Download invoice PDF
//	@Description	Downloads the invoice PDF for the given billing account number and billing month
//	@Tags			invoices
//	@Accept			json
//	@Produce		application/pdf
//	@Param			billingAccountNo	query		string	true	"Billing Account Number"
//	@Param			billingMonth		query		string	true	"Billing Month"
//	@Success		200					{file}		binary	"PDF file"
//	@Failure		400					{object}	apierrors.ErrorResponse
//	@Failure		401					{object}	apierrors.ErrorResponse
//	@Failure		403					{object}	apierrors.ErrorResponse
//	@Failure		404					{object}	apierrors.ErrorResponse
//	@Failure		429					{object}	apierrors.ErrorResponse
//	@Failure		500					{object}	apierrors.ErrorResponse
//	@Failure		502					{object}	apierrors.ErrorResponse
//	@Failure		504					{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/invoice/downloadPdf [get]
func (c *InvoiceController) DownloadInvoicePdf(w http.ResponseWriter, r *http.Request) {
	// --- 400: Validate request parameters ---
	billingAccountNo := r.URL.Query().Get("billingAccountNo")
	if billingAccountNo == "" {
		c.logger.Error("billingAccountNo parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("billingAccountNo query parameter is required", nil), c.isDevelopment)
		return
	}

	billingMonth := r.URL.Query().Get("billingMonth")
	if billingMonth == "" {
		c.logger.Error("billingMonth parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("billingMonth query parameter is required", nil), c.isDevelopment)
		return
	}

	// --- Call repository ---
	pdfBytes, err := c.repository.DownloadInvoicePdf(r.Context(), billingAccountNo, billingMonth)
	if err != nil {
		c.logger.Error("Failed to download invoice PDF", "billingAccountNo", billingAccountNo, "billingMonth", billingMonth, "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	// --- 404: PDF not found ---
	if len(pdfBytes) == 0 {
		c.logger.Info("Invoice PDF not found", "billingAccountNo", billingAccountNo, "billingMonth", billingMonth)
		apierrors.WriteJSON(w, apierrors.NewNotFound("invoice PDF not found", nil), c.isDevelopment)
		return
	}

	filename := fmt.Sprintf("invoice_%s_%s.pdf", billingAccountNo, billingMonth)
	w.Header().Set("Content-Type", "application/pdf")
	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"%s\"", filename))
	w.Header().Set("Content-Length", fmt.Sprintf("%d", len(pdfBytes)))
	w.WriteHeader(http.StatusOK)
	w.Write(pdfBytes)
}

// RegisterRoutes registers all invoice routes with the router
func (c *InvoiceController) RegisterRoutes(router router.IRouter) {
	invoiceGroup := router.Group("/api/v1/invoice")
	invoiceGroup.GET("/downloadPdf", c.DownloadInvoicePdf)
	invoiceGroup.GET("/getInvoices", c.GetInvoices)
	invoiceGroup.GET("/getPaymentHistory", c.GetPaymentHistory)
}

// GetInvoices godoc
//
//	@Summary		Get invoices
//	@Description	Retrieves invoices for the given account number and optional invoice number
//	@Tags			invoices
//	@Accept			json
//	@Produce		json
//	@Param			accountNo	query		string	true	"Account No"
//	@Param			invoiceNo	query		string	false	"Invoice No"
//	@Success		200			{object}	entities.DataResponse{data=[]entities.InvoiceResponse}
//	@Failure		400			{object}	apierrors.ErrorResponse
//	@Failure		401			{object}	apierrors.ErrorResponse
//	@Failure		403			{object}	apierrors.ErrorResponse
//	@Failure		404			{object}	apierrors.ErrorResponse
//	@Failure		429			{object}	apierrors.ErrorResponse
//	@Failure		500			{object}	apierrors.ErrorResponse
//	@Failure		502			{object}	apierrors.ErrorResponse
//	@Failure		504			{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/invoice/getInvoices [get]
func (c *InvoiceController) GetInvoices(w http.ResponseWriter, r *http.Request) {
	// --- 400: Validate required parameters ---
	accountNo := r.URL.Query().Get("accountNo")
	if accountNo == "" {
		c.logger.Error("accountNo parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("accountNo query parameter is required", nil), c.isDevelopment)
		return
	}

	invoiceNo := r.URL.Query().Get("invoiceNo")

	// --- Call repository ---
	invoices, err := c.repository.GetInvoices(r.Context(), accountNo, invoiceNo)
	if err != nil {
		c.logger.Error("Failed to get invoices", "accountNo", accountNo, "invoiceNo", invoiceNo, "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	// --- Map to response entities ---
	invoiceResponses := make([]interface{}, len(invoices))
	for i := range invoices {
		invoiceResponses[i] = entities.FromCoreInvoice(&invoices[i])
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(entities.NewDataResponse(invoiceResponses))
}

// GetPaymentHistory godoc
//
//	@Summary		Get payment history
//	@Description	Retrieves payment history for the given account number with optional filters
//	@Tags			invoices
//	@Accept			json
//	@Produce		json
//	@Param			accountNo			query		string	true	"Account Number"
//	@Param			transactionType		query		string	false	"Transaction Type"
//	@Param			fromDate			query		string	false	"From Date"
//	@Param			toDate				query		string	false	"To Date"
//	@Param			returnLimit			query		int		false	"Return Limit"	default(100)
//	@Success		200					{object}	entities.DataResponse{data=entities.PaymentHistoryResponse}
//	@Failure		400					{object}	apierrors.ErrorResponse
//	@Failure		401					{object}	apierrors.ErrorResponse
//	@Failure		403					{object}	apierrors.ErrorResponse
//	@Failure		404					{object}	apierrors.ErrorResponse
//	@Failure		429					{object}	apierrors.ErrorResponse
//	@Failure		500					{object}	apierrors.ErrorResponse
//	@Failure		502					{object}	apierrors.ErrorResponse
//	@Failure		504					{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/invoice/getPaymentHistory [get]
func (c *InvoiceController) GetPaymentHistory(w http.ResponseWriter, r *http.Request) {
	// --- 400: Validate required parameters ---
	accountNo := r.URL.Query().Get("accountNo")
	if accountNo == "" {
		c.logger.Error("accountNo parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("accountNo query parameter is required", nil), c.isDevelopment)
		return
	}

	transactionType := r.URL.Query().Get("transactionType")
	fromDate := r.URL.Query().Get("fromDate")
	toDate := r.URL.Query().Get("toDate")

	returnLimit := 100
	returnLimitStr := r.URL.Query().Get("returnLimit")
	if returnLimitStr != "" {
		parsedLimit, err := strconv.Atoi(returnLimitStr)
		if err != nil {
			c.logger.Error("Invalid returnLimit parameter", "error", err)
			apierrors.WriteJSON(w, apierrors.NewBadRequest("returnLimit must be a valid integer", err), c.isDevelopment)
			return
		}
		returnLimit = parsedLimit
	}

	// --- Call repository ---
	paymentHistory, err := c.repository.GetPaymentHistory(r.Context(), accountNo, transactionType, fromDate, toDate, returnLimit)
	if err != nil {
		c.logger.Error("Failed to get payment history", "accountNo", accountNo, "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	// --- 404: Payment history not found ---
	if paymentHistory == nil {
		c.logger.Info("Payment history not found", "accountNo", accountNo)
		apierrors.WriteJSON(w, apierrors.NewNotFound("payment history not found", nil), c.isDevelopment)
		return
	}

	paymentHistoryResponse := entities.FromCorePaymentHistory(paymentHistory)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(entities.NewDataResponse([]interface{}{paymentHistoryResponse}))
}
