package controllers

import "net/http"

// IHealthController defines the interface for health check endpoints
type IHealthController interface {
	IController

	// HealthCheck returns the health status of the application
	HealthCheck(w http.ResponseWriter, r *http.Request)

	// ReadinessCheck returns whether the application is ready to accept traffic
	ReadinessCheck(w http.ResponseWriter, r *http.Request)

	// LivenessCheck returns whether the application is alive
	LivenessCheck(w http.ResponseWriter, r *http.Request)
}
