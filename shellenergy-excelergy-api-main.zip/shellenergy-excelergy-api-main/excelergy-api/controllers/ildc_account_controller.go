package controllers

import "net/http"

// ILdcAccountController defines the interface for LDC account endpoints
type ILdcAccountController interface {
	IController

	// GetLdcAccount returns the LDC account information
	GetLdcAccount(w http.ResponseWriter, r *http.Request)
}
