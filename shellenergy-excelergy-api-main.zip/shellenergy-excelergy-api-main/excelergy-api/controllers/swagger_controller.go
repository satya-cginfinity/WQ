package controllers

import (
	router "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/router"
	core_logger "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
	httpSwagger "github.com/swaggo/http-swagger/v2"

	_ "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/docs"
)

// SwaggerController implements the IController interface
type SwaggerController struct {
	logger core_logger.ILogger
}

// NewSwaggerController creates a new SwaggerController instance
func NewSwaggerController(logger core_logger.ILogger, router router.IRouter) IController {
	controller := &SwaggerController{
		logger: logger,
	}

	return controller
}

// RegisterRoutes registers all swagger documentation routes with the router
func (h *SwaggerController) RegisterRoutes(router router.IRouter) {
	swaggerGroup := router.Group("/swagger/")
	swaggerGroup.GET("/*any", httpSwagger.WrapHandler)
}
