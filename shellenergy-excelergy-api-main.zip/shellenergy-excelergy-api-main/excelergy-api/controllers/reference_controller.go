package controllers

import (
	"encoding/json"
	"net/http"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/entities"
	router "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/router"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
	core_logger "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"
)

// ReferenceController implements the IReferenceController interface
type ReferenceController struct {
	logger        core_logger.ILogger
	repository    repository.IReferenceRepository
	isDevelopment bool
}

// NewReferenceController creates a new ReferenceController instance
func NewReferenceController(logger core_logger.ILogger, repository repository.IReferenceRepository, router router.IRouter, cfg client.IClientConfig) IController {
	controller := &ReferenceController{
		logger:        logger,
		repository:    repository,
		isDevelopment: cfg.IsDevelopment(),
	}

	return controller
}

// GetReferenceCode godoc
//
//	@Summary		Get reference codes
//	@Description	Retrieves reference codes by code and domain name
//	@Tags			reference
//	@Accept			json
//	@Produce		json
//	@Param			code		query		string	true	"Code"
//	@Param			domainName	query		string	true	"Domain Name"
//	@Success		200			{object}	entities.DataResponse{data=[]entities.ReferenceCodeResponse}
//	@Failure		400			{object}	apierrors.ErrorResponse
//	@Failure		401			{object}	apierrors.ErrorResponse
//	@Failure		403			{object}	apierrors.ErrorResponse
//	@Failure		404			{object}	apierrors.ErrorResponse
//	@Failure		429			{object}	apierrors.ErrorResponse
//	@Failure		500			{object}	apierrors.ErrorResponse
//	@Failure		502			{object}	apierrors.ErrorResponse
//	@Failure		504			{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/reference/getReferenceCode [get]
func (c *ReferenceController) GetReferenceCode(w http.ResponseWriter, r *http.Request) {
	// --- 400: Validate request parameters ---
	code := r.URL.Query().Get("code")
	if code == "" {
		c.logger.Error("code parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("code query parameter is required", nil), c.isDevelopment)
		return
	}

	domainName := r.URL.Query().Get("domainName")
	if domainName == "" {
		c.logger.Error("domainName parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("domainName query parameter is required", nil), c.isDevelopment)
		return
	}

	// --- Call repository ---
	referenceCodes, err := c.repository.GetReferenceCode(r.Context(), code, domainName)
	if err != nil {
		c.logger.Error("Failed to get reference codes", "code", code, "domainName", domainName, "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	// --- 404: Reference codes not found ---
	if len(referenceCodes) == 0 {
		c.logger.Info("Reference codes not found", "code", code, "domainName", domainName)
		apierrors.WriteJSON(w, apierrors.NewNotFound("reference codes not found", nil), c.isDevelopment)
		return
	}

	referenceCodeResponses := entities.FromCoreReferenceCodes(referenceCodes)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(entities.NewDataResponse(referenceCodeResponses))
}

// RegisterRoutes registers all reference routes with the router
func (c *ReferenceController) RegisterRoutes(router router.IRouter) {
	referenceGroup := router.Group("/api/v1/reference")
	referenceGroup.GET("/getReferenceCode", c.GetReferenceCode)
}
