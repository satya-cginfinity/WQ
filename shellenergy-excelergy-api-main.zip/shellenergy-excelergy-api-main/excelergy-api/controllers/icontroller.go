package controllers

import router "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/router"

// IController defines the interface for controller endpoints
type IController interface {
	RegisterRoutes(router router.IRouter)
}
