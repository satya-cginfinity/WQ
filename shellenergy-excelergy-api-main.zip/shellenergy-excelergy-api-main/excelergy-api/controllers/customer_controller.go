package controllers

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/entities"
	router "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/router"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
	core_logger "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"
)

// CustomerController implements the ICustomerController interface
type CustomerController struct {
	logger        core_logger.ILogger
	repository    repository.ICustomerRepository
	isDevelopment bool
}

// NewCustomerController creates a new CustomerController instance
func NewCustomerController(logger core_logger.ILogger, repository repository.ICustomerRepository, router router.IRouter, cfg client.IClientConfig) IController {
	controller := &CustomerController{
		logger:        logger,
		repository:    repository,
		isDevelopment: cfg.IsDevelopment(),
	}

	return controller
}

// GetCustomer godoc
//
//	@Summary		Get customer by ID
//	@Description	Retrieves customer information by customer ID and username
//	@Tags			customers
//	@Accept			json
//	@Produce		json
//	@Param			customerId	query		int		true	"Customer ID"
//	@Param			username	query		string	true	"Username"
//	@Success		200			{object}	entities.CustomerResponse
//	@Failure		400			{object}	apierrors.ErrorResponse
//	@Failure		401			{object}	apierrors.ErrorResponse
//	@Failure		403			{object}	apierrors.ErrorResponse
//	@Failure		404			{object}	apierrors.ErrorResponse
//	@Failure		429			{object}	apierrors.ErrorResponse
//	@Failure		500			{object}	apierrors.ErrorResponse
//	@Failure		502			{object}	apierrors.ErrorResponse
//	@Failure		504			{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/customer/getCustomer [get]
func (c *CustomerController) GetCustomer(w http.ResponseWriter, r *http.Request) {
	// --- 400: Validate request parameters ---
	// customerId is required to look up the customer in Bridge.
	customerIdStr := r.URL.Query().Get("customerId")
	if customerIdStr == "" {
		c.logger.Error("customerId parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("customerId query parameter is required", nil), c.isDevelopment)
		return
	}

	// username is forwarded to the upstream API as part of the request context.
	username := r.URL.Query().Get("username")
	if username == "" {
		c.logger.Error("username parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("username query parameter is required", nil), c.isDevelopment)
		return
	}

	customerId, err := strconv.ParseUint(customerIdStr, 10, 64)
	if err != nil {
		c.logger.Error("Invalid customerId parameter", "error", err)
		apierrors.WriteJSON(w, apierrors.NewBadRequest("customerId must be a valid positive integer", err), c.isDevelopment)
		return
	}

	// --- Call repository ---
	customer, err := c.repository.GetCustomer(r.Context(), customerId, username)
	if err != nil {
		c.logger.Error("Failed to get customer", "customerId", customerId, "username", username, "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	// --- 404: Customer not found ---
	if customer == nil {
		c.logger.Info("Customer not found", "customerId", customerId)
		apierrors.WriteJSON(w, apierrors.NewNotFound("customer not found", nil), c.isDevelopment)
		return
	}

	customerResponse := entities.FromCoreCustomer(customer)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(entities.NewDataResponse([]interface{}{customerResponse}))
}

// GetCustomerAccounts godoc
//
//	@Summary		Get customer accounts by customer ID
//	@Description	Retrieves all accounts for a customer by customer ID and username
//	@Tags			customers
//	@Accept			json
//	@Produce		json
//	@Param			customerId	query		int		true	"Customer ID"
//	@Param			username	query		string		true	"Username"
//	@Success		200			{array}		entities.AccountResponse
//	@Failure		400			{object}	apierrors.ErrorResponse
//	@Failure		401			{object}	apierrors.ErrorResponse
//	@Failure		403			{object}	apierrors.ErrorResponse
//	@Failure		404			{object}	apierrors.ErrorResponse
//	@Failure		429			{object}	apierrors.ErrorResponse
//	@Failure		500			{object}	apierrors.ErrorResponse
//	@Failure		502			{object}	apierrors.ErrorResponse
//	@Failure		504			{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/customer/accounts [get]
func (c *CustomerController) GetCustomerAccounts(w http.ResponseWriter, r *http.Request) {
	// --- 400: Validate request parameters ---
	// customerId is required to look up the customer in Bridge.
	customerIdStr := r.URL.Query().Get("customerId")
	if customerIdStr == "" {
		c.logger.Error("customerId parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("customerId query parameter is required", nil), c.isDevelopment)
		return
	}

	// username is forwarded to the upstream API as part of the request context.
	username := r.URL.Query().Get("username")
	if username == "" {
		c.logger.Error("username parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("username query parameter is required", nil), c.isDevelopment)
		return
	}

	customerId, err := strconv.ParseUint(customerIdStr, 10, 64)
	if err != nil {
		c.logger.Error("Invalid customerId parameter", "error", err)
		apierrors.WriteJSON(w, apierrors.NewBadRequest("customerId must be a valid positive integer", err), c.isDevelopment)
		return
	}

	// --- Call repository ---
	accounts, err := c.repository.GetCustomerAccounts(r.Context(), customerId, username)
	if err != nil {
		c.logger.Error("Failed to get customer accounts", "customerId", customerId, "username", username, "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	// Convert core account entities into API response models.
	accountResponses := entities.FromCoreAccounts(accounts)
	if accountResponses == nil {
		// Always return an empty array instead of null for list endpoints.
		accountResponses = []entities.AccountResponse{}
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(entities.NewDataResponse(accountResponses))
}

// RegisterRoutes registers all customer routes with the router
func (c *CustomerController) RegisterRoutes(router router.IRouter) {
	customerGroup := router.Group("/api/v1/customer")
	customerGroup.GET("/getCustomer", c.GetCustomer)
	customerGroup.GET("/accounts", c.GetCustomerAccounts)
}
