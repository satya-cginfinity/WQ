package controllers

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/entities"
	router "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/router"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
	core_logger "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"
)

// LdcAccountController implements the ILdcAccountController interface
type LdcAccountController struct {
	logger        core_logger.ILogger
	repository    repository.ILdcAccountRepository
	isDevelopment bool
}

// NewLdcAccountController creates a new LdcAccountController instance
func NewLdcAccountController(logger core_logger.ILogger, repository repository.ILdcAccountRepository, router router.IRouter, cfg client.IClientConfig) IController {
	controller := &LdcAccountController{
		logger:        logger,
		repository:    repository,
		isDevelopment: cfg.IsDevelopment(),
	}

	return controller
}

// GetLdcAccount godoc
//
//	@Summary		Get LDC account
//	@Description	Retrieves an LDC account. At least one of customerId, ldcAccountId, or accountId must be provided.
//	@Tags			ldcAccount
//	@Accept			json
//	@Produce		json
//	@Param			customerId		query		int		false	"Customer ID"
//	@Param			ldcAccountId	query		int		false	"LDC Account ID"
//	@Param			accountId		query		int		false	"Account ID"
//	@Param			userName		query		string	false	"User Name"
//	@Success		200				{object}	entities.DataResponse{data=[]entities.LdcAccountResponse}
//	@Failure		400				{object}	apierrors.ErrorResponse
//	@Failure		401				{object}	apierrors.ErrorResponse
//	@Failure		403				{object}	apierrors.ErrorResponse
//	@Failure		404				{object}	apierrors.ErrorResponse
//	@Failure		429				{object}	apierrors.ErrorResponse
//	@Failure		500				{object}	apierrors.ErrorResponse
//	@Failure		502				{object}	apierrors.ErrorResponse
//	@Failure		504				{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/ldcAccount [get]
func (c *LdcAccountController) GetLdcAccount(w http.ResponseWriter, r *http.Request) {
	// --- 400: Validate request parameters ---
	var customerId *uint64
	customerIdStr := r.URL.Query().Get("customerId")
	if customerIdStr != "" {
		parsed, err := strconv.ParseUint(customerIdStr, 10, 64)
		if err != nil {
			c.logger.Error("Invalid customerId parameter", "error", err)
			apierrors.WriteJSON(w, apierrors.NewBadRequest("customerId must be a valid positive integer", err), c.isDevelopment)
			return
		}
		customerId = &parsed
	}

	var ldcAccountId *uint64
	ldcAccountIdStr := r.URL.Query().Get("ldcAccountId")
	if ldcAccountIdStr != "" {
		parsed, err := strconv.ParseUint(ldcAccountIdStr, 10, 64)
		if err != nil {
			c.logger.Error("Invalid ldcAccountId parameter", "error", err)
			apierrors.WriteJSON(w, apierrors.NewBadRequest("ldcAccountId must be a valid positive integer", err), c.isDevelopment)
			return
		}
		ldcAccountId = &parsed
	}

	var accountId *uint64
	accountIdStr := r.URL.Query().Get("accountId")
	if accountIdStr != "" {
		parsed, err := strconv.ParseUint(accountIdStr, 10, 64)
		if err != nil {
			c.logger.Error("Invalid accountId parameter", "error", err)
			apierrors.WriteJSON(w, apierrors.NewBadRequest("accountId must be a valid positive integer", err), c.isDevelopment)
			return
		}
		accountId = &parsed
	}

	// At least one of customerId, ldcAccountId, or accountId must be provided
	if customerId == nil && ldcAccountId == nil && accountId == nil {
		c.logger.Error("No ID parameter provided")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("at least one of customerId, ldcAccountId, or accountId must be provided", nil), c.isDevelopment)
		return
	}

	userName := r.URL.Query().Get("userName")

	// --- Call repository ---
	ldcAccount, err := c.repository.GetLdcAccount(r.Context(), customerId, ldcAccountId, accountId, userName)
	if err != nil {
		c.logger.Error("Failed to get LDC account", "customerId", derefUint64(customerId), "ldcAccountId", derefUint64(ldcAccountId), "accountId", derefUint64(accountId), "userName", userName, "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	// --- 404: LDC Account not found ---
	if ldcAccount == nil {
		c.logger.Info("LDC account not found", "customerId", derefUint64(customerId), "ldcAccountId", derefUint64(ldcAccountId), "accountId", derefUint64(accountId), "userName", userName)
		apierrors.WriteJSON(w, apierrors.NewNotFound("LDC account not found", nil), c.isDevelopment)
		return
	}

	ldcAccountResponse := entities.FromCoreLdcAccount(ldcAccount)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(entities.NewDataResponse([]interface{}{ldcAccountResponse}))
}

// RegisterRoutes registers all LDC account routes with the router
func (c *LdcAccountController) RegisterRoutes(router router.IRouter) {
	ldcAccountGroup := router.Group("/api/v1/ldcAccount")
	ldcAccountGroup.GET("", c.GetLdcAccount)
}

func derefUint64(p *uint64) interface{} {
	if p == nil {
		return nil
	}
	return *p
}
