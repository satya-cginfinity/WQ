package controllers

import "net/http"

// ICalendarController defines the interface for calendar endpoints
type ICalendarController interface {
	IController

	// GetCalendarHolidays returns the list of holidays for a given calendar Code
	GetCalendarHolidays(w http.ResponseWriter, r *http.Request)

	// GetCalendarByCode returns a calendar for a given calendar Code
	GetCalendarByCode(w http.ResponseWriter, r *http.Request)
}
