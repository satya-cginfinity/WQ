package controllers

import "net/http"

// IAccountController defines the interface for account endpoints
type IAccountController interface {
	IController

	// GetAccountById returns the account information by account ID
	GetAccountById(w http.ResponseWriter, r *http.Request)

	// GetAccount searches for accounts using the supplied AccountCriteria request body
	GetAccount(w http.ResponseWriter, r *http.Request)

	// GetAccountBalance returns the account balance details by account ID
	GetAccountBalance(w http.ResponseWriter, r *http.Request)

	// GetPaymentArrangement returns the payment arrangement list by account ID
	GetPaymentArrangement(w http.ResponseWriter, r *http.Request)

	// GetInvoiceDistribution returns the invoice distribution info list by account ID
	GetInvoiceDistribution(w http.ResponseWriter, r *http.Request)
}
