package controllers

import "net/http"

// IInvoiceController defines the interface for invoice endpoints
type IInvoiceController interface {
	IController

	// DownloadInvoicePdf downloads the invoice PDF for the given billing account and billing month
	DownloadInvoicePdf(w http.ResponseWriter, r *http.Request)

	// GetInvoices retrieves invoices for the given account number and optional invoice number
	GetInvoices(w http.ResponseWriter, r *http.Request)

	// GetPaymentHistory retrieves payment history for a given account number
	GetPaymentHistory(w http.ResponseWriter, r *http.Request)
}
