package controllers

import "net/http"

// ICustomerController defines the interface for customer endpoints
type ICustomerController interface {
	IController

	// GetCustomer returns the customer information
	GetCustomer(w http.ResponseWriter, r *http.Request)

	// GetCustomerAccounts returns all accounts for a customer
	GetCustomerAccounts(w http.ResponseWriter, r *http.Request)
}
