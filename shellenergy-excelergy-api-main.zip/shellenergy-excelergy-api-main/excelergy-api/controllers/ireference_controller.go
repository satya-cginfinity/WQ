package controllers

import "net/http"

// IReferenceController defines the interface for reference endpoints
type IReferenceController interface {
	IController

	// GetReferenceCode returns reference codes by code and domain name
	GetReferenceCode(w http.ResponseWriter, r *http.Request)
}
