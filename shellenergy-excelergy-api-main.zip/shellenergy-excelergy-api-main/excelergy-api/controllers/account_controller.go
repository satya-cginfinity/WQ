package controllers

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/apierrors"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/entities"
	router "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-api/router"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
	core_logger "github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/repository"
)

// AccountController implements the IAccountController interface
type AccountController struct {
	logger        core_logger.ILogger
	repository    repository.IAccountRepository
	isDevelopment bool
}

// NewAccountController creates a new AccountController instance
func NewAccountController(logger core_logger.ILogger, repository repository.IAccountRepository, router router.IRouter, cfg client.IClientConfig) IController {
	controller := &AccountController{
		logger:        logger,
		repository:    repository,
		isDevelopment: cfg.IsDevelopment(),
	}

	return controller
}

// GetAccountById godoc
//
//	@Summary		Get account by ID
//	@Description	Retrieves account information by account ID
//	@Tags			accounts
//	@Accept			json
//	@Produce		json
//	@Param			accountId	query		int	true	"Account ID"
//	@Success		200			{object}	entities.DataResponse{data=entities.AccountResponse}
//	@Failure		400			{object}	apierrors.ErrorResponse
//	@Failure		401			{object}	apierrors.ErrorResponse
//	@Failure		403			{object}	apierrors.ErrorResponse
//	@Failure		404			{object}	apierrors.ErrorResponse
//	@Failure		429			{object}	apierrors.ErrorResponse
//	@Failure		500			{object}	apierrors.ErrorResponse
//	@Failure		502			{object}	apierrors.ErrorResponse
//	@Failure		504			{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/account/getAccountById [get]
func (c *AccountController) GetAccountById(w http.ResponseWriter, r *http.Request) {
	// --- 400: Validate request parameters ---
	accountIdStr := r.URL.Query().Get("accountId")
	if accountIdStr == "" {
		c.logger.Error("accountId parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("accountId query parameter is required", nil), c.isDevelopment)
		return
	}

	accountId, err := strconv.ParseUint(accountIdStr, 10, 64)
	if err != nil {
		c.logger.Error("Invalid accountId parameter", "error", err)
		apierrors.WriteJSON(w, apierrors.NewBadRequest("accountId must be a valid positive integer", err), c.isDevelopment)
		return
	}

	// --- Call repository ---
	account, err := c.repository.GetAccountById(r.Context(), accountId)
	if err != nil {
		c.logger.Error("Failed to get account", "accountId", accountId, "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	// --- 404: Account not found ---
	if account == nil {
		c.logger.Info("Account not found", "accountId", accountId)
		apierrors.WriteJSON(w, apierrors.NewNotFound("account not found", nil), c.isDevelopment)
		return
	}

	accountResponse := entities.FromCoreAccount(account)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(entities.NewDataResponse([]interface{}{accountResponse}))
}

// GetAccount godoc
//
//	@Summary		Search accounts by criteria
//	@Description	Searches for accounts using the provided AccountCriteria.
//	@Tags			accounts
//	@Accept			json
//	@Produce		json
//	@Param			accountCriteria	body	entities.AccountCriteriaRequest	true	"Account search criteria"
//	@Success		200			{object}	entities.DataResponse{data=[]entities.AccountResponse}
//	@Failure		400			{object}	apierrors.ErrorResponse
//	@Failure		401			{object}	apierrors.ErrorResponse
//	@Failure		403			{object}	apierrors.ErrorResponse
//	@Failure		404			{object}	apierrors.ErrorResponse
//	@Failure		429			{object}	apierrors.ErrorResponse
//	@Failure		500			{object}	apierrors.ErrorResponse
//	@Failure		502			{object}	apierrors.ErrorResponse
//	@Failure		504			{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/account/getAccount [post]
func (c *AccountController) GetAccount(w http.ResponseWriter, r *http.Request) {
	// --- 400: Decode and validate request body ---
	var criteria entities.AccountCriteriaRequest
	if err := json.NewDecoder(r.Body).Decode(&criteria); err != nil {
		c.logger.Error("Failed to decode accountCriteria request body", "error", err)
		apierrors.WriteJSON(w, apierrors.NewBadRequest("request body must be a valid accountCriteria JSON object", err), c.isDevelopment)
		return
	}

	// --- Call repository ---
	accounts, err := c.repository.GetAccount(r.Context(), criteria.ToCoreAccountCriteria())
	if err != nil {
		c.logger.Error("Failed to get accounts", "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	accountResponses := entities.FromCoreAccounts(accounts)

	// --- 404: Account not found ---
	if len(accountResponses) == 0 {
		c.logger.Info("Account not found", "criteria", criteria)
		apierrors.WriteJSON(w, apierrors.NewNotFound("account not found", nil), c.isDevelopment)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(entities.NewDataResponse(accountResponses))
}

// GetAccountBalance godoc
//
//	@Summary		Get account balance by ID
//	@Description	Retrieves account balance details by account ID
//	@Tags			accounts
//	@Accept			json
//	@Produce		json
//	@Param			accountId	query		int	true	"Account ID"
//	@Success		200			{object}	entities.DataResponse{data=entities.AccountBalanceResponse}
//	@Failure		400			{object}	apierrors.ErrorResponse
//	@Failure		401			{object}	apierrors.ErrorResponse
//	@Failure		403			{object}	apierrors.ErrorResponse
//	@Failure		404			{object}	apierrors.ErrorResponse
//	@Failure		429			{object}	apierrors.ErrorResponse
//	@Failure		500			{object}	apierrors.ErrorResponse
//	@Failure		502			{object}	apierrors.ErrorResponse
//	@Failure		504			{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/account/accountBalance [get]
func (c *AccountController) GetAccountBalance(w http.ResponseWriter, r *http.Request) {
	// --- 400: Validate request parameters ---
	accountIdStr := r.URL.Query().Get("accountId")
	if accountIdStr == "" {
		c.logger.Error("accountId parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("accountId query parameter is required", nil), c.isDevelopment)
		return
	}

	accountId, err := strconv.ParseUint(accountIdStr, 10, 64)
	if err != nil {
		c.logger.Error("Invalid accountId parameter", "error", err)
		apierrors.WriteJSON(w, apierrors.NewBadRequest("accountId must be a valid positive integer", err), c.isDevelopment)
		return
	}

	// --- Call repository ---
	accountBalance, err := c.repository.GetAccountBalance(r.Context(), accountId)
	if err != nil {
		c.logger.Error("Failed to get account balance", "accountId", accountId, "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	// --- 404: Account balance not found ---
	if accountBalance == nil {
		c.logger.Info("Account balance not found", "accountId", accountId)
		apierrors.WriteJSON(w, apierrors.NewNotFound("account balance not found", nil), c.isDevelopment)
		return
	}

	accountBalanceResponse := entities.FromCoreAccountBalance(accountBalance)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(entities.NewDataResponse([]interface{}{accountBalanceResponse}))
}

// GetPaymentArrangement godoc
//
//	@Summary		Get payment arrangement by account ID
//	@Description	Retrieves payment arrangement list by account ID
//	@Tags			accounts
//	@Accept			json
//	@Produce		json
//	@Param			accountId	query		int	true	"Account ID"
//	@Success		200			{object}	entities.DataResponse{data=[]entities.PaymentArrangementResponse}
//	@Failure		400			{object}	apierrors.ErrorResponse
//	@Failure		401			{object}	apierrors.ErrorResponse
//	@Failure		403			{object}	apierrors.ErrorResponse
//	@Failure		404			{object}	apierrors.ErrorResponse
//	@Failure		429			{object}	apierrors.ErrorResponse
//	@Failure		500			{object}	apierrors.ErrorResponse
//	@Failure		502			{object}	apierrors.ErrorResponse
//	@Failure		504			{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/account/paymentArrangement [get]
func (c *AccountController) GetPaymentArrangement(w http.ResponseWriter, r *http.Request) {
	// --- 400: Validate request parameters ---
	accountIdStr := r.URL.Query().Get("accountId")
	if accountIdStr == "" {
		c.logger.Error("accountId parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("accountId query parameter is required", nil), c.isDevelopment)
		return
	}

	accountId, err := strconv.ParseUint(accountIdStr, 10, 64)
	if err != nil {
		c.logger.Error("Invalid accountId parameter", "error", err)
		apierrors.WriteJSON(w, apierrors.NewBadRequest("accountId must be a valid positive integer", err), c.isDevelopment)
		return
	}

	// --- Call repository ---
	paymentArrangements, err := c.repository.GetPaymentArrangement(r.Context(), accountId)
	if err != nil {
		c.logger.Error("Failed to get payment arrangement", "accountId", accountId, "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	paymentArrangementResponses := entities.FromCorePaymentArrangements(paymentArrangements)

	// --- 404: Payment arrangement not found ---
	if len(paymentArrangementResponses) == 0 {
		c.logger.Info("Payment arrangement not found", "accountId", accountId)
		apierrors.WriteJSON(w, apierrors.NewNotFound("payment arrangement not found", nil), c.isDevelopment)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(entities.NewDataResponse(paymentArrangementResponses))
}

// GetInvoiceDistribution godoc
//
//	@Summary		Get invoice distribution info by account ID
//	@Description	Retrieves the invoice distribution info list for the given account ID
//	@Tags			accounts
//	@Accept			json
//	@Produce		json
//	@Param			accountId	query		int	true	"Account ID"
//	@Success		200			{object}	entities.DataResponse{data=[]entities.InvoiceDistributionInfoResponse}
//	@Failure		400			{object}	apierrors.ErrorResponse
//	@Failure		401			{object}	apierrors.ErrorResponse
//	@Failure		403			{object}	apierrors.ErrorResponse
//	@Failure		404			{object}	apierrors.ErrorResponse
//	@Failure		429			{object}	apierrors.ErrorResponse
//	@Failure		500			{object}	apierrors.ErrorResponse
//	@Failure		502			{object}	apierrors.ErrorResponse
//	@Failure		504			{object}	apierrors.ErrorResponse
//	@Security		ApiKeyAuth
//	@Router			/api/v1/account/getInvoiceDistribution [get]
func (c *AccountController) GetInvoiceDistribution(w http.ResponseWriter, r *http.Request) {
	// --- 400: Validate request parameters ---
	accountIdStr := r.URL.Query().Get("accountId")
	if accountIdStr == "" {
		c.logger.Error("accountId parameter is missing")
		apierrors.WriteJSON(w, apierrors.NewBadRequest("accountId query parameter is required", nil), c.isDevelopment)
		return
	}

	accountId, err := strconv.ParseUint(accountIdStr, 10, 64)
	if err != nil {
		c.logger.Error("Invalid accountId parameter", "error", err)
		apierrors.WriteJSON(w, apierrors.NewBadRequest("accountId must be a valid positive integer", err), c.isDevelopment)
		return
	}

	// --- Call repository ---
	invDistInfos, err := c.repository.GetInvoiceDistribution(r.Context(), accountId)
	if err != nil {
		c.logger.Error("Failed to get invoice distribution", "accountId", accountId, "error", err)
		apiErr := apierrors.ClassifyRepositoryError(err)
		apierrors.WriteJSON(w, apiErr, c.isDevelopment)
		return
	}

	invDistResponses := entities.FromCoreInvoiceDistributionInfos(invDistInfos)

	// --- 404: Invoice distribution not found ---
	if len(invDistResponses) == 0 {
		c.logger.Info("Invoice distribution not found", "accountId", accountId)
		apierrors.WriteJSON(w, apierrors.NewNotFound("invoice distribution not found", nil), c.isDevelopment)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(entities.NewDataResponse(invDistResponses))
}

// RegisterRoutes registers all account routes with the router
func (c *AccountController) RegisterRoutes(router router.IRouter) {
	accountGroup := router.Group("/api/v1/account")
	accountGroup.GET("/getAccountById", c.GetAccountById)
	accountGroup.POST("/getAccount", c.GetAccount)
	accountGroup.GET("/accountBalance", c.GetAccountBalance)
	accountGroup.GET("/paymentArrangement", c.GetPaymentArrangement)
	accountGroup.GET("/getInvoiceDistribution", c.GetInvoiceDistribution)
}
