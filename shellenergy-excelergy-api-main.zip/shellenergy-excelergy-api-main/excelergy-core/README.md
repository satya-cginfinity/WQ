# excelergy-core

Description: This is the core functionality of the API for Excelergy

repo-team-owner: @sede-enterprise/teams/ses-backoffice-admin

created-by: David Alcazar (David.Alcazar@shellenergy.com)

---

## 📁 Project Structure & Architecture

This is the **core business logic layer** of the Excelergy application. It contains framework-agnostic code that can be used across multiple interfaces (REST API, CLI, batch jobs, etc.). The core follows the **Repository Pattern** and **Interface Segregation Principle**.

### Folder Structure

```
excelergy-core/
├── client/          # HTTP client for external APIs
├── entities/        # Domain models/data structures
├── logger/          # Logging interface
└── repository/      # Data access layer
```

### 🎯 Architectural Decisions

#### 1. **Framework-Agnostic Core**
- **Why**: Core business logic should not depend on HTTP frameworks, routing, or presentation concerns
- **Implementation**: No dependencies on Gin, HTTP handlers, or web frameworks
- **Benefits**:
  - Can be used by multiple interfaces (REST, GraphQL, CLI, workers)
  - Easier to test without spinning up web servers
  - Business logic remains portable

#### 2. **Repository Pattern**
- **Why**: Abstracts data access and external API calls
- **Implementation**: Repositories handle all I/O operations (HTTP calls, database queries)
- **Benefits**:
  - Easy to mock for testing
  - Centralized data access logic
  - Can switch data sources without affecting business logic

#### 3. **Interface-Driven Design**
- **Why**: Promotes testability and flexibility
- **Implementation**: Every component defines an interface
- **Benefits**:
  - Easy to create test doubles
  - Clear contracts between layers
  - Supports dependency injection

### 📂 Package Details

#### **client/**
- **Purpose**: HTTP client for making requests to external APIs
- **Responsibilities**:
  - Configure HTTP client with timeouts, TLS settings
  - Handle authentication (bearer tokens)
  - Perform GET, POST, PUT, DELETE requests
  - Log requests and responses
- **Key Design Decisions**:
  - **TLS Configuration**: Supports insecure connections in development mode
  - **Context Support**: All methods accept `context.Context` for cancellation/timeouts
  - **Logging**: Detailed request/response logging for debugging
  - **Abstraction**: `IClient` interface allows swapping implementations

**Implementation Highlights**:
```go
IClient interface {
    Get(ctx, path, pathParams, queryParams, headers)
    Post(ctx, path, pathParams, queryParams, body, headers)
    Put(ctx, path, pathParams, queryParams, body, headers)
    Delete(ctx, path, pathParams, queryParams, headers)
    Patch(ctx, path, pathParams, queryParams, body, headers)
}
```

**Path Parameters**: Replace placeholders in the path (e.g., `{id}` → `123`)
**Query Parameters**: Append URL-encoded query strings (e.g., `?key=value&other=data`)

**Usage Examples**:
```go
// Query parameters only
queryParams := map[string]string{"customerId": "123", "includeDetails": "true"}
client.Get(ctx, "Customer/Get", nil, queryParams, nil)
// Results in: /Customer/Get?customerId=123&includeDetails=true

// Path parameters only
pathParams := map[string]string{"id": "456"}
client.Get(ctx, "Customer/{id}", pathParams, nil, nil)
// Results in: /Customer/456

// Both path and query parameters
pathParams := map[string]string{"id": "456"}
queryParams := map[string]string{"format": "json"}
client.Get(ctx, "Customer/{id}/details", pathParams, queryParams, nil)
// Results in: /Customer/456/details?format=json
```

**Configuration**: Reads from `IClientConfig` interface (implemented by API config):
- Base URL for external API
- Request timeout
- Development mode flag
- Authentication token

#### **entities/**
- **Purpose**: Define domain models and data structures
- **Responsibilities**:
  - Represent business entities
  - Define data transfer objects (DTOs)
  - Provide JSON serialization tags
- **Key Design Decisions**:
  - **Pure Data Structures**: No business logic in entities
  - **JSON Tags**: Enable seamless serialization/deserialization
  - **Shared Across Layers**: Used by repositories, controllers, and external systems

**Why Separate Package**: 
- Entities are shared between multiple packages
- Prevents circular dependencies
- Single source of truth for data models

#### **logger/**
- **Purpose**: Provide logging abstraction
- **Responsibilities**:
  - Define logging interface (`ILogger`)
  - Support structured logging
  - Multiple log levels (Info, Error, Debug, etc.)
- **Key Design Decisions**:
  - **Interface Only**: Core defines the contract, API layer provides implementation
  - **Framework Agnostic**: Not tied to any specific logging library
  - **Dependency Injection**: Logger passed to all components needing it

**Why in Core**: 
- Repositories and clients need logging
- Interface allows different implementations (Zap, Logrus, etc.)
- Consistent logging across all layers

```go
ILogger interface {
    Info(msg string)
    Error(msg string)
    Debug(msg string)
    // ... other levels
}
```

#### **repository/**
- **Purpose**: Data access layer for business entities
- **Responsibilities**:
  - Fetch data from external APIs
  - Parse and transform responses
  - Handle data access errors
  - Return domain entities
- **Key Design Decisions**:
  - **Interface Per Repository**: Each domain entity has its own repository interface
  - **Context Propagation**: All methods accept `context.Context` for timeouts/cancellation
  - **Error Handling**: Wrap errors with context for debugging
  - **Client Abstraction**: Uses `IClient` interface, not concrete HTTP client

**Example Pattern**:
```go
type ICustomerRepository interface {
    GetCustomer(ctx context.Context, customerId uint64) (*entities.Customer, error)
}

type CustomerRepository struct {
    logger logger.ILogger
    client client.IClient
}
```

**Why This Pattern**:
- Testable: Mock the client interface in tests
- Clear responsibilities: One repository per aggregate root
- Error propagation: Enriches errors with context before returning
- Logging: Structured logs for debugging data access issues

### 🏗️ Layered Architecture in Core

```
┌─────────────────────────────────────┐
│         Repository Layer            │
│   - Business logic orchestration    │
│   - Data access coordination        │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│          Client Layer               │
│   - HTTP communication              │
│   - Request/response handling       │
│   - Authentication                  │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│       External APIs                 │
│   - Third-party services            │
│   - Backend systems                 │
└─────────────────────────────────────┘
```

### 🔄 Data Flow

1. **Controller** (in API layer) calls **Repository** method
2. **Repository** uses **Client** to make HTTP request
3. **Client** communicates with **External API**
4. **Client** returns raw response to **Repository**
5. **Repository** parses response into **Entity**
6. **Repository** returns **Entity** to **Controller**
7. **Controller** formats **Entity** as HTTP response

### 🎨 Design Principles Applied

#### **Single Responsibility Principle**
- Each package has one clear purpose
- Repositories handle data access, not HTTP concerns
- Client handles HTTP, not business logic

#### **Dependency Inversion Principle**
- High-level modules (repositories) depend on abstractions (IClient)
- Low-level modules (HTTPClient) implement abstractions
- Both depend on interfaces, not concrete types

#### **Interface Segregation Principle**
- Small, focused interfaces (IClient, ILogger, ICustomerRepository)
- Components only depend on methods they use
- Easy to implement and mock

#### **Open/Closed Principle**
- Core is open for extension (add new repositories)
- Closed for modification (existing repositories don't change)
- New functionality added through new components

### 🧪 Testing Strategy

The core is designed for easy testing:

1. **Repository Tests**: Mock `IClient` interface
2. **Client Tests**: Mock HTTP transport or use test servers
3. **Integration Tests**: Use real HTTP client against test APIs

**Example Mock Strategy**:
```go
type MockClient struct{}
func (m *MockClient) Get(ctx, path, pathParams, queryParams, headers) ([]byte, error) {
    return []byte(`{"customerId": 123}`), nil
}
```

### 🔗 Integration with excelergy-api

The API layer consumes core by:
- **Importing packages**: `excelergy-core/repository`, `excelergy-core/entities`
- **Dependency injection**: API provides concrete implementations (HTTPClient, Logger)
- **Configuration**: API's config implements core's config interfaces
- **Business logic**: Controllers delegate to repositories

**Separation of Concerns**:
- **Core**: What to do (business logic)
- **API**: How to present it (HTTP, JSON, status codes)

### 📝 Best Practices

1. **No HTTP in Core**: Use `context.Context`, not `http.Request`
2. **Return Entities**: Repositories return domain models, not DTOs
3. **Error Wrapping**: Add context to errors as they bubble up
4. **Interface Dependencies**: Always depend on interfaces defined in core
5. **Logging**: Log errors in repositories before returning
6. **Context Propagation**: Pass context through all layers for timeout/cancellation

### 🚀 Future Extensibility

This architecture easily supports:
- **New Data Sources**: Add new repository implementations (database, cache)
- **New Entities**: Add new packages under `entities/`
- **New Repositories**: Follow existing pattern
- **New Interfaces**: Core can serve GraphQL, gRPC, CLI without changes
- **Caching**: Add caching layer between repository and client
- **Batch Operations**: Add methods to repositories for bulk operations

The core remains stable while presentation layers evolve.

---

## 🚀 Getting Started

### Prerequisites

- **Go**: 1.25 or higher
- **Git**: For cloning the repository

### Installation

```bash
# Clone the repository
git clone https://github.com/sede-enterprise/shellenergy-excelergy-api.git
cd shellenergy-excelergy-api/excelergy-core

# Install dependencies
go mod download
```

### Using as a Module

The `excelergy-core` is designed to be imported as a Go module by other projects (like `excelergy-api`).

In your project's `go.mod`:
```go
require (
    github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core v0.0.0
)
```

For local development, use module replacement:
```go
replace github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core => ../excelergy-core
```

---

## 🧪 Testing

### Running Tests

```bash
# Run all tests
go test ./...

# Run tests with verbose output
go test -v ./...

# Run tests with coverage
go test -cover ./...

# Generate detailed coverage report
go test -coverprofile=coverage.out ./...
go tool cover -html=coverage.out -o coverage.html

# Open coverage report in browser
go tool cover -html=coverage.out
```

### Test Structure

Core modules should have comprehensive unit tests:

```
excelergy-core/
├── client/
│   ├── http_client.go
│   └── http_client_test.go
├── entities/
│   └── customer_test.go
└── repository/
    ├── customer_repository.go
    └── customer_repository_test.go
```

### Testing Best Practices

#### 1. **Repository Testing**

Mock the `IClient` interface to test repository logic without making real HTTP calls:

```go
// mock_client_test.go
type MockClient struct {
    GetFunc func(ctx context.Context, path string, headers map[string]string) ([]byte, error)
}

func (m *MockClient) Get(ctx context.Context, path string, headers map[string]string) ([]byte, error) {
    if m.GetFunc != nil {
        return m.GetFunc(ctx, path, headers)
    }
    return nil, nil
}

// customer_repository_test.go
func TestCustomerRepository_GetCustomer(t *testing.T) {
    mockLogger := &MockLogger{}
    mockClient := &MockClient{
        GetFunc: func(ctx context.Context, path string, pathParams map[string]string, queryParams map[string]string, headers map[string]string) ([]byte, error) {
            return []byte(`{"customerId": 123, "name": "Test Customer"}`), nil
        },
    }
    
    repo := NewCustomerRepository(mockLogger, mockClient)
    customer, err := repo.GetCustomer(context.Background(), 123)
    
    assert.NoError(t, err)
    assert.NotNil(t, customer)
    assert.Equal(t, uint64(123), customer.CustomerId)
}
```

#### 2. **Client Testing**

Use `httptest` package to test HTTP client without external dependencies:

```go
func TestHTTPClient_Get(t *testing.T) {
    // Create test server
    server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        w.WriteHeader(http.StatusOK)
        w.Write([]byte(`{"result": "success"}`))
    }))
    defer server.Close()
    
    // Create client with test server URL
    config := &MockConfig{BaseURL: server.URL}
    logger := &MockLogger{}
    client := NewHTTPClient(config, logger)
    
    // Test GET request
    resp, err := client.Get(context.Background(), "/test", nil, nil, nil)
    
    assert.NoError(t, err)
    assert.Contains(t, string(resp), "success")
}
```

#### 3. **Entity Testing**

Test JSON serialization/deserialization:

```go
func TestCustomer_JSONMarshaling(t *testing.T) {
    customer := &Customer{
        CustomerId: 123,
        Name:      "Test Customer",
    }
    
    // Marshal to JSON
    jsonData, err := json.Marshal(customer)
    assert.NoError(t, err)
    
    // Unmarshal back
    var decoded Customer
    err = json.Unmarshal(jsonData, &decoded)
    assert.NoError(t, err)
    assert.Equal(t, customer.CustomerId, decoded.CustomerId)
}
```

#### 4. **Table-Driven Tests**

Use table-driven tests for multiple scenarios:

```go
func TestCustomerRepository_GetCustomer_Errors(t *testing.T) {
    tests := []struct {
        name          string
        customerId    uint64
        mockResponse  []byte
        mockError     error
        expectedError bool
    }{
        {
            name:          "successful fetch",
            customerId:    123,
            mockResponse:  []byte(`{"customerId": 123}`),
            mockError:     nil,
            expectedError: false,
        },
        {
            name:          "network error",
            customerId:    456,
            mockResponse:  nil,
            mockError:     errors.New("network timeout"),
            expectedError: true,
        },
        {
            name:          "invalid JSON",
            customerId:    789,
            mockResponse:  []byte(`{invalid json}`),
            mockError:     nil,
            expectedError: true,
        },
    }
    
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            mockClient := &MockClient{
                GetFunc: func(ctx context.Context, path string, headers map[string]string) ([]byte, error) {
                    return tt.mockResponse, tt.mockError
                },
            }
            
            repo := NewCustomerRepository(&MockLogger{}, mockClient)
            _, err := repo.GetCustomer(context.Background(), tt.customerId)
            
            if tt.expectedError {
                assert.Error(t, err)
            } else {
                assert.NoError(t, err)
            }
        })
    }
}
```

### Running Specific Tests

```bash
# Run tests in specific package
go test ./repository/...

# Run specific test function
go test -run TestCustomerRepository_GetCustomer ./repository/

# Run tests with race detection
go test -race ./...

# Run tests with timeout
go test -timeout 30s ./...
```

### Coverage Goals

Aim for:
- **Repository layer**: 80%+ coverage
- **Client layer**: 75%+ coverage
- **Entities**: 90%+ coverage (if containing logic)

### Integration Testing

For integration tests with real external APIs:

```go
// +build integration

func TestCustomerRepository_Integration(t *testing.T) {
    if testing.Short() {
        t.Skip("Skipping integration test")
    }
    
    // Use real config and client
    config := &RealConfig{}
    logger := &RealLogger{}
    client := NewHTTPClient(config, logger)
    repo := NewCustomerRepository(logger, client)
    
    // Test against real API
    customer, err := repo.GetCustomer(context.Background(), 123)
    assert.NoError(t, err)
    assert.NotNil(t, customer)
}
```

Run integration tests:
```bash
# Skip integration tests (default)
go test ./...

# Run only integration tests
go test -tags=integration ./...

# Run all tests including integration
go test -tags=integration -v ./...
```

---

## 🔧 Development Guidelines

### Adding a New Repository

1. **Define the interface** in `repository/i[name]_repository.go`:
```go
type IProductRepository interface {
    GetProduct(ctx context.Context, productId uint64) (*entities.Product, error)
}
```

2. **Create the entity** in `entities/product.go`:
```go
type Product struct {
    ProductId   uint64 `json:"productId"`
    Name        string `json:"name"`
    Description string `json:"description"`
}
```

3. **Implement the repository** in `repository/product_repository.go`:
```go
type ProductRepository struct {
    logger logger.ILogger
    client client.IClient
}

func NewProductRepository(logger logger.ILogger, client client.IClient) IProductRepository {
    return &ProductRepository{
        logger: logger,
        client: client,
    }
}

func (r *ProductRepository) GetProduct(ctx context.Context, productId uint64) (*entities.Product, error) {
    queryParams := map[string]string{"productId": fmt.Sprintf("%d", productId)}
    bytes, err := r.client.Get(ctx, "Product/Get", nil, queryParams, nil)
    if err != nil {
        r.logger.Error(fmt.Sprintf("failed to get product from API: %v", err))
        return nil, fmt.Errorf("failed to get product from API: %w", err)
    }

    var product entities.Product
    if err := json.Unmarshal(bytes, &product); err != nil {
        r.logger.Error(fmt.Sprintf("failed to unmarshal product data: %v", err))
        return nil, fmt.Errorf("failed to unmarshal product data: %w", err)
    }

    return &product, nil
}
```

4. **Write tests** in `repository/product_repository_test.go`

5. **Register in API layer** via dependency injection

### Adding a New Entity

1. Create file in `entities/[name].go`
2. Define struct with JSON tags
3. Add any helper methods if needed
4. Write serialization tests
5. Document the entity's purpose

### Error Handling Pattern

Always wrap errors with context:

```go
if err != nil {
    r.logger.Error(fmt.Sprintf("operation failed: %v", err))
    return nil, fmt.Errorf("operation failed: %w", err)
}
```

This allows error chains to be traced back through the call stack.

### Logging Best Practices

- **Info**: Successful operations, state changes
- **Error**: Failures, exceptions, unexpected conditions
- **Debug**: Detailed diagnostic information (not in production)

```go
r.logger.Info(fmt.Sprintf("fetching customer %d", customerId))
r.logger.Error(fmt.Sprintf("failed to fetch customer %d: %v", customerId, err))
```

### Context Usage

Always accept and propagate `context.Context`:

```go
func (r *Repository) FetchData(ctx context.Context, id uint64) (*Entity, error) {
    // Pass context to client with path and query parameters
    pathParams := map[string]string{"id": fmt.Sprintf("%d", id)}
    data, err := r.client.Get(ctx, path, pathParams, nil, nil)
    
    // Check for context cancellation
    select {
    case <-ctx.Done():
        return nil, ctx.Err()
    default:
        // Continue processing
    }
}
```

Benefits:
- Request timeouts
- Cancellation propagation
- Request-scoped values

---

## 🔍 Code Quality

### Linting

```bash
# Install golangci-lint
go install github.com/golangci/golangci-lint/cmd/golangci-lint@latest

# Run linter
golangci-lint run

# Run with auto-fix
golangci-lint run --fix
```

### Formatting

```bash
# Format code
go fmt ./...

# Organize imports
goimports -w .
```

### Static Analysis

```bash
# Run go vet
go vet ./...

# Check for common mistakes
staticcheck ./...
```

---

## 📦 Building & Versioning

### Building the Module

```bash
# Verify module
go mod verify

# Tidy dependencies
go mod tidy

# Vendor dependencies (optional)
go mod vendor
```

### Versioning

This module follows semantic versioning (semver):
- **Major**: Breaking changes
- **Minor**: New features (backward compatible)
- **Patch**: Bug fixes

Tag releases:
```bash
git tag v1.0.0
git push origin v1.0.0
```

---

## 🐛 Troubleshooting

### Common Issues

**Module not found**:
```bash
# Clear module cache
go clean -modcache

# Re-download dependencies
go mod download
```

**Import cycle errors**:
- Ensure entities package has no external dependencies
- Repositories should only depend on client, logger, and entities
- Client should only depend on logger

**Test failures**:
```bash
# Run with verbose output
go test -v ./...

# Run specific test with debugging
go test -v -run TestName ./package/
```

---

## 📖 Additional Resources

- [Go Testing Documentation](https://golang.org/pkg/testing/)
- [Go Modules Reference](https://go.dev/ref/mod)
- [Effective Go](https://golang.org/doc/effective_go)
- [Go Code Review Comments](https://github.com/golang/go/wiki/CodeReviewComments)
- [Table Driven Tests](https://github.com/golang/go/wiki/TableDrivenTests)
