package client

type IClientConfig interface {
	IsDevelopment() bool
	GetHTTPBaseURL() string
	GetHTTPTimeout() int
	GetHTTPToken() string
}
