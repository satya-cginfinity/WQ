package client

import (
	"context"
	"crypto/tls"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
)

// HTTPClient implements the IClient interface for HTTP requests
type HTTPClient struct {
	baseURL    string
	httpClient *http.Client
	authToken  string
	logger     logger.ILogger
}

// NewHTTPClient creates a new HTTP client instance
func NewHTTPClient(config IClientConfig, logger logger.ILogger) IClient {
	// Create a custom transport with TLS configuration to skip certificate verification
	transport := &http.Transport{
		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: config.IsDevelopment(),
		},
	}

	if config.IsDevelopment() {
		logger.Warn("TLS certificate verification is DISABLED in development mode. This exposes the application to man-in-the-middle attacks. Use only in isolated environments.")
	}

	return &HTTPClient{
		baseURL: config.GetHTTPBaseURL(),
		httpClient: &http.Client{
			Timeout:   time.Duration(config.GetHTTPTimeout()) * time.Second,
			Transport: transport,
		},
		authToken: config.GetHTTPToken(),
		logger:    logger,
	}
}

// Get performs a GET request to the specified path
func (c *HTTPClient) Get(ctx context.Context, path string, pathParams map[string]string, queryParams map[string]string, headers map[string]string) ([]byte, error) {
	return c.doRequest(ctx, http.MethodGet, path, pathParams, queryParams, nil, headers)
}

// Post performs a POST request to the specified path with a body
func (c *HTTPClient) Post(ctx context.Context, path string, pathParams map[string]string, queryParams map[string]string, body io.Reader, headers map[string]string) ([]byte, error) {
	return c.doRequest(ctx, http.MethodPost, path, pathParams, queryParams, body, headers)
}

// Put performs a PUT request to the specified path with a body
func (c *HTTPClient) Put(ctx context.Context, path string, pathParams map[string]string, queryParams map[string]string, body io.Reader, headers map[string]string) ([]byte, error) {
	return c.doRequest(ctx, http.MethodPut, path, pathParams, queryParams, body, headers)
}

// Delete performs a DELETE request to the specified path
func (c *HTTPClient) Delete(ctx context.Context, path string, pathParams map[string]string, queryParams map[string]string, headers map[string]string) ([]byte, error) {
	return c.doRequest(ctx, http.MethodDelete, path, pathParams, queryParams, nil, headers)
}

// Patch performs a PATCH request to the specified path with a body
func (c *HTTPClient) Patch(ctx context.Context, path string, pathParams map[string]string, queryParams map[string]string, body io.Reader, headers map[string]string) ([]byte, error) {
	return c.doRequest(ctx, http.MethodPatch, path, pathParams, queryParams, body, headers)
}

// doRequest is a helper method to perform the actual HTTP request
func (c *HTTPClient) doRequest(ctx context.Context, method, path string, pathParams map[string]string, queryParams map[string]string, body io.Reader, headers map[string]string) ([]byte, error) {
	// Build the path with path parameters
	finalPath := path
	for key, value := range pathParams {
		placeholder := fmt.Sprintf("{%s}", key)
		finalPath = replacePathParam(finalPath, placeholder, value)
	}

	// Build the URL with query parameters
	fullURL := fmt.Sprintf("%s%s", c.baseURL, finalPath)
	if len(queryParams) > 0 {
		queryString := buildQueryString(queryParams)
		fullURL = fmt.Sprintf("%s?%s", fullURL, queryString)
	}

	url := fullURL

	req, err := http.NewRequestWithContext(ctx, method, url, body)
	if err != nil {
		c.logger.Error(fmt.Sprintf("failed to create request: %v", err))
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	// Set authorization header if token exists
	if c.authToken != "" {
		req.Header.Set("X-Api", c.authToken)
	}

	// Set headers
	for key, value := range headers {
		req.Header.Set(key, value)
	}
	// Set default Content-Type if not provided and body exists
	if body != nil && req.Header.Get("Content-Type") == "" {
		req.Header.Set("Content-Type", "application/json")
	}

	resp, err := c.httpClient.Do(req)
	if err != nil {
		c.logger.Error(fmt.Sprintf("failed to execute request: %v", err))
		return nil, fmt.Errorf("failed to execute request: %w", err)
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		c.logger.Error(fmt.Sprintf("failed to read response body: %v", err))
		return nil, fmt.Errorf("failed to read response body: %w", err)
	}

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		c.logger.Error(fmt.Sprintf("request failed with status %d: %s", resp.StatusCode, string(respBody)))
		return respBody, fmt.Errorf("request failed with status %d: %s", resp.StatusCode, string(respBody))
	}

	return respBody, nil
}

// replacePathParam replaces a placeholder in the path with the actual value
func replacePathParam(path, placeholder, value string) string {
	return strings.ReplaceAll(path, placeholder, value)
}

// buildQueryString builds a URL-encoded query string from a map of parameters
func buildQueryString(queryParams map[string]string) string {
	params := url.Values{}
	for key, value := range queryParams {
		params.Add(key, value)
	}
	return params.Encode()
}
