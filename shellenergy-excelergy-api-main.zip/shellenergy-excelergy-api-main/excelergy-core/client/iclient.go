package client

import (
	"context"
	"io"
)

// IClient defines the interface for making HTTP API requests
type IClient interface {
	// Get performs a GET request to the specified path
	Get(ctx context.Context, path string, pathParams map[string]string, queryParams map[string]string, headers map[string]string) ([]byte, error)

	// Post performs a POST request to the specified path with a body
	Post(ctx context.Context, path string, pathParams map[string]string, queryParams map[string]string, body io.Reader, headers map[string]string) ([]byte, error)

	// Put performs a PUT request to the specified path with a body
	Put(ctx context.Context, path string, pathParams map[string]string, queryParams map[string]string, body io.Reader, headers map[string]string) ([]byte, error)

	// Delete performs a DELETE request to the specified path
	Delete(ctx context.Context, path string, pathParams map[string]string, queryParams map[string]string, headers map[string]string) ([]byte, error)

	// Patch performs a PATCH request to the specified path with a body
	Patch(ctx context.Context, path string, pathParams map[string]string, queryParams map[string]string, body io.Reader, headers map[string]string) ([]byte, error)
}
