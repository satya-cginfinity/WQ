package repository

import (
	"context"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type ICalendarRepository interface {
	// GetCalendarHolidays retrieves the list of holidays for a given calendar Code
	GetCalendarHolidays(ctx context.Context, calendarCode string) ([]entities.Holiday, error)

	// GetCalendarByCode retrieves a calendar by its calendar Code
	GetCalendarByCode(ctx context.Context, calendarCode string) (*entities.Calendar, error)
}
