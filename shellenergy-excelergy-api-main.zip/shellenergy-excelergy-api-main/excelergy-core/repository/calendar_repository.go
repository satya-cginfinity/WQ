package repository

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
)

// CalendarRepository is an implementation of ICalendarRepository
type CalendarRepository struct {
	logger logger.ILogger
	client client.IClient
}

// NewCalendarRepository creates a new CalendarRepository instance
func NewCalendarRepository(logger logger.ILogger, client client.IClient) ICalendarRepository {
	return &CalendarRepository{
		logger: logger,
		client: client,
	}
}

// GetCalendarHolidays retrieves the list of holidays for a given calendar Code from the external API
func (r *CalendarRepository) GetCalendarHolidays(ctx context.Context, calendarCode string) ([]entities.Holiday, error) {
	queryParams := map[string]string{"calendarCode": calendarCode}
	const path = "Calendar/GetCalendarHolidays"
	responseBytes, err := r.client.Get(ctx, path, nil, queryParams, nil)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to get calendar holidays from API: %v", err))

		// Detect upstream HTTP status from the error message produced by the HTTP client.
		upstreamStatus := 0
		if strings.Contains(err.Error(), "request failed with status") {
			fmt.Sscanf(err.Error(), "request failed with status %d", &upstreamStatus)
		}

		return nil, &UpstreamError{
			StatusCode: upstreamStatus,
			Message:    "failed to get calendar holidays from upstream API",
			Err:        err,
		}
	}

	var response entities.BridgeResult[[]entities.Holiday]
	if err := json.Unmarshal(responseBytes, &response); err != nil {
		r.logger.Error(fmt.Sprintf("failed to unmarshal calendar holidays data: %v", err))
		return nil, &UpstreamError{
			StatusCode: 0,
			Message:    "failed to unmarshal upstream response",
			Err:        err,
		}
	}

	// Non-2xx upstream status → real error
	if response.Status < 200 || response.Status >= 300 {
		return nil, &UpstreamError{
			StatusCode: int(response.Status),
			Message:    fmt.Sprintf("upstream API returned an error: %s", response.Error),
			Err:        fmt.Errorf("upstream status %d: %s", response.Status, response.Error),
		}
	}

	// 2xx with nil result → treat as not-found so the controller can return 404
	if response.Result == nil {
		return nil, nil
	}

	return response.Result, nil
}

// GetCalendarByCode retrieves a calendar by its calendar Code from the external API
func (r *CalendarRepository) GetCalendarByCode(ctx context.Context, calendarCode string) (*entities.Calendar, error) {
	queryParams := map[string]string{"calendarCode": calendarCode}
	const path = "Calendar/GetCalendarByCode"
	responseBytes, err := r.client.Get(ctx, path, nil, queryParams, nil)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to get calendar by code from API: %v", err))

		// Detect upstream HTTP status from the error message produced by the HTTP client.
		upstreamStatus := 0
		if strings.Contains(err.Error(), "request failed with status") {
			fmt.Sscanf(err.Error(), "request failed with status %d", &upstreamStatus)
		}

		return nil, &UpstreamError{
			StatusCode: upstreamStatus,
			Message:    "failed to get calendar by code from upstream API",
			Err:        err,
		}
	}

	var response entities.BridgeResult[*entities.Calendar]
	if err := json.Unmarshal(responseBytes, &response); err != nil {
		r.logger.Error(fmt.Sprintf("failed to unmarshal calendar data: %v", err))
		return nil, &UpstreamError{
			StatusCode: 0,
			Message:    "failed to unmarshal upstream response",
			Err:        err,
		}
	}

	// Non-2xx upstream status → real error
	if response.Status < 200 || response.Status >= 300 {
		return nil, &UpstreamError{
			StatusCode: int(response.Status),
			Message:    fmt.Sprintf("upstream API returned an error: %s", response.Error),
			Err:        fmt.Errorf("upstream status %d: %s", response.Status, response.Error),
		}
	}

	// 2xx with nil result → treat as not-found so the controller can return 404
	if response.Result == nil {
		return nil, nil
	}

	return response.Result, nil
}
