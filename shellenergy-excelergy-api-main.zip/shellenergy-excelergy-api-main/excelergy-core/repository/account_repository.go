package repository

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
)

// UpstreamError wraps an error from the upstream (Fusion) API and carries
// the HTTP status code that the upstream returned.
type UpstreamError struct {
	StatusCode int
	Message    string
	Err        error
}

func (e *UpstreamError) Error() string {
	if e.Err != nil {
		return fmt.Sprintf("%s: %v", e.Message, e.Err)
	}
	return e.Message
}

func (e *UpstreamError) Unwrap() error {
	return e.Err
}

// AccountRepository is an implementation of IAccountRepository
type AccountRepository struct {
	logger logger.ILogger
	client client.IClient
}

// NewAccountRepository creates a new AccountRepository instance
func NewAccountRepository(logger logger.ILogger, client client.IClient) IAccountRepository {
	return &AccountRepository{
		logger: logger,
		client: client,
	}
}

// GetAccountById retrieves an account by its ID from the external API
func (r *AccountRepository) GetAccountById(ctx context.Context, accountId uint64) (*entities.Account, error) {
	queryParams := map[string]string{"accountId": fmt.Sprintf("%d", accountId)}
	const path = "Account/GetAccountById"
	responseBytes, err := r.client.Get(ctx, path, nil, queryParams, nil)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to get account from API: %v", err))

		// Detect upstream HTTP status from the error message produced by the HTTP client.
		upstreamStatus := 0
		if strings.Contains(err.Error(), "request failed with status") {
			fmt.Sscanf(err.Error(), "request failed with status %d", &upstreamStatus)
		}

		return nil, &UpstreamError{
			StatusCode: upstreamStatus,
			Message:    "failed to get account from upstream API",
			Err:        err,
		}
	}

	var response entities.BridgeResult[*entities.Account]
	if err := json.Unmarshal(responseBytes, &response); err != nil {
		r.logger.Error(fmt.Sprintf("failed to unmarshal account data: %v", err))
		return nil, &UpstreamError{
			StatusCode: 0,
			Message:    "failed to unmarshal upstream response",
			Err:        err,
		}
	}

	if response.Result == nil || response.Status < 200 || response.Status >= 300 {
		return nil, &UpstreamError{
			StatusCode: int(response.Status),
			Message:    fmt.Sprintf("upstream API returned an error: %s", response.Error),
			Err:        fmt.Errorf("upstream status %d: %s", response.Status, response.Error),
		}
	}

	return response.Result, nil
}

// GetAccount searches for accounts by criteria via BridgeApp/api/v2/Account/GetAccount.
func (r *AccountRepository) GetAccount(ctx context.Context, criteria *entities.AccountCriteria) ([]entities.Account, error) {
	const path = "Account/GetAccount"

	body, err := json.Marshal(criteria)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to marshal account criteria: %v", err))
		return nil, &UpstreamError{
			StatusCode: 0,
			Message:    "failed to marshal account criteria",
			Err:        err,
		}
	}

	responseBytes, err := r.client.Post(ctx, path, nil, nil, bytes.NewReader(body), map[string]string{"Content-Type": "application/json"})
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to get accounts from API: %v", err))

		upstreamStatus := 0
		if strings.Contains(err.Error(), "request failed with status") {
			fmt.Sscanf(err.Error(), "request failed with status %d", &upstreamStatus)
		}

		return nil, &UpstreamError{
			StatusCode: upstreamStatus,
			Message:    "failed to get accounts from upstream API",
			Err:        err,
		}
	}

	var response entities.BridgeResult[[]entities.Account]
	if err := json.Unmarshal(responseBytes, &response); err != nil {
		r.logger.Error(fmt.Sprintf("failed to unmarshal accounts data: %v", err))
		return nil, &UpstreamError{
			StatusCode: 0,
			Message:    "failed to unmarshal upstream response",
			Err:        err,
		}
	}

	if response.Status < 200 || response.Status >= 300 {
		return nil, &UpstreamError{
			StatusCode: int(response.Status),
			Message:    fmt.Sprintf("upstream API returned an error: %s", response.Error),
			Err:        fmt.Errorf("upstream status %d: %s", response.Status, response.Error),
		}
	}

	if response.Result != nil {
		return response.Result, nil
	}

	return []entities.Account{}, nil
}

// GetAccountBalance retrieves account balance details by account ID
func (r *AccountRepository) GetAccountBalance(ctx context.Context, accountId uint64) (*entities.AccountBalance, error) {
	queryParams := map[string]string{"accountId": fmt.Sprintf("%d", accountId)}
	const path = "Account/GetAccountBalance"
	responseBytes, err := r.client.Get(ctx, path, nil, queryParams, nil)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to get account balance from API: %v", err))

		upstreamStatus := 0
		if strings.Contains(err.Error(), "request failed with status") {
			fmt.Sscanf(err.Error(), "request failed with status %d", &upstreamStatus)
		}

		return nil, &UpstreamError{
			StatusCode: upstreamStatus,
			Message:    "failed to get account balance from upstream API",
			Err:        err,
		}
	}

	var response entities.BridgeResult[[]entities.AccountBalance]
	if err := json.Unmarshal(responseBytes, &response); err != nil {
		r.logger.Error(fmt.Sprintf("failed to unmarshal account balance data: %v", err))
		return nil, &UpstreamError{
			StatusCode: 0,
			Message:    "failed to unmarshal upstream response",
			Err:        err,
		}
	}

	if response.Status < 200 || response.Status >= 300 {
		return nil, &UpstreamError{
			StatusCode: int(response.Status),
			Message:    fmt.Sprintf("upstream API returned an error: %s", response.Error),
			Err:        fmt.Errorf("upstream status %d: %s", response.Status, response.Error),
		}
	}

	if len(response.Result) == 0 {
		return nil, nil
	}

	return &response.Result[0], nil
}

// GetPaymentArrangement retrieves payment arrangement list by account ID
func (r *AccountRepository) GetPaymentArrangement(ctx context.Context, accountId uint64) ([]entities.PaymentArrangement, error) {
	queryParams := map[string]string{"accountId": fmt.Sprintf("%d", accountId)}
	const path = "Account/GetPaymentArrangement"
	responseBytes, err := r.client.Get(ctx, path, nil, queryParams, nil)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to get payment arrangement from API: %v", err))

		upstreamStatus := 0
		if strings.Contains(err.Error(), "request failed with status") {
			fmt.Sscanf(err.Error(), "request failed with status %d", &upstreamStatus)
		}

		return nil, &UpstreamError{
			StatusCode: upstreamStatus,
			Message:    "failed to get payment arrangement from upstream API",
			Err:        err,
		}
	}

	var response entities.BridgeResult[[]entities.PaymentArrangement]
	if err := json.Unmarshal(responseBytes, &response); err != nil {
		r.logger.Error(fmt.Sprintf("failed to unmarshal payment arrangement data: %v", err))
		return nil, &UpstreamError{
			StatusCode: 0,
			Message:    "failed to unmarshal upstream response",
			Err:        err,
		}
	}

	if response.Status < 200 || response.Status >= 300 {
		return nil, &UpstreamError{
			StatusCode: int(response.Status),
			Message:    fmt.Sprintf("upstream API returned an error: %s", response.Error),
			Err:        fmt.Errorf("upstream status %d: %s", response.Status, response.Error),
		}
	}

	if response.Result != nil {
		return response.Result, nil
	}

	return []entities.PaymentArrangement{}, nil
}

// GetInvoiceDistribution retrieves invoice distribution info by account ID via BridgeApp/api/v2/Account/GetAccountById.
func (r *AccountRepository) GetInvoiceDistribution(ctx context.Context, accountId uint64) ([]entities.InvoiceDistributionInfo, error) {
	queryParams := map[string]string{"accountId": fmt.Sprintf("%d", accountId)}
	const path = "Account/GetAccountById"
	responseBytes, err := r.client.Get(ctx, path, nil, queryParams, nil)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to get account from API for invoice distribution: %v", err))

		upstreamStatus := 0
		if strings.Contains(err.Error(), "request failed with status") {
			fmt.Sscanf(err.Error(), "request failed with status %d", &upstreamStatus)
		}

		return nil, &UpstreamError{
			StatusCode: upstreamStatus,
			Message:    "failed to get invoice distribution from upstream API",
			Err:        err,
		}
	}

	var response entities.BridgeResult[*entities.Account]
	if err := json.Unmarshal(responseBytes, &response); err != nil {
		r.logger.Error(fmt.Sprintf("failed to unmarshal account data for invoice distribution: %v", err))
		return nil, &UpstreamError{
			StatusCode: 0,
			Message:    "failed to unmarshal upstream response",
			Err:        err,
		}
	}

	if response.Result == nil || response.Status < 200 || response.Status >= 300 {
		return nil, &UpstreamError{
			StatusCode: int(response.Status),
			Message:    fmt.Sprintf("upstream API returned an error: %s", response.Error),
			Err:        fmt.Errorf("upstream status %d: %s", response.Status, response.Error),
		}
	}

	if response.Result.InvDistInfos != nil {
		return response.Result.InvDistInfos, nil
	}

	return []entities.InvoiceDistributionInfo{}, nil
}
