package repository

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
)

// ReferenceRepository is an implementation of IReferenceRepository
type ReferenceRepository struct {
	logger logger.ILogger
	client client.IClient
}

// NewReferenceRepository creates a new ReferenceRepository instance
func NewReferenceRepository(logger logger.ILogger, client client.IClient) IReferenceRepository {
	return &ReferenceRepository{
		logger: logger,
		client: client,
	}
}

// GetReferenceCode retrieves reference codes by code and domain name from the external API
func (r *ReferenceRepository) GetReferenceCode(ctx context.Context, code string, domainName string) ([]entities.ReferenceCode, error) {
	queryParams := map[string]string{
		"refCode":    code,
		"domainName": domainName,
	}
	const path = "Reference/GetReferenceCode"
	responseBytes, err := r.client.Get(ctx, path, nil, queryParams, nil)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to get reference code from API: %v", err))

		// Detect upstream HTTP status from the error message produced by the HTTP client.
		upstreamStatus := 0
		if strings.Contains(err.Error(), "request failed with status") {
			fmt.Sscanf(err.Error(), "request failed with status %d", &upstreamStatus)
		}

		return nil, &UpstreamError{
			StatusCode: upstreamStatus,
			Message:    "failed to get reference code from upstream API",
			Err:        err,
		}
	}

	var response entities.BridgeResult[[]entities.ReferenceCode]
	if err := json.Unmarshal(responseBytes, &response); err != nil {
		r.logger.Error(fmt.Sprintf("failed to unmarshal reference code data: %v", err))
		return nil, &UpstreamError{
			StatusCode: 0,
			Message:    "failed to unmarshal upstream response",
			Err:        err,
		}
	}

	if response.Result == nil || response.Status < 200 || response.Status >= 300 {
		return nil, &UpstreamError{
			StatusCode: int(response.Status),
			Message:    fmt.Sprintf("upstream API returned non-success status: %d", response.Status),
		}
	}

	return response.Result, nil
}
