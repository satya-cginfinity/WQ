package repository

import (
	"context"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type IAccountRepository interface {
	GetAccountById(ctx context.Context, accountId uint64) (*entities.Account, error)

	// GetAccount searches for accounts using the supplied AccountCriteria request body
	GetAccount(ctx context.Context, criteria *entities.AccountCriteria) ([]entities.Account, error)

	// GetAccountBalance retrieves the account balance details by account ID
	GetAccountBalance(ctx context.Context, accountId uint64) (*entities.AccountBalance, error)

	// GetPaymentArrangement retrieves the payment arrangement list by account ID
	GetPaymentArrangement(ctx context.Context, accountId uint64) ([]entities.PaymentArrangement, error)

	// GetInvoiceDistribution retrieves the invoice distribution info list by account ID
	GetInvoiceDistribution(ctx context.Context, accountId uint64) ([]entities.InvoiceDistributionInfo, error)
}
