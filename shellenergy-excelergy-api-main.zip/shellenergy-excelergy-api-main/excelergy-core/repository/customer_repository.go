package repository

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
)

type customerAccountsResult struct {
	// Accounts is the list returned under result.accounts by Bridge GetCustomer.
	Accounts []entities.Account `json:"accounts"`
}

// CustomerRepository is an implementation of ICustomerRepository
type CustomerRepository struct {
	logger logger.ILogger
	client client.IClient
}

// NewCustomerRepository creates a new CustomerRepository instance
func NewCustomerRepository(logger logger.ILogger, client client.IClient) ICustomerRepository {
	return &CustomerRepository{
		logger: logger,
		client: client,
	}
}

// GetCustomer retrieves a customer by their ID and username
func (r *CustomerRepository) GetCustomer(ctx context.Context, customerId uint64, username string) (*entities.Customer, error) {
	queryParams := map[string]string{"customerId": fmt.Sprintf("%d", customerId), "username": username}
	bytes, err := r.client.Get(ctx, "Customer/GetCustomer", nil, queryParams, nil)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to get customer from API: %v", err))
		return nil, fmt.Errorf("failed to get customer from API: %w", err)
	}

	var response entities.BridgeResult[*entities.Customer]
	if err := json.Unmarshal(bytes, &response); err != nil {
		r.logger.Error(fmt.Sprintf("failed to unmarshal customer data: %v", err))
		return nil, fmt.Errorf("failed to unmarshal customer data: %w", err)
	}

	if response.Result == nil || response.Status < 200 || response.Status >= 300 {
		return nil, fmt.Errorf("API returned an error: %s", response.Error)
	}

	return response.Result, nil
}

// GetCustomerAccounts retrieves all accounts for a customer from the external API
func (r *CustomerRepository) GetCustomerAccounts(ctx context.Context, customerId uint64, username string) ([]entities.Account, error) {
	// Reuse the existing GetCustomer upstream endpoint and extract only accounts.
	queryParams := map[string]string{
		"customerId": fmt.Sprintf("%d", customerId),
		"username":   username,
	}

	bytes, err := r.client.Get(ctx, "Customer/GetCustomer", nil, queryParams, nil)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to get customer accounts from API: %v", err))
		return nil, fmt.Errorf("failed to get customer accounts from API: %w", err)
	}

	var response entities.BridgeResult[customerAccountsResult]
	if err := json.Unmarshal(bytes, &response); err != nil {
		r.logger.Error(fmt.Sprintf("failed to unmarshal customer accounts data: %v", err))
		return nil, fmt.Errorf("failed to unmarshal customer accounts data: %w", err)
	}

	if response.Status < 200 || response.Status >= 300 {
		return nil, fmt.Errorf("API returned an error: %s", response.Error)
	}

	if response.Result.Accounts != nil {
		return response.Result.Accounts, nil
	}

	// Normalize missing accounts to an empty list for controller serialization.
	return []entities.Account{}, nil
}
