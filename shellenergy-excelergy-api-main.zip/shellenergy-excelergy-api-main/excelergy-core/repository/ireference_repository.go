package repository

import (
	"context"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type IReferenceRepository interface {
	// GetReferenceCode retrieves reference codes by code and domain name
	GetReferenceCode(ctx context.Context, code string, domainName string) ([]entities.ReferenceCode, error)
}
