package repository

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
)

// LdcAccountRepository is an implementation of ILdcAccountRepository
type LdcAccountRepository struct {
	logger logger.ILogger
	client client.IClient
}

// NewLdcAccountRepository creates a new LdcAccountRepository instance
func NewLdcAccountRepository(logger logger.ILogger, client client.IClient) ILdcAccountRepository {
	return &LdcAccountRepository{
		logger: logger,
		client: client,
	}
}

// GetLdcAccount retrieves an LDC account from the external API
func (r *LdcAccountRepository) GetLdcAccount(ctx context.Context, customerId *uint64, ldcAccountId *uint64, accountId *uint64, userName string) (*entities.LdcAccount, error) {
	queryParams := map[string]string{}
	if customerId != nil {
		queryParams["customerId"] = fmt.Sprintf("%d", *customerId)
	}
	if ldcAccountId != nil {
		queryParams["ldcAccountId"] = fmt.Sprintf("%d", *ldcAccountId)
	}
	if accountId != nil {
		queryParams["accountId"] = fmt.Sprintf("%d", *accountId)
	}
	if userName != "" {
		queryParams["userName"] = userName
	}
	const path = "Reference/GetLdcAccount"
	responseBytes, err := r.client.Get(ctx, path, nil, queryParams, nil)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to get LDC account from API: %v", err))

		// Detect upstream HTTP status from the error message produced by the HTTP client.
		upstreamStatus := 0
		if strings.Contains(err.Error(), "request failed with status") {
			fmt.Sscanf(err.Error(), "request failed with status %d", &upstreamStatus)
		}

		return nil, &UpstreamError{
			StatusCode: upstreamStatus,
			Message:    "failed to get LDC account from upstream API",
			Err:        err,
		}
	}

	var response entities.BridgeResult[[]entities.LdcAccount]
	if err := json.Unmarshal(responseBytes, &response); err != nil {
		r.logger.Error(fmt.Sprintf("failed to unmarshal LDC account data: %v", err))
		return nil, &UpstreamError{
			StatusCode: 0,
			Message:    "failed to unmarshal upstream response",
			Err:        err,
		}
	}

	// Non-2xx upstream status → real error
	if response.Status < 200 || response.Status >= 300 {
		return nil, &UpstreamError{
			StatusCode: int(response.Status),
			Message:    fmt.Sprintf("upstream API returned an error: %s", response.Error),
			Err:        fmt.Errorf("upstream status %d: %s", response.Status, response.Error),
		}
	}

	// 2xx with nil/empty result → treat as not-found so the controller can return 404
	if response.Result == nil || len(response.Result) == 0 {
		return nil, nil
	}

	return &response.Result[0], nil
}
