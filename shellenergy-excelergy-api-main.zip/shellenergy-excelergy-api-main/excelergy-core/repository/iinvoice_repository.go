package repository

import (
	"context"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

// IInvoiceRepository defines the contract for invoice data access
type IInvoiceRepository interface {
	// DownloadInvoicePdf downloads the PDF for a given billing account and billing month
	DownloadInvoicePdf(ctx context.Context, billingAccountNo string, billingMonth string) ([]byte, error)

	// GetInvoices retrieves invoices for a given account number and optional invoice number
	GetInvoices(ctx context.Context, accountNo string, invoiceNo string) ([]entities.Invoice, error)

	// GetPaymentHistory retrieves payment history for a given account number and filters
	GetPaymentHistory(ctx context.Context, accountNo string, transactionType string, fromDate string, toDate string, returnLimit int) (*entities.PaymentHistory, error)
}
