package repository

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/client"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/logger"
)

// InvoiceRepository is an implementation of IInvoiceRepository
type InvoiceRepository struct {
	logger logger.ILogger
	client client.IClient
}

// NewInvoiceRepository creates a new InvoiceRepository instance
func NewInvoiceRepository(logger logger.ILogger, client client.IClient) IInvoiceRepository {
	return &InvoiceRepository{
		logger: logger,
		client: client,
	}
}

// DownloadInvoicePdf retrieves the PDF for a given billing account and billing month from the bridge
func (r *InvoiceRepository) DownloadInvoicePdf(ctx context.Context, billingAccountNo string, billingMonth string) ([]byte, error) {
	queryParams := map[string]string{
		"billingAccountNo": billingAccountNo,
		"billingMonth":     billingMonth,
	}
	const path = "Invoice/DownloadInvoicePdf"
	responseBytes, err := r.client.Get(ctx, path, nil, queryParams, nil)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to download invoice PDF from API: %v", err))

		upstreamStatus := 0
		if strings.Contains(err.Error(), "request failed with status") {
			fmt.Sscanf(err.Error(), "request failed with status %d", &upstreamStatus)
		}

		return nil, &UpstreamError{
			StatusCode: upstreamStatus,
			Message:    "failed to download invoice PDF from upstream API",
			Err:        err,
		}
	}

	// The bridge returns raw PDF bytes directly, so no JSON unmarshalling is needed.
	return responseBytes, nil
}

// GetInvoices retrieves invoices for a given account number and optional invoice number from the bridge
func (r *InvoiceRepository) GetInvoices(ctx context.Context, accountNo string, invoiceNo string) ([]entities.Invoice, error) {
	queryParams := map[string]string{
		"accountNo": accountNo,
	}
	if invoiceNo != "" {
		queryParams["invoiceNo"] = invoiceNo
	}

	const path = "Invoice/GetInvoices"
	responseBytes, err := r.client.Get(ctx, path, nil, queryParams, nil)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to get invoices from API: %v", err))

		upstreamStatus := 0
		if strings.Contains(err.Error(), "request failed with status") {
			fmt.Sscanf(err.Error(), "request failed with status %d", &upstreamStatus)
		}

		return nil, &UpstreamError{
			StatusCode: upstreamStatus,
			Message:    "failed to get invoices from upstream API",
			Err:        err,
		}
	}

	var bridgeResult entities.BridgeResult[[]entities.Invoice]
	if err := json.Unmarshal(responseBytes, &bridgeResult); err != nil {
		r.logger.Error(fmt.Sprintf("failed to unmarshal invoices response: %v", err))
		return nil, &UpstreamError{
			StatusCode: 0,
			Message:    "failed to parse invoices response from upstream API",
			Err:        err,
		}
	}

	if bridgeResult.Status < 200 || bridgeResult.Status >= 300 {
		return nil, &UpstreamError{
			StatusCode: int(bridgeResult.Status),
			Message:    fmt.Sprintf("upstream API returned an error: %s", bridgeResult.Error),
			Err:        fmt.Errorf("upstream status %d: %s", bridgeResult.Status, bridgeResult.Error),
		}
	}

	if bridgeResult.Result != nil {
		return bridgeResult.Result, nil
	}

	return []entities.Invoice{}, nil
}

// GetPaymentHistory retrieves payment history for a given account number and filters from the bridge
func (r *InvoiceRepository) GetPaymentHistory(ctx context.Context, accountNo string, transactionType string, fromDate string, toDate string, returnLimit int) (*entities.PaymentHistory, error) {
	queryParams := map[string]string{
		"accountNo":   accountNo,
		"returnLimit": fmt.Sprintf("%d", returnLimit),
	}
	if transactionType != "" {
		queryParams["transactionType"] = transactionType
	}
	if fromDate != "" {
		queryParams["fromDate"] = fromDate
	}
	if toDate != "" {
		queryParams["toDate"] = toDate
	}

	const path = "Invoice/GetPaymentHistory"
	responseBytes, err := r.client.Get(ctx, path, nil, queryParams, nil)
	if err != nil {
		r.logger.Error(fmt.Sprintf("failed to get payment history from API: %v", err))

		upstreamStatus := 0
		if strings.Contains(err.Error(), "request failed with status") {
			fmt.Sscanf(err.Error(), "request failed with status %d", &upstreamStatus)
		}

		return nil, &UpstreamError{
			StatusCode: upstreamStatus,
			Message:    "failed to get payment history from upstream API",
			Err:        err,
		}
	}

	var bridgeResult entities.BridgeResult[*entities.PaymentHistory]
	if err := json.Unmarshal(responseBytes, &bridgeResult); err != nil {
		r.logger.Error(fmt.Sprintf("failed to unmarshal payment history response: %v", err))
		return nil, &UpstreamError{
			StatusCode: 0,
			Message:    "failed to parse payment history response from upstream API",
			Err:        err,
		}
	}

	if bridgeResult.Status < 200 || bridgeResult.Status >= 300 {
		return nil, &UpstreamError{
			StatusCode: int(bridgeResult.Status),
			Message:    fmt.Sprintf("upstream API returned an error: %s", bridgeResult.Error),
			Err:        fmt.Errorf("upstream status %d: %s", bridgeResult.Status, bridgeResult.Error),
		}
	}

	return bridgeResult.Result, nil
}
