package repository

import (
	"context"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type ILdcAccountRepository interface {
	// GetLdcAccount retrieves an LDC account by its parameters.
	// At least one of customerId, ldcAccountId, or accountId must be non-nil.
	GetLdcAccount(ctx context.Context, customerId *uint64, ldcAccountId *uint64, accountId *uint64, userName string) (*entities.LdcAccount, error)
}
