package repository

import (
	"context"

	"github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core/entities"
)

type ICustomerRepository interface {
	GetCustomer(ctx context.Context, customerId uint64, username string) (*entities.Customer, error)
	GetCustomerAccounts(ctx context.Context, customerId uint64, username string) ([]entities.Account, error)
}
