package entities

type CollectionEvent struct {
	CollectionScheduleId uint64                 `json:"collectionScheduleId"`
	DueAmount            float64                `json:"dueAmount"`
	DueDays              float64                `json:"dueDays"`
	EventAmount          float64                `json:"eventAmount"`
	ExtractIn            bool                   `json:"extractIn"`
	FeeAmount            float64                `json:"feeAmount"`
	FeeMaxAmount         float64                `json:"feeMaxAmount"`
	FeeMinAmount         float64                `json:"feeMinAmount"`
	FeePercent           float64                `json:"feePercent"`
	FeePercentUI         float64                `json:"feePercentUI"`
	FeeType              string                 `json:"feeType"`
	LateAmount           float64                `json:"lateAmount"`
	Message              string                 `json:"message"`
	MessageOnInvoiceIn   bool                   `json:"messageOnInvoiceIn"`
	MinWaitDays          float64                `json:"minWaitDays"`
	OrderNo              uint32                 `json:"orderNo"`
	ProtectionList       []CollectionProtection `json:"protectionList"`
	ProtectionString     string                 `json:"protectionString"`
	RepeatEveryDaysNo    uint32                 `json:"repeatEveryDaysNo"`
	SubType              string                 `json:"subType"`
	Type                 string                 `json:"type"`
}
