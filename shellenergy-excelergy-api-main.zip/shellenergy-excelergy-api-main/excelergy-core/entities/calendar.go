package entities

type Calendar struct {
	CalendarId   uint64 `json:"calendarId"`
	TypeCode     string `json:"typeCode"`
	Default      bool   `json:"default"`
	Description  string `json:"description"`
	CalendarCode string `json:"calendarCode"`
}
