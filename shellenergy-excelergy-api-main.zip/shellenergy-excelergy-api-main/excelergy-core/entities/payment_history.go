package entities

type PaymentHistory struct {
	TotalFound    int        `json:"totalFound"`
	TotalReturned int        `json:"totalReturned"`
	AccountNumber string     `json:"accountNumber"`
	Payments      []*Payment `json:"payments"`
}
