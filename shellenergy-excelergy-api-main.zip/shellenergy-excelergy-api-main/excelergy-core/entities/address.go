package entities

type Address struct {
	AddressID  uint64       `json:"addressID"`
	City       string       `json:"city"`
	Country    string       `json:"country"`
	County     string       `json:"county"`
	Line1      string       `json:"line1"`
	Line2      string       `json:"line2"`
	PostalCode string       `json:"postalCode"`
	State      string       `json:"state"`
	SysTmStamp FlexibleTime `json:"sysTmStamp"`
}
