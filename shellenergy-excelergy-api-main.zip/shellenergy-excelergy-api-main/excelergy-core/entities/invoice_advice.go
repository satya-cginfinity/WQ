package entities

type InvoiceAdvice struct {
	ActualBudgetChargesAmount  float64      `json:"actualBudgetChargesAmount"`
	BillMethod                 string       `json:"billMethod"`
	BillMethodDesc             string       `json:"billMethodDesc"`
	BudgetBillVarianceAmount   float64      `json:"budgetBillVarianceAmount"`
	BudgetChargesAmount        float64      `json:"budgetChargesAmount"`
	CancelIndicator            bool         `json:"cancelIndicator"`
	ClassName                  string       `json:"className"`
	DisplayCode                string       `json:"displayCode"`
	DisplayName                string       `json:"displayName"`
	DueDate                    FlexibleTime `json:"dueDate"`
	EDIReferenceNumber         string       `json:"ediReferenceNumber"`
	EndDate                    FlexibleTime `json:"endDate"`
	EspVendorID                uint64       `json:"espVendorID"`
	InvoicedIndicator          bool         `json:"invoicedIndicator"`
	InvoiceId                  uint64       `json:"invoiceId"`
	LateChargeAm               float64      `json:"lateChargeAm"`
	LdcAccountId               uint64       `json:"ldcAccountId"`
	NewFee                     float64      `json:"newFee"`
	NewRatedChargesAm          float64      `json:"newRatedChargesAm"`
	NewServiceChargesAm        float64      `json:"newServiceChargesAm"`
	NewTaxesAm                 float64      `json:"newTaxesAm"`
	OriginalEDIReferenceNumber string       `json:"originalEDIReferenceNumber"`
	PaymentsReceivedAmount     float64      `json:"paymentsReceivedAmount"`
	PrevBalAfterAdjAmount      float64      `json:"prevBalAfterAdjAmount"`
	PrevBalDueAmount           float64      `json:"prevBalDueAmount"`
	PreviousAmount             float64      `json:"previousAmount"`
	Skip810867MatchIn          bool         `json:"skip810867MatchIn"`
	StartDate                  FlexibleTime `json:"startDate"`
	TotalAdjAmount             float64      `json:"totalAdjAmount"`
	TotalChargeCreditAmount    float64      `json:"totalChargeCreditAmount"`
	TotalDueAmount             float64      `json:"totalDueAmount"`
	TotalNewChargesAm          float64      `json:"totalNewChargesAm"`
	XBRExcludeTaxesCode        string       `json:"xbrExcludeTaxesCode"`
}
