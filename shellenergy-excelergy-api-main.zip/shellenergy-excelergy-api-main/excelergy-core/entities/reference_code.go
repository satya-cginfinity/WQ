package entities

type ReferenceCode struct {
	Code                string               `json:"code"`
	Default             bool                 `json:"default"`
	DisplayCode         string               `json:"displayCode"`
	DisplayName         string               `json:"displayName"`
	DomainName          string               `json:"domainName"`
	EDICode             string               `json:"ediCode"`
	IsActive            bool                 `json:"isActive"`
	IsChecked           bool                 `json:"isChecked"`
	LongDescription     string               `json:"longDescription"`
	MixedCase           bool                 `json:"mixedCase"`
	ReferenceAttributes []ReferenceAttribute `json:"referenceAttributes"`
	ShortDescription    string               `json:"shortDescription"`
	XMLCode             string               `json:"xmlCode"`
}
