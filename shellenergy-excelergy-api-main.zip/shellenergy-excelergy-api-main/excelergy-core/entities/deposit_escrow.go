package entities

// DepositEscrowModel is a Go representation of the provided C# DepositEscrowModel.
//
// Notes:
// - C# decimal -> Go float64 (consider shopspring/decimal for exact precision)
// - C# uint -> Go uint32
// - C# ulong -> Go uint64
type DepositEscrow struct {
	Amount                          float64 `json:"amount"`
	Balance                         float64 `json:"balance"`
	ClosedDate                      string  `json:"closedDate"`
	CreationDate                    string  `json:"creationDate"`
	DepositAmountMaxFormattedLength uint32  `json:"depositAmountMaxFormattedLength"`
	DepositEscrowRuleName           string  `json:"depositEscrowRuleName"`
	DepositId                       uint64  `json:"depositId"`
	DisplayCode                     string  `json:"displayCode"`
	DisplayName                     string  `json:"displayName"`
	LastCalcdate                    string  `json:"lastCalcdate"`
	RelateClassName                 string  `json:"relateClassName"`
	RelateId                        uint64  `json:"relateId"`
	ReviewDate                      string  `json:"reviewDate"`
	RuleId                          uint64  `json:"ruleId"`
	ServiceTypeCode                 string  `json:"serviceTypeCode"`
	ServiceTypeCodeShortDesc        string  `json:"serviceTypeCodeShortDesc"`
	StartDate                       string  `json:"startDate"`
	TotalInterest                   float64 `json:"totalInterest"`
}
