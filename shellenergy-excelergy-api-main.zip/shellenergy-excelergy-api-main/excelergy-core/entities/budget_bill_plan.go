package entities

type BudgetBillPlan struct {
	BudgetBillAmount             float64      `json:"budgetBillAmount"`
	CurrentPriceUsedInCalc       bool         `json:"currentPriceUsedInCalc"`
	EndDate                      FlexibleTime `json:"endDate"`
	ExtBudgetBillAmount          float64      `json:"extBudgetBillAmount"`
	ExtRolloverAmt               float64      `json:"extRolloverAmt"`
	ExtSuggestedBudgetBillAmount float64      `json:"extSuggestedBudgetBillAmount"`
	HasBeenCalculated            bool         `json:"hasBeenCalculated"`
	IntBudgetBillAmount          float64      `json:"intBudgetBillAmount"`
	IntRolloverAmt               float64      `json:"intRolloverAmt"`
	IntSuggestedBudgetBillAmount float64      `json:"intSuggestedBudgetBillAmount"`
	IsBudgetAmountAboveMin       bool         `json:"isBudgetAmountAboveMin"`
	IsSuggestedValid             bool         `json:"isSuggestedValid"`
	LastBudgetSetDate            FlexibleTime `json:"lastBudgetSetDate"`
	LastReconcileDate            FlexibleTime `json:"lastReconcileDate"`
	LastReviewDate               FlexibleTime `json:"lastReviewDate"`
	LDCAccountId                 uint64       `json:"ldcAccountId"`
	MinimumAmount                float64      `json:"minimumAmount"`
	MinimumQuantity              float64      `json:"minimumQuantity"`
	NumUsageMonths               uint32       `json:"numUsageMonths"`
	OriginalFlatAmount           float64      `json:"originalFlatAmount"`
	OverrideCalculation          bool         `json:"overrideCalculation"`
	Quantity                     float64      `json:"quantity"`
	Renew                        string       `json:"renew"`
	RenewBool                    bool         `json:"renewBool"`
	RoundedAmountDifference      float64      `json:"roundedAmountDifference"`
	SetReasonCode                string       `json:"setReasonCode"`
	StartDate                    FlexibleTime `json:"startDate"`
	SuggestedBudgetBillAmount    float64      `json:"suggestedBudgetBillAmount"`
	SuggestedQuantity            float64      `json:"suggestedQuantity"`
	SuggestedUOM                 string       `json:"suggestedUOM"`
	Total                        float64      `json:"total"`
	TransitionAmount             float64      `json:"transitionAmount"`
	TransitionDate               FlexibleTime `json:"transitionDate"`
	Type                         string       `json:"type"`
	TypeDesc                     string       `json:"typeDesc"`
	UOM                          string       `json:"uom"`
	UserAmount                   float64      `json:"userAmount"`
	VendorDBNo                   string       `json:"vendorDBNo"`
	VendorId                     uint64       `json:"vendorId"`
}
