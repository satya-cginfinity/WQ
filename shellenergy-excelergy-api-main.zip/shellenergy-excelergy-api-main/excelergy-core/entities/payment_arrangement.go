package entities

// PaymentArrangement is a Go representation of the provided C# PaymentArrangementModel.
//
// Notes:
// - C# decimal -> Go float64 (consider shopspring/decimal for exact precision)
// - C# uint -> Go uint32
// - C# ulong -> Go uint64
type PaymentArrangement struct {
	AccountBalance    bool    `json:"accountBalance"`
	AcctId            uint64  `json:"acctId"`
	Amount            float64 `json:"amount"`
	ClosedDate        string  `json:"closedDate"`
	CreationDate      string  `json:"creationDate"`
	Duration          uint32  `json:"duration"`
	FirstPaymentDate  string  `json:"firstPaymentDate"`
	GoodwillApplies   bool    `json:"goodwillApplies"`
	Invoiced          bool    `json:"invoiced"`
	InvoiceLookupDate string  `json:"invoiceLookupDate"`
	IsGoodwillEnabled bool    `json:"isGoodwillEnabled"`
	LastPaymentDate   string  `json:"lastPaymentDate"`
	PaidAmount        float64 `json:"paidAmount"`
	PurposeCode       string  `json:"purposeCode"`
	ScheduleAmount    float64 `json:"scheduleAmount"`
	Status            string  `json:"status"`
	TypeCode          string  `json:"typeCode"`
}
