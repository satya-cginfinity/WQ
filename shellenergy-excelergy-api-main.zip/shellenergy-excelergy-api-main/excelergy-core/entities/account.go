package entities

// Notes:
// - C# string -> Go string
// - C# bool -> Go bool
// - C# decimal/decimal? -> Go float64 / *float64 (nullable). Consider shopspring/decimal for exact precision.
// - C# uint -> Go uint32
// - C# ulong -> Go uint64
// - C# List<T> -> Go []T
// - Reference types -> pointers (*Type) where it matches typical "nullable" semantics in C#.
type Account struct {
	ActiveIn                      bool                      `json:"activeIn"`
	AccountBalance                *float64                  `json:"accountBalance"`
	AccountId                     uint64                    `json:"accountId"`
	AccountNo                     string                    `json:"accountNo"`
	AccountNoSeq                  string                    `json:"accountNoSeq"`
	ACHDebitDayofMonth            uint32                    `json:"achDebitDayofMonth"`
	ACHDirectDebitStatus          string                    `json:"achDirectDebitStatus"`
	ACHRequestDateCalcCode        string                    `json:"achRequestDateCalcCode"`
	ACHStatusDate                 string                    `json:"achStatusDate"`
	AlertNote                     string                    `json:"alertNote"`
	BankABA                       string                    `json:"bankABA"`
	BankAcctId                    string                    `json:"bankAcctId"`
	BankAcctType                  string                    `json:"bankAcctType"`
	BankAuthCode                  string                    `json:"bankAuthCode"`
	BankAuthDate                  string                    `json:"bankAuthDate"`
	BankCustomerName              string                    `json:"bankCustomerName"`
	BankName                      string                    `json:"bankName"`
	BankTransitId                 string                    `json:"bankTransitId"`
	BudgetBillStatus              string                    `json:"budgetBillStatus"`
	CalculatedBalance             float64                   `json:"calculatedBalance"`
	CCExpireDate                  string                    `json:"ccExpireDate"`
	CCName                        string                    `json:"ccName"`
	CCNo                          string                    `json:"ccNo"`
	CCSuspendDate                 string                    `json:"ccSuspendDate"`
	CCTypeCode                    string                    `json:"ccTypeCode"`
	CCTypeCodeDesc                string                    `json:"ccTypeCodeDesc"`
	ClassName                     string                    `json:"className"`
	ContainsBudgetBillLdcAccounts bool                      `json:"containsBudgetBillLdcAccounts"`
	CurrentUsage                  bool                      `json:"currentUsage"`
	Creation                      string                    `json:"creation"`
	CreationDate                  string                    `json:"creationDate"`
	CreditBalance                 float64                   `json:"creditBalance"`
	CreditandCollectionRuleName   string                    `json:"creditandCollectionRuleName"`
	CreditCollectionRuleId        uint64                    `json:"creditCollectionRuleId"`
	CreditCollectRule             *CreditCollectionRule     `json:"creditCollectRule"`
	CustomerClassType             string                    `json:"customerClassType"`
	CustomerId                    uint64                    `json:"customerId"`
	DepositEscrows                []DepositEscrow           `json:"depositEscrows"`
	DisplayCode                   string                    `json:"displayCode"`
	DisplayName                   string                    `json:"displayName"`
	Do810867MatchIn               bool                      `json:"do810867MatchIn"`
	EstimationWaitPer             float64                   `json:"estimationWaitPer"`
	EventLDCAcctId                uint64                    `json:"eventLdcAcctId"`
	FirstName                     string                    `json:"firstName"`
	Interactions                  []Interaction             `json:"interactions"`
	InvDistInfos                  []InvoiceDistributionInfo `json:"invDistInfos"`
	InvoiceAdviceRequirement      string                    `json:"invoiceAdviceRequirement"`
	InvoiceHold                   bool                      `json:"invoiceHold"`
	InvoiceCreationEventRule      string                    `json:"invoiceCreationEventRule"`
	InvoiceMessage                string                    `json:"invoiceMessage"`
	InvoiceQueueStatusDescription string                    `json:"invoiceQueueStatusDescription"`
	InvoiceCycle                  uint32                    `json:"invoiceCycle"`
	Invoices                      []Invoice                 `json:"invoices"`
	IsACHDirectDebit              bool                      `json:"isAchDirectDebit"`
	IsDirectCreditStatusActive    bool                      `json:"isDirectCreditStatusActive"`
	IsOnPaymentArrangement        bool                      `json:"isOnPaymentArrangement"`
	IsSEPADirectDebit             bool                      `json:"isSepaDirectDebit"`
	LdcAccounts                   []LdcAccount              `json:"ldcAccounts"`
	LastName                      string                    `json:"lastName"`
	LPCSuspendDate                string                    `json:"lpcSuspendDate"`
	MiddleName                    string                    `json:"middleName"`
	Name                          string                    `json:"name"`
	NewCharge                     *Transaction              `json:"newCharge"`
	NewCredit                     *Transaction              `json:"newCredit"`
	NextInvoiceDate               string                    `json:"nextInvoiceDate"`
	NumberOfLDCAccounts           uint32                    `json:"numberOfLdcAccounts"`
	PhoneNo                       string                    `json:"phoneNo"`
	PreviousInvoiceDate           string                    `json:"previousInvoiceDate"`
	PreviousInvoiceDueDate        string                    `json:"previousInvoiceDueDate"`
	PrevInvoiceBalAm              float64                   `json:"prevInvoiceBalAm"`
	PricePlans                    []PricePlan               `json:"pricePlans"`
	SEPADirectDebitStatus         string                    `json:"sepaDirectDebitStatus"`
	SEPADaysOverride              bool                      `json:"sepaDaysOverride"`
	SEPAFirstDays                 uint32                    `json:"sepaFirstDays"`
	SEPAMandateExpiration         string                    `json:"sepaMandateExpiration"`
	SEPAMandateReference          string                    `json:"sepaMandateReference"`
	SEPAMandateSignature          string                    `json:"sepaMandateSignature"`
	SEPARecurrentDays             uint32                    `json:"sepaRecurrentDays"`
	SpecialHandling               string                    `json:"specialHandling"`
	SuspendCC                     bool                      `json:"suspendCC"`
	SuspendLPC                    bool                      `json:"suspendLPC"`
	TaxID                         string                    `json:"taxID"`
	TaxIDState                    string                    `json:"taxIDState"`
	Transactions                  []Transaction             `json:"transactions"`
	VendorAliasDbNumber           string                    `json:"vendorAliasDbNumber"`
	VendorAliasName               string                    `json:"vendorAliasName"`
	VendorBank                    string                    `json:"vendorBank"`
	VendorDBNo                    string                    `json:"vendorDBNo"`
	VendorDisplayDBNumber         string                    `json:"vendorDisplayDBNumber"`
	VendorDisplayName             string                    `json:"vendorDisplayName"`
	VendorId                      uint64                    `json:"vendorId"`
}
