package entities

type CollectionSchedule struct {
	BillingType           string            `json:"billingType"`
	BuisnessDayIn         bool              `json:"buisnessDayIn"`
	CancelPaymentEventId  uint64            `json:"cancelPaymentEventId"`
	CollectionEvents      []CollectionEvent `json:"collectionEvents"`
	Country               string            `json:"country"`
	CustomerClassType     string            `json:"customerClassType"`
	Name                  string            `json:"name"`
	PADroppedResetEventId uint64            `json:"paDroppedResetEventId"`
	ReducedBalanceEventId uint64            `json:"reducedBalanceEventId"`
	ServiceType           string            `json:"serviceType"`
	State                 string            `json:"state"`
	TransTypes            []string          `json:"transTypes"`
	Type                  string            `json:"type"`
	VendorId              uint64            `json:"vendorId"`
	VendorName            string            `json:"vendorName"`
}
