package entities

type BridgeResult[T any] struct {
	Result T      `json:"result"`
	Error  string `json:"error"`
	Status int32  `json:"status"`
}
