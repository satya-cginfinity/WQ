package entities

type ReferenceAttribute struct {
	Attribute string `json:"attribute"`
	Code      string `json:"code"`
	Domain    string `json:"domain"`
	IsDirty   bool   `json:"isDirty"`
	Value     string `json:"value"`
}
