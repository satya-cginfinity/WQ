package entities

// Notes:
// - C# ulong -> Go uint64
// - C# DateTime -> Go FlexibleTime
type InvoiceDistributionInfo struct {
	AddressID       uint64       `json:"addressID"`
	Attn            string       `json:"attn"`
	City            string       `json:"city"`
	Country         string       `json:"country"`
	County          string       `json:"county"`
	DistType        string       `json:"distType"`
	EmailAddr       string       `json:"emailAddr"`
	FormatType      string       `json:"formatType"`
	InvDistType     string       `json:"invDistType"`
	Line1           string       `json:"line1"`
	Line2           string       `json:"line2"`
	Name            string       `json:"name"`
	PostalCode      string       `json:"postalCode"`
	RelateClassName string       `json:"relateClassName"`
	RelateId        uint64       `json:"relateId"`
	State           string       `json:"state"`
	SysTmStamp      FlexibleTime `json:"sysTmStamp"`
}
