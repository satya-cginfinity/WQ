package entities

type CollectionProtection struct {
	Active             bool   `json:"active"`
	ActiveIn           bool   `json:"activeIn"`
	Country            string `json:"country"`
	County             string `json:"county"`
	CustomerClassType  string `json:"customerClassType"`
	Duration           uint32 `json:"duration"`
	EBTInclude         bool   `json:"ebtInclude"`
	EndDate            string `json:"endDate"`
	Implied            bool   `json:"implied"`
	Name               string `json:"name"`
	ProtectionTypeCode string `json:"protectionTypeCode"`
	ServiceTypeCode    string `json:"serviceTypeCode"`
	StartDate          string `json:"startDate"`
	State              string `json:"state"`
	VendorDBNo         string `json:"vendorDBNo"`
	VendorId           uint64 `json:"vendorId"`
	VendorName         string `json:"vendorName"`
}
