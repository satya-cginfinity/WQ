package entities

type Payment struct {
	TransactionId      uint64         `json:"transactionId"`
	Date               string         `json:"date"`
	Amount             float64        `json:"amount"`
	TransactionSubType string         `json:"transactionSubType"`
	Cancelled          *CancelledInfo `json:"cancelled"`
}
