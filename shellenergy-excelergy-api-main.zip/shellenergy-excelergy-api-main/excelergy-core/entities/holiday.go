package entities

type Holiday struct {
	HolidayId   uint64 `json:"holidayId"`
	CalendarId  uint64 `json:"calendarId"`
	HolidayDate string `json:"holidayDate"`
	HolidayType string `json:"holidayType"`
	Description string `json:"description"`
}
