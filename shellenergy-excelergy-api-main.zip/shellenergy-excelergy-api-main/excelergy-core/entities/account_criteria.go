package entities

type AccountCriteria struct {
	SEPADirectDebitStatuses      []string `json:"sepaDirectDebitStatuses"`
	SEPAMaxMandateExpiration     *string  `json:"sepaMaxMandateExpiration"`
	SEPAMandateReference         *string  `json:"sepaMandateReference"`
	SearchOrderByIDInclusive     *bool    `json:"searchOrderByIdInclusive"`
	SearchOrderByID              *bool    `json:"searchOrderById"`
	SearchLimit                  *int     `json:"searchLimit"`
	SearchAccountsPreviousOrNext *bool    `json:"searchAccountsPreviousOrNext"`
	AccountWithActiveLDCs        *bool    `json:"accountWithActiveLDCs"`
	AccountNumber                *string  `json:"accountNumber"`
	AccountID                    *uint64  `json:"accountId"`
	AcctCreditBalance            *float64 `json:"acctCreditBalance"`
	AccountActiveIndicator       *bool    `json:"accountActiveIndicator"`
	DirectDebitEnabled           *bool    `json:"directDebitEnabled"`
	AccountACHEnabled            *bool    `json:"accountACHEnabled"`
}
