package entities

type Customer struct {
	Accounts              []Account     `json:"accounts"`
	ClassName             string        `json:"className"`
	CoOrLastName          string        `json:"coOrLastName"`
	CreditLimit           float64       `json:"creditLimit"`
	CreditRisk            string        `json:"creditRisk"`
	CreditScore           string        `json:"creditScore"`
	CreditScoreDate       FlexibleTime  `json:"creditScoreDate"`
	CreditScoreSource     string        `json:"creditScoreSource"`
	CustomerClassType     string        `json:"customerClassType"`
	CustomerId            uint64        `json:"customerId"`
	DisplayCode           string        `json:"displayCode"`
	DisplayName           string        `json:"displayName"`
	DisplayNameByLastName string        `json:"displayNameByLastName"`
	DunBradNum            string        `json:"dunBradNum"`
	FirstName             string        `json:"firstName"`
	Interactions          []Interaction `json:"interactions"`
	InternalCreditScore   string        `json:"internalCreditScore"`
	IsResidential         bool          `json:"isResidential"`
	MiddleName            string        `json:"middleName"`
	Phone                 string        `json:"phone"`
	PhoneNumberRaw        string        `json:"phoneNumberRaw"`
	Prefix                string        `json:"prefix"`
	Suffix                string        `json:"suffix"`
	UnlistedPhoneNum      bool          `json:"unlistedPhoneNum"`
	UpperCoOrLastName     string        `json:"upperCoOrLastName"`
}
