package entities

type ProtectionRelate struct {
	DisplayCode               string       `json:"displayCode"`
	DisplayName               string       `json:"displayName"`
	EndDate                   FlexibleTime `json:"endDate"`
	LdcAcctId                 uint64       `json:"ldcAcctId"`
	ProtectionId              uint64       `json:"protectionId"`
	ProtectionIdSetDatesIfNew uint64       `json:"protectionIdSetDatesIfNew"`
	ProtectionName            string       `json:"protectionName"`
	StartDate                 FlexibleTime `json:"startDate"`
}
