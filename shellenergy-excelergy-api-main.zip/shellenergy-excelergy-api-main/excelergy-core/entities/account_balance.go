package entities

type AccountBalance struct {
	BudgetBillVariance      float64 `json:"budgetBillVariance"`
	Current                 float64 `json:"current"`
	Over0                   float64 `json:"over0"`
	Over30                  float64 `json:"over30"`
	Over60                  float64 `json:"over60"`
	Over90                  float64 `json:"over90"`
	Total                   float64 `json:"total"`
	TransactionGroupingType string  `json:"transactionGroupingType"`
	UnappliedCredits        float64 `json:"unappliedCredits"`
	Unbilled                float64 `json:"unbilled"`
	VendorName              string  `json:"vendorName"`
}
