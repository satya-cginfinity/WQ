package entities

type CancelledInfo struct {
	Value           string `json:"value"`
	InCancel        string `json:"inCancel"`
	InOffset        string `json:"inOffset"`
	InOffsetAdj     string `json:"inOffsetAdj"`
	InBeenOffset    string `json:"inBeenOffset"`
	InBeenOffsetAdj string `json:"inBeenOffsetAdj"`
}
