package entities

import (
	"strings"
	"time"
)

type FlexibleTime struct {
	time.Time
}

func (ft *FlexibleTime) UnmarshalJSON(b []byte) error {
	s := strings.Trim(string(b), `"`)
	if s == "null" || s == "" {
		ft.Time = time.Time{}
		return nil
	}

	// Try parsing with multiple formats
	formats := []string{
		time.RFC3339Nano,
		time.RFC3339,
		"2006-01-02T15:04:05.999999999",
		"2006-01-02T15:04:05",
		"2006-01-02 15:04:05",
		"2006-01-02",
	}

	for _, format := range formats {
		if t, err := time.Parse(format, s); err == nil {
			ft.Time = t
			return nil
		}
	}

	// If all formats fail, try default time.Time parsing
	return ft.Time.UnmarshalJSON(b)
}

func (ft FlexibleTime) MarshalJSON() ([]byte, error) {
	return ft.Time.MarshalJSON()
}
