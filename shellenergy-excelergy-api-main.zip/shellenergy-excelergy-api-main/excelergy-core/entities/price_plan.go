package entities

type PricePlan struct {
	AccountPricePlan      bool    `json:"accountPricePlan"`
	BreakPointPricing     bool    `json:"breakPointPricing"`
	Description           string  `json:"description"`
	DisplayCode           string  `json:"displayCode"`
	DisplayName           string  `json:"displayName"`
	DisplayNameEx         string  `json:"displayNameEx"`
	EndDate               string  `json:"endDate"`
	ExternalRateCode      string  `json:"externalRateCode"`
	ExternalUOMCd         string  `json:"externalUOMCd"`
	ExternalVendorPPU     float64 `json:"externalVendorPPU"`
	IsDistributionType    bool    `json:"isDistributionType"`
	IsSupplyType          bool    `json:"isSupplyType"`
	NonPassThruDomain     string  `json:"nonPassThruDomain"`
	PricePlanCode         string  `json:"pricePlanCode"`
	PricePlanId           uint64  `json:"pricePlanId"`
	Restricted            bool    `json:"restricted"`
	SeasonGroupId         uint64  `json:"seasonGroupId"`
	ServiceType           string  `json:"serviceType"`
	SignificanceProfileId uint64  `json:"significanceProfileId"`
	StartDate             string  `json:"startDate"`
	TypeCd                string  `json:"typeCd"`
	VendorDBNumber        string  `json:"vendorDBNumber"`
	VendorId              uint64  `json:"vendorId"`
	VendorName            string  `json:"vendorName"`
}
