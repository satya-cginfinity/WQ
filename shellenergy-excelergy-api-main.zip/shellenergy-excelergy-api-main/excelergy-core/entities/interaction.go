package entities

type Interaction struct {
	InteractionId    uint64 `json:"interactionId"`
	ContactName      string `json:"contactName"`
	Date             string `json:"date"`
	RelatedClassName string `json:"relatedClassName"`
	RelatedId        uint64 `json:"relatedId"`
	StartTime        int32  `json:"startTime"`
	SubTypeCode      string `json:"subTypeCode"`
	SubTypeCodeDesc  string `json:"subTypeCodeDesc"`
	Text             string `json:"text"`
	TypeCode         string `json:"typeCode"`
	UserName         string `json:"userName"`
}
