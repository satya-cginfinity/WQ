package entities

type Nomination struct {
	DisplayCode   string       `json:"displayCode"`
	DisplayName   string       `json:"displayName"`
	EndDate       FlexibleTime `json:"endDate"`
	NomId         uint64       `json:"nomId"`
	QuantityNo    float64      `json:"quantityNo"`
	StartDate     FlexibleTime `json:"startDate"`
	UnitOfMeasure string       `json:"unitOfMeasure"`
}
