package entities

type CollectionEventQueue struct {
	DisplayCode                  string `json:"displayCode"`
	DisplayName                  string `json:"displayName"`
	EstimatedDropDate            string `json:"estimatedDropDate"`
	LastCollectionEventQueueDate string `json:"lastCollectionEventQueueDate"`
	LastCollectionEventQueueID   uint64 `json:"lastCollectionEventQueueID"`
	LastCollectionEventQueueName string `json:"lastCollectionEventQueueName"`
	NextCollectionEventQueueDate string `json:"nextCollectionEventQueueDate"`
	NextCollectionEventQueueID   uint64 `json:"nextCollectionEventQueueID"`
	NextCollectionEventQueueName string `json:"nextCollectionEventQueueName"`
}
