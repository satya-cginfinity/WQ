package entities

type CreditCollectionRule struct {
	AccountLevelLPC                      bool    `json:"accountLevelLPC"`
	ChargeLateFee                        bool    `json:"chargeLateFee"`
	ChargeOneTime                        bool    `json:"chargeOneTime"`
	CollectionScheduleId                 uint64  `json:"collectionScheduleId"`
	CustClassType                        string  `json:"custClassType"`
	DefaultRule                          bool    `json:"defaultRule"`
	DisplayCode                          string  `json:"displayCode"`
	DisplayName                          string  `json:"displayName"`
	DueDaysInvoiceNo                     uint32  `json:"dueDaysInvoiceNo"`
	DueDaysMonthNo                       uint32  `json:"dueDaysMonthNo"`
	GraceDaysNo                          uint32  `json:"graceDaysNo"`
	GracePeriod                          bool    `json:"gracePeriod"`
	GracePeriodString                    string  `json:"gracePeriodString"`
	InvoiceAmountIncludesPreviousBalance bool    `json:"invoiceAmountIncludesPreviousBalance"`
	InvoiceDate                          bool    `json:"invoiceDate"`
	InvoiceDueDateBaseCode               string  `json:"invoiceDueDateBaseCode"`
	IsCustom                             bool    `json:"isCustom"`
	LatePaymentChargePercentage          float64 `json:"latePaymentChargePercentage"`
	MaximumCharge                        float64 `json:"maximumCharge"`
	MaximumRefundAmount                  float64 `json:"maximumRefundAmount"`
	MinimumCharge                        float64 `json:"minimumCharge"`
	MinimumOverdue                       float64 `json:"minimumOverdue"`
	MinimumRefundAmount                  float64 `json:"minimumRefundAmount"`
	OverrideReason                       string  `json:"overrideReason"`
	RelateClassName                      string  `json:"relateClassName"`
	RelateId                             uint64  `json:"relateId"`
	RuleName                             string  `json:"ruleName"`
	Simple                               bool    `json:"simple"`
	SimpleCompoundCode                   string  `json:"simpleCompoundCode"`
	Today                                bool    `json:"today"`
	UseBusinessDays                      bool    `json:"useBusinessDays"`
}
