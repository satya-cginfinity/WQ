package logger

// ILogger defines the interface for structured logging throughout the application.
// It supports standard log levels and structured logging with key-value fields.
type ILogger interface {
	// Debug logs a message at debug level with optional structured fields
	Debug(msg string, fields ...interface{})

	// Info logs a message at info level with optional structured fields
	Info(msg string, fields ...interface{})

	// Warn logs a message at warn level with optional structured fields
	Warn(msg string, fields ...interface{})

	// Error logs a message at error level with optional structured fields
	Error(msg string, fields ...interface{})

	// Fatal logs a message at fatal level and terminates the application
	Fatal(msg string, fields ...interface{})

	// With creates a child logger with additional context fields
	With(fields ...interface{}) ILogger

	// Sync flushes any buffered log entries
	Sync() error
}
