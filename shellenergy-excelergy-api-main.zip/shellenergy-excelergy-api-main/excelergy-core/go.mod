module github.com/sede-enterprise/shellenergy-excelergy-api/excelergy-core

go 1.25.0
