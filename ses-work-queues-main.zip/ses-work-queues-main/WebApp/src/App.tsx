import { ShellThemeProvider } from '@sede-enterprise/shell-ds-react-framework';
import { LicenseManager } from "ag-grid-enterprise";
import * as WorkQueueConstant from "./Utility/Constant";
import "./App.css";
import Navbar from "./Components/Navbar";
import Routes from "./Routes";
import { useEffect } from 'react';

// LicenseManager.setLicenseKey(process.env.REACT_APP_AGKEY as string); 
LicenseManager.setLicenseKey(import.meta.env.VITE_AGKEY);

function App() {

  useEffect(() => {    
   if(window.location.pathname == "/")
    localStorage.clear();
  }, []);
  
  const handleLogin = () => {
    window.location.assign(WorkQueueConstant.LOGIN_URL as string);
  };

  const handleLogout = () => {
    localStorage.clear();
    window.location.assign(import.meta.env.VITE_BASEURL as string);
  };
  
  return (
    <>
      <ShellThemeProvider theme="light">
        <Navbar
          title="Work Queue"
          isLoggedIn={false}
          onLogin={handleLogin}
          onLogout={handleLogout}
        />
        <Routes />
      </ShellThemeProvider>
    </>
  );
}
export default App;
