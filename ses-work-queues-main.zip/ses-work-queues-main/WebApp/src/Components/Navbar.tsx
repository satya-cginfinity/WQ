import { Grid, Menu, NavBar } from '@sede-enterprise/shell-ds-react-framework';
import { ItemType } from "@sede-enterprise/shell-ds-react-framework/build/esm/components/Menu/Menu.types";
import { GetUserNameSpaceSeperated } from '../Utility/UserDetailsHelper';

const Navbar = (props) => {

  const items: any = null;
  let LoggedIn = props.isLoggedIn;
  let userName;
  let email;

  if (localStorage.getItem("LoggedIn") !== null) {
    if (window.location.pathname === "/")
      LoggedIn = false
    else
      LoggedIn = localStorage.getItem("LoggedIn") === "true" ? true : false;
  }

  if (LoggedIn) {
    if (localStorage.getItem("email") !== null) {
      email = localStorage.getItem("email")?.toString();
      userName = GetUserNameSpaceSeperated();
    }
  }

  const menuItems: ItemType[] = !LoggedIn ? items || [{
    label: 'Login',
    itemIcon: <Grid />,
    onClick: props.onLogin
  },
  ] : items || [{
    label: 'Logout',
    itemIcon: <Grid />,
    onClick: props.onLogout,
  }];

  const avtarItems = LoggedIn ?
    {
      label: userName,
      additionalText: email,
      dropdownOverlay: <Menu items={menuItems}>
      </Menu>
    } :
    {
      dropdownOverlay: <Menu items={menuItems}>
      </Menu>
    };

  return (
    <NavBar
      header={{
        title: props.title
      }}
      avatarProps={avtarItems}>
    </NavBar>
  );
}

export default Navbar;