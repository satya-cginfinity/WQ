
const FilterTooltipRenderer = (props: any) => {
  if (!props.value) return null;
  return (
    <span title={props.value}>
      {props.value}
    </span>
  );
};

export default FilterTooltipRenderer;