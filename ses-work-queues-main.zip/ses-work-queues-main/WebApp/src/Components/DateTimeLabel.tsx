import React from "react";
import { Label } from "@sede-enterprise/shell-ds-react-framework";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";

dayjs.extend(utc);
dayjs.extend(timezone);


const DateTimeLabel = ({date}) => {

 const formatTimestamp = (date: Date | null) => {
   if (!date) return "";
   return dayjs(date)
     .tz("America/Chicago")
     .format("dddd, MMM DD, YYYY hh:mm A z");
 };

  return (
      <div className="dropdown">
        <Label>
        Updated as of: <span>{formatTimestamp(date)}</span>
      </Label>
      </div>
  );
};

export default DateTimeLabel;
