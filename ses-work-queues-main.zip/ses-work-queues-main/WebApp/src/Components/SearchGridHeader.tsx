import { Button, Sentiments, TextInput } from "@sede-enterprise/shell-ds-react-framework";
import { useState } from "react";

import * as WorkQueueConstant from "../Utility/Constant";

const SearchGridHeaderComponent = (props) => {

  const [searchItem, setGridSearchItem] = useState("");

  const IsEnterPressed = (e) => {
    if (e.key === 'Enter') {
      SearchOnGrid();
    }
  }

  const SearchOnGrid = () => {
    if (searchItem !== "") {
      props.gridRef.current.api.ensureColumnVisible(searchItem.toUpperCase(), 'start');
    }
    else {
      props.actionNotification(WorkQueueConstant.SEARCH_VALIDATION_MESSAGE);
    }
  }

  return (
    <div className="row searchrow g-1">
      <div className="col-md-8 dropdown">
        <TextInput type="text"
          clearable
          list="data"
          onChange={e => setGridSearchItem(e.target.value)}
          className="txtSearch"
          onKeyDown={IsEnterPressed}
          placeholder={WorkQueueConstant.SEARCH_PLACEHOLDER} />
      </div>
      <div className="col-md-4">
        <Button sentiment={Sentiments.Primary}
          className=""
          type="button"
          data-bs-toggle=""
          onClick={SearchOnGrid}
          aria-expanded="false">
          Search
        </Button>
        <datalist id="data">
          {props.excelparams.columnKeys.map((val) =>
            <option value={val} />
          )}
        </datalist>
      </div>
    </div>
  );
};

export default SearchGridHeaderComponent;
