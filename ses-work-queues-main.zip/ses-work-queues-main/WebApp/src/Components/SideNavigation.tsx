import { useState } from "react";
import { NavLink, Outlet } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faAngleDoubleRight, faAngleDoubleLeft } from "@fortawesome/free-solid-svg-icons";
import { Order, BarChart, Gears} from "@sede-enterprise/shell-ds-react-framework/build/esm/components/Icon/components";
import { Icons } from "@sede-enterprise/shell-ds-react-framework";

import { isUserAuthenticated } from "../Utility/Auth";
import * as WorkQueueConstant from "../Utility/Constant";

const SideNavigation = () => {
  const userType= localStorage.getItem("userType")

  const checkAuthentication = () => {
    isUserAuthenticated();
  };

  checkAuthentication();

  const [isSideNavOpen, setIsSideNavOpen] = useState(false);

  const toggleSideNav = () => {
    setIsSideNavOpen(!isSideNavOpen);
  };

  return (
    <>
      <button className="sidenavtogglebtn" onClick={toggleSideNav}>
        <FontAwesomeIcon icon={isSideNavOpen ? faAngleDoubleLeft : faAngleDoubleRight} /><span className="toggle-spn" hidden={isSideNavOpen ? false : true}> {WorkQueueConstant.COLLAPSE}</span>
      </button>
      <nav className={`side-nav ${isSideNavOpen ? "open" : "closed"}`}>
        <ul>
       
          <li>
            <NavLink to="/prebillvalidation">
              {isSideNavOpen === true ? (
                WorkQueueConstant.PREBILL
              ) : (
                <Icons.Home width={25} height={25}></Icons.Home>
              )}
            </NavLink>
          </li>
        
          <li>
            <NavLink to="/billing">
              {isSideNavOpen === true ? (
                WorkQueueConstant.BILLING
              ) : (
                <Order width={25} height={25}></Order>
              )}
            </NavLink>
          </li>
        </ul>
      </nav>
      <div className="row">
        <Outlet />
      </div>
    </>
  );
};

export default SideNavigation;
