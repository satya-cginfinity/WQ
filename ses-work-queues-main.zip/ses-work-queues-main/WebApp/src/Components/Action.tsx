//#region Libraries
import { useCallback, useState } from "react";
import { Button, FormField, Label, Loading, Modal, Positions, Sentiments, SingleDatePicker, Sizes, TextInput, Variants } from "@sede-enterprise/shell-ds-react-framework";
import { ArrowCcw, Download } from "@sede-enterprise/shell-ds-react-framework/build/esm/components/Icon/components";
import dayjs from 'dayjs';

import { ChangeInvoiceCycle, ChangeLDCAccountStatus, CloseMultipleBatchLogErrors, fetchBillingPreview, FetchInvoiceHolidays, MonthlyUsage, SetPreviewUsageHold } from "../API/FusionAPI";
import * as WorkQueueConstant from "../Utility/Constant";
import { ConvertDateTimeToString, ConvertDateToStringWithHyphen } from "../Utility/GridHelper";
import ModalComponent from "./Modal";
import DropdownComponent from "./Dropdown";
import { GetUserNameDotSeperated, GetUserNameSpaceSeperated } from "../Utility/UserDetailsHelper";

//#endregion

const ActionComponent = (props) => {

  //#region Constants
  const [openSetUsageModel, setOpenSetUsageModel] = useState(false);
  const [changeInvoiceCycleModel, setChangeInvoiceCycleModel] = useState(false);
  const [openSetUsageConfirmationModel, setOpenSetUsageConfirmationModel] = useState(false);
  const [invoiceCycleConfirmationModel, setInvoiceCycleConfirmationModel] = useState(false);
  const [openGenericConfirmationModal, setOpenGenericConfirmationModal] = useState(false);
  const [invoiceIds, setInvoiceIds] = useState('');
  const [monthlyUsageIds, setMonthlyUsageIds] = useState('');
  const optionSelected = '';
  const [expiryDate, setExpiryDate] = useState(null);
  const [invoiceCycleNo, setInvoiceCycleNo] = useState('');
  const [showLoader, setShowLoader] = useState(false);
  const [batchDetails, setBatchDetails] = useState({});
  const [holidayList, setHolidayList] = useState<dayjs.Dayjs[]>([]);
  const [accountIds, setAccountIds] = useState('');
  const confirmationMessage = props.selectedData.length === 1 ? WorkQueueConstant.CONFIRMATION_MESSAGE.replace("X", props.selectedData.length).replace("rows", "row") : WorkQueueConstant.CONFIRMATION_MESSAGE.replace("X", props.selectedData.length);
  const [LDCAccountDetails, setLDCAccountDetails] = useState(new Array());
  const [LDCStatusCode, setLDCStatusCode] = useState('');
  const [LDCStatusModel, setLDCStatusModel] = useState(false);
  const [LDCStatusConfirmationModel, setLDCStatusConfirmationModel] = useState(false);
  //#endregion

  //#region Generic Modal
  const GenericConfirmationModalOnClose = () => {
    setOpenGenericConfirmationModal(false);
    setShowLoader(false);
    props.gridRef.current?.api.deselectAll();
  };

  async function GenericConfirmationModalOnAction() {
    setShowLoader(true);
    if (props.activeTab === WorkQueueConstant.INVOICE_PREVIEW) {
      let result = await SetRemoveMonthlyUsageByInvoiceIds(invoiceIds, null);
      ActionNotificationRemoveUsageHold(result);
    }
    else if (props.activeTab === WorkQueueConstant.UNRATED_USAGE) {
      let result = await SetRemoveMonthlyUsage(null, monthlyUsageIds);
      ActionNotificationRemoveUsageHold(result);
    }
    else if (props.activeTab === WorkQueueConstant.INVOICE_BATCH_LOG_ERROR) {
      let result = await CloseMultipleBatchLogErrors(batchDetails);
      if (result) {
        props.actionNotification(WorkQueueConstant.SET_CLOSEBATCHLOGERRORS_SUCCESS);
      }
      else {
        props.actionNotification(WorkQueueConstant.SET_CLOSEBATCHLOGERRORS_ERROR);
      }
    }
    setOpenGenericConfirmationModal(false);
    props.gridRef.current?.api.deselectAll();
    setShowLoader(false);
  };

  const HandleExpiryDateOnChange = (expiryDate) => {
    if (expiryDate) {
      setExpiryDate(expiryDate);
      setOpenSetUsageConfirmationModel(true);
    } else {
      setExpiryDate(null);
    }
  }

  const HandleInvoiceCycleChange = (invoiceCycle) => {
    if (invoiceCycle) {
      setInvoiceCycleConfirmationModel(true);
    } else {
      setExpiryDate(null);
    }
  }

  //#endregion

  //#region Action Dropdown items & Action Button Click

  const GetDDLOptions = () => {

    if (props.activeTab === WorkQueueConstant.INVOICE_PREVIEW) {
      return [
        { value: WorkQueueConstant.REMOVE_USAGE_HOLD, label: WorkQueueConstant.REMOVE_USAGE_HOLD },
        { value: WorkQueueConstant.SET_USAGE_HOLD, label: WorkQueueConstant.SET_USAGE_HOLD }
      ];
    }
    else if (props.activeTab === WorkQueueConstant.UNRATED_USAGE) {
      return [
        { value: WorkQueueConstant.REMOVE_USAGE_HOLD, label: WorkQueueConstant.REMOVE_USAGE_HOLD },
        { value: WorkQueueConstant.SET_USAGE_HOLD, label: WorkQueueConstant.SET_USAGE_HOLD },
        { value: WorkQueueConstant.CHANGE_INVOICE_CYCLE, label: WorkQueueConstant.CHANGE_INVOICE_CYCLE }

      ];
    }
    else if (props.activeTab === WorkQueueConstant.UNBILLED_35_DAYS) {
      return [
        { value: WorkQueueConstant.CHANGE_INVOICE_CYCLE, label: WorkQueueConstant.CHANGE_INVOICE_CYCLE },
        //{ value: WorkQueueConstant.CHANGE_LDC_ACCOUNT_STATUS, label: WorkQueueConstant.CHANGE_LDC_ACCOUNT_STATUS }
      ];
    }
    else if (props.activeTab === WorkQueueConstant.INVOICE_BATCH_LOG_ERROR) {
      return [
        { value: WorkQueueConstant.CLOSE_BATCH_LOG_ERRORS, label: WorkQueueConstant.CLOSE_BATCH_LOG_ERRORS }
      ];
    }
    else
      return [{ value: WorkQueueConstant.CLICK_ACTION, label: WorkQueueConstant.CLICK_ACTION }];

  };

  var actionBtnDDL = GetDDLOptions();

  const handlePerformAction = (optionSelected) => {

    if (props.selectedData.length === 0) {
      props.actionNotification(WorkQueueConstant.MIN_RECORD + optionSelected.currentTarget.innerText);
    }
    else {
      if (props.activeTab === WorkQueueConstant.INVOICE_PREVIEW) {
        let invoiceID = "";
        props.selectedData.forEach(element => {
          //This INVOICE_ID is coming from database table 
          invoiceID += element.INVOICE_ID + ',';
        });
        invoiceID = invoiceID.replace(/(\s*,?\s*)*$/, "");
        setInvoiceIds(invoiceID);

        if (optionSelected.currentTarget.innerText === WorkQueueConstant.SET_USAGE_HOLD) {
          GetInvoiceHolidays();
          setOpenSetUsageModel(true);
        }
        else {
          setOpenGenericConfirmationModal(true);
        }
      }
      else if (props.activeTab === WorkQueueConstant.UNRATED_USAGE) {
        const monthlyUsageIDs: any = [];
        props.selectedData.forEach(element => {
          monthlyUsageIDs.push(element.MONTHLY_USAGE_ID);
        });

        setMonthlyUsageIds(monthlyUsageIDs);

        if (optionSelected.currentTarget.innerText === WorkQueueConstant.SET_USAGE_HOLD) {
          GetInvoiceHolidays();
          setOpenSetUsageModel(true);
        }
        else if (optionSelected.currentTarget.innerText === WorkQueueConstant.REMOVE_USAGE_HOLD) {
          setOpenGenericConfirmationModal(true);
        }
        else if (optionSelected.currentTarget.innerText === WorkQueueConstant.CHANGE_INVOICE_CYCLE) {
          const accountIds: any = [];
          props.selectedData.forEach(element => {
            accountIds.push(element.ACCT_ID);
          });
          setAccountIds(accountIds);
          setChangeInvoiceCycleModel(true);
        }

      }
      else if (props.activeTab === WorkQueueConstant.UNBILLED_35_DAYS) {
        if (optionSelected.currentTarget.innerText === WorkQueueConstant.CHANGE_INVOICE_CYCLE) {
          const accountIds: any = [];
          props.selectedData.forEach(element => {
            accountIds.push(element.ACCT_ID);
          });
          setAccountIds(accountIds);
          setChangeInvoiceCycleModel(true);
        }
        else if (optionSelected.currentTarget.innerText === WorkQueueConstant.CHANGE_LDC_ACCOUNT_STATUS) {
          let detailsList = new Array();
          props.selectedData.forEach(element => {
            let detail = {};
            detail["LDC_ACCT_NO"] = element.LDC_ACCT_NO;
            detail["SERVICE_ID"] = element.LDC_ACCT_ID;
            detail["STATUS_CODE"] = "";
            detailsList.push(detail);
          });
          setLDCAccountDetails(detailsList);
          setLDCStatusModel(true);
        }
      }
      else if (props.activeTab === WorkQueueConstant.INVOICE_BATCH_LOG_ERROR) {
        let batchDetailList = new Array();
        props.selectedData.forEach(element => {
          //These element values are coming from database table    
          let batchDetail = {};
          batchDetail["BATCH_ID"] = element.BATCH_ID;;
          batchDetail["BATCH_LOG_ID"] = element.BATCH_LOG_ID;
          batchDetailList.push(batchDetail);
        });

        let details = {
          "PAYLOADS": batchDetailList
        }
        setBatchDetails(details);
        setOpenGenericConfirmationModal(true);
      }
      else {
        //Need to implement as per requirement, for demo purpose showing no of records.
        props.actionNotification(`Perform action for selected records: ${props.selectedData.length} `);
      }
    }
  }

  //#endregion 

  //#region Export Button

  function processCellCallback(props) {
    if ((props.column.colId === WorkQueueConstant.INVOICE_ID) || (props.column.colId === WorkQueueConstant.LDC_ACCT_NO)
      || (props.column.colId === WorkQueueConstant.CREATION_DT) || (props.column.colId === WorkQueueConstant.MONTHLY_USAGE_ID)
      || (props.column.colId === WorkQueueConstant.BATCH_LOG_ID) || (props.column.colId === WorkQueueConstant.ACCT_NM)
      || (props.column.colId === WorkQueueConstant.LDCAcctNo) || (props.column.colId === WorkQueueConstant.BillingAcctNo) 
      || (props.column.colId === WorkQueueConstant.CustomerAcctNo) || (props.column.colId === WorkQueueConstant.BillingAcctName)
      || (props.column.colId === WorkQueueConstant.ACCT_ID) || (props.column.colId === WorkQueueConstant.LDC_ACCT_ID)
      || (props.column.colId === WorkQueueConstant.Monthly_Usage_Id) || (props.column.colId === WorkQueueConstant.METER_ID)) {
      return '\u200C' + (`${props.value}`);
    }
    else {
      return props.value;
    }
  }

  const onBtExport = useCallback(() => {
    if (props.gridRef.current?.props.rowData.length > 0) {
      var todaysDate = ConvertDateTimeToString(new Date());
      //bug fix: Remove empty column while exporting to csv
      let originalColumns = props.gridRef.current?.api.getColumns();
      let filteredColumns = props.gridRef.current?.api.getColumns().filter((column) => column.colId !== '0');
      var filteredColDef = filteredColumns.map(function (item) { return item.colDef; })
      props.gridRef.current.api.setColumnDefs(filteredColDef);
      props.gridRef.current.api.exportDataAsExcel({
        allColumns:true,
        fileName: (props.activeTab !== undefined && props.activeTab !== null) ? props.activeTab.replace(/ /g, '_') + '_' + todaysDate : "export",
        processCellCallback: processCellCallback
      });
      var originalColDef = originalColumns.map(function (item) { return item.colDef; });
      props.gridRef.current.api.setColumnDefs(originalColDef);
    }
    else {
      props.actionNotification(WorkQueueConstant.NO_RECORDS_TO_EXPORT);
    }
  }, [props]);

  //#endregion

  //#region Set Remove Usage Hold Handling

  const handleOnClose = () => {
    setOpenSetUsageModel(false);
    props.gridRef.current?.api.deselectAll();
    setExpiryDate(null);
    setShowLoader(false);
  };

  const handleSetConfirmationModalOnClose = () => {
    setOpenSetUsageConfirmationModel(false);
    setOpenSetUsageModel(true);
  };

  const ActionNotificationRemoveUsageHold = (message) => {

    if (message.status === WorkQueueConstant.USAGEHOLD_SUCCESS) {
      props.actionNotification(WorkQueueConstant.REMOVE_USAGE_SUCCESS);
    }
    else if (message.status === WorkQueueConstant.USAGEHOLD_ACCEPTED) {
      props.actionNotification(WorkQueueConstant.DATA_ACCEPTED_NOTIFICATION);
    }
    else {
      props.actionNotification(WorkQueueConstant.ACTION_ERROR);
    }
  }


  const ActionNotificationSetUsageHold = (message) => {

    if (message.status == WorkQueueConstant.USAGEHOLD_SUCCESS) {
      props.actionNotification(WorkQueueConstant.SET_USAGE_SUCCESS);
    }
    else if (message.status == WorkQueueConstant.USAGEHOLD_ACCEPTED) {
      props.actionNotification(WorkQueueConstant.DATA_ACCEPTED_NOTIFICATION);
    }
    else {
      props.actionNotification(WorkQueueConstant.ACTION_ERROR);
    }
  }

  async function ShowExpirypopup() {
    setShowLoader(true);
    let formatedExpirationDate = ConvertDateToStringWithHyphen(expiryDate);
    setOpenSetUsageConfirmationModel(false);
    let result;
    if (props.activeTab === WorkQueueConstant.INVOICE_PREVIEW) {
      result = await SetRemoveMonthlyUsageByInvoiceIds(invoiceIds, formatedExpirationDate);
      ActionNotificationSetUsageHold(result);
    }
    else if (props.activeTab === WorkQueueConstant.UNRATED_USAGE) {
      result = await SetRemoveMonthlyUsage(formatedExpirationDate, monthlyUsageIds);
      ActionNotificationSetUsageHold(result);
    }
    setExpiryDate(null);
    setOpenSetUsageModel(false);
    setShowLoader(false);
    props.gridRef.current?.api.deselectAll();
  };

  //#endregion

  //#region Set/Remove Usage Hold API Call
  const SetRemoveMonthlyUsageByInvoiceIds = async (invoiceIDs, expirationDate) => {
    let previewMonthlyUsageResult;
    const monthlyUsageIDs: any = [];
    let details = {
      "INVOICE_ID": invoiceIDs
    }
    try {
      const previewResult = await SetPreviewUsageHold(details);
      let previewHoldUsageResultMsg = previewResult.message;

      if (previewResult && previewResult.status === WorkQueueConstant.SUCCESS) {
        //getting monthlyUsageID from response
        for (const row of previewHoldUsageResultMsg) {
          monthlyUsageIDs.push(Object.values(row)[0])
        }
        const monthlyUsageResult = await SetRemoveMonthlyUsage(expirationDate, monthlyUsageIDs);
        return previewMonthlyUsageResult = monthlyUsageResult;
      }
      else {
        console.log('Error Message : ' + previewHoldUsageResultMsg.error);
        previewMonthlyUsageResult = { "status": WorkQueueConstant.USAGEHOLD_ERROR };
      }

      setMonthlyUsageIds(monthlyUsageIDs);
      //Pass the monthlyUsageIds and date to API2

    }
    catch (ex) {
      console.log('Error Message.' + ex);
      previewMonthlyUsageResult = { "status": WorkQueueConstant.USAGEHOLD_ERROR };
    }

    return previewMonthlyUsageResult;
  }

  const SetRemoveMonthlyUsage = async (expirationDate, monthlyUsageIDs) => {
    let previewMonthlyUsageResult;
    try {
      const monthlyUsageResult = await MonthlyUsage(monthlyUsageIDs, expirationDate);
      let monthlyUsageResultMsg = monthlyUsageResult.message;

      if (monthlyUsageResult && monthlyUsageResult.status === WorkQueueConstant.SUCCESS) {
        console.log(monthlyUsageResultMsg.message);
        previewMonthlyUsageResult = {
          "status": WorkQueueConstant.USAGEHOLD_SUCCESS
        };
      }
      else if (monthlyUsageResult && monthlyUsageResult.status === WorkQueueConstant.ACCEPTED) {
        console.log(monthlyUsageResultMsg.message);
        previewMonthlyUsageResult = {
          "status": WorkQueueConstant.USAGEHOLD_ACCEPTED
        };
      }
      else {
        console.log('Error Message : ' + monthlyUsageResultMsg.error);
        previewMonthlyUsageResult = {
          "status": WorkQueueConstant.USAGEHOLD_ERROR
        };
      }

    }
    catch (ex) {
      console.log('Error Message.' + ex);
      previewMonthlyUsageResult = {
        "status": WorkQueueConstant.USAGEHOLD_ERROR
      };
    }
    return previewMonthlyUsageResult;
  }

  //#endregion

  //#region DatePicker Configuration  

  const GetInvoiceHolidays = async () => {
    const invoiceHolidays = await FetchInvoiceHolidays();
    var holidays = invoiceHolidays.message.map(date => dayjs(date));
    setHolidayList(holidays);
  };

  const IsHoliday = (date) => {
    return holidayList.some(holiday => holiday.isSame(date, 'day'));
  };

  const DateDisabled = (date) => {
    const today = dayjs().startOf('day');
    const oneYearFromToday = dayjs().add(1, 'year').endOf('day');
    const dayOfWeek = dayjs(date).day();
    const currentDate = dayjs(date);
    return (currentDate.isBefore(today) || currentDate.isAfter(oneYearFromToday) || dayOfWeek === 0 || dayOfWeek === 6 || IsHoliday(currentDate));
  }

  //#endregion

  //#region Change Invoice Cycle 
  const HandleInvoiceCycleClose = () => {
    setChangeInvoiceCycleModel(false);
    props.gridRef.current?.api.deselectAll();
    setInvoiceCycleNo('');
    setShowLoader(false);
  };

  const InvoiceCycleConfirmationModalOnClose = () => {
    setInvoiceCycleConfirmationModel(false);
    setChangeInvoiceCycleModel(true);
  };

  const SetInvoiceCycle = async () => {
    setShowLoader(true);
    setInvoiceCycleConfirmationModel(false);
    let accountIdsList = accountIds.toString().split(",");
    let batchDetailList = new Array();
    accountIdsList.forEach(element => {
      //These element values are coming from database table    
      let batchDetail = {};
      batchDetail["ACCOUNT_ID"] = element;
      batchDetail["BILL_CYCLE"] = invoiceCycleNo;
      batchDetailList.push(batchDetail);
    });
    let details = {
      "PAYLOADS": batchDetailList
    }
    let result = await ChangeInvoiceCycle(details);
    if (result) {
      props.actionNotification(WorkQueueConstant.CHANGE_INVOICE_CYCLE_SUCCESS);
    }
    else {
      props.actionNotification(WorkQueueConstant.ACTION_ERROR);
    }
    setShowLoader(false);
    setInvoiceCycleNo('');
    setChangeInvoiceCycleModel(false);
    props.gridRef.current?.api.deselectAll();
  }

  const HandleChangeInvoiceCycleNo = () => {
    if (props.activeTab === WorkQueueConstant.UNRATED_USAGE) {
      SetInvoiceCycle();
    }
    else if (props.activeTab === WorkQueueConstant.UNBILLED_35_DAYS) {
      SetInvoiceCycle();
    }
  };

  const ValidateInput = (value) => {
    return new RegExp("^([1-9]|[12][0-9]|30)$").test(value) ? setInvoiceCycleNo(value) : setInvoiceCycleNo('');
  };
  //#endregion

  //#region Recache

  const EnableBillingPreviewRecache = async () => {
    let enableReache = true;
    try {
      const result = await fetchBillingPreview(enableReache);
      if (result.status === WorkQueueConstant.ACCEPTED && result.message !== 'undefined' && result.message.length !== 0) {
        let errorMessage = JSON.parse(result.message).error.trim().toUpperCase();
        if (errorMessage === WorkQueueConstant.FUSION_PREPARING_NOTIFICATION.trim().toUpperCase())
          props.actionNotification(WorkQueueConstant.RECACHE_ENABLE_SUCCESS);
        else
          props.actionNotification(WorkQueueConstant.ACTION_ERROR);
        console.log('Error Message : ' + errorMessage);
      }
      else {
        props.actionNotification(WorkQueueConstant.ACTION_ERROR);
        console.log('Error Message : ' + result);
      }
    }
    catch (ex) {
      console.log('Error Message.' + ex);
    }
  }
  //#endregion

  //#region Update LDC Account Status
  const UpdateLDCAccountStatus = () => {
    if (LDCStatusCode !== "") {
      setLDCStatusConfirmationModel(true);
    }
  }

  const SetLDCAccountStatus = async () => {
    setShowLoader(true);
    setLDCStatusConfirmationModel(false);
    setLDCStatusModel(true);
    LDCAccountDetails.forEach(element => {
      element["STATUS_CODE"] = LDCStatusCode;
    });
    let details = {
      "NAME": GetUserNameSpaceSeperated(),
      "USER_NAME": GetUserNameDotSeperated(),
      "PAYLOADS": LDCAccountDetails
    }
    let result = await ChangeLDCAccountStatus(details);
    if (result) {
      props.actionNotification(WorkQueueConstant.UPDATE_LDC_ACCOUNT_SUCCESS);
    }
    else {
      props.actionNotification(WorkQueueConstant.ACTION_ERROR);
    }
    setShowLoader(false);
    setLDCStatusCode('');
    setLDCStatusModel(false);
    props.gridRef.current?.api.deselectAll();
  }

  const HandleLDCAccountStatusModelClose = () => {
    setLDCStatusModel(false);
    props.gridRef.current?.api.deselectAll();
    setLDCStatusCode('');
    setShowLoader(false);
  };

  const UpdateLDCStatusConfirmationModalOnClose = () => {
    setLDCStatusConfirmationModel(false);
    setLDCStatusModel(true);
  };

  const GetLDCStatusDDLOptions = () => {
    return [
      { value: '', label: WorkQueueConstant.DEFAULT },
      { value: WorkQueueConstant.LDCACCOUNTSTATUS_CANC, label: WorkQueueConstant.LDCACCOUNTSTATUS_CANC },
      { value: WorkQueueConstant.LDCACCOUNTSTATUS_VOID, label: WorkQueueConstant.LDCACCOUNTSTATUS_VOID },
      { value: WorkQueueConstant.LDCACCOUNTSTATUS_TERM, label: WorkQueueConstant.LDCACCOUNTSTATUS_TERM }]
  };


  var LDCStatusDDLOptions = GetLDCStatusDDLOptions();

  const HandleLDCAccountStatus = (value) => {
    setLDCStatusCode(value);
  }
  //#endregion

  return (
    <>
      <div className="flex-container acticomp">
        <div className="col-md-4 flex-item">
          <Button sentiment={Sentiments.Primary}
            className="btnrecahe"
            type="button"
            data-bs-toggle=""
            aria-expanded="false"
            onClick={props.onClick}
            disabled={props.recacheDisabled}
            icon={<ArrowCcw />}
            iconPosition={Positions.Left}>
            REFRESH
          </Button>
        </div>
        <div className="col-md-4 flex-item">
          <Button sentiment={Sentiments.Primary}
            className="btnexp"
            type="button"
            data-bs-toggle=""
            aria-expanded="false"
            onClick={onBtExport}
            icon={<Download />}
            iconPosition={Positions.Left}>
            EXPORT
          </Button>
        </div>
        <div className="col-md-4 flex-item">
          <Button sentiment={Sentiments.Primary}
            className="dropdown-toggle btnaction"
            type="button"
            data-bs-toggle="dropdown"
            aria-expanded="false"
            disabled={props.actionDisabled}>
            ACTION
          </Button>
          <ul className="dropdown-menu btndropmenu" >
            {actionBtnDDL.map((option) => (
              <li>
                <button className="dropdown-item" onClick={handlePerformAction} value={optionSelected} >
                  {option.label}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div >
        <Modal open={openSetUsageModel} title="Expiration Date:" showHeader={!showLoader}
          onClose={() => {
            handleOnClose();
          }} >
          <div className="row">
            <div className="col-md-4">
            </div>
            <div className="col-md-4">
              {showLoader && <div className="modalLoader"><Loading /></div>}
              {!showLoader && <div>
                <SingleDatePicker className="expiry" id="ExpirationDateFilter" value={expiryDate} placeholder="Select Date" size={Sizes.Small}
                  inputReadOnly onChange={HandleExpiryDateOnChange} disabledDate={DateDisabled}
                />
              </div>
              }
            </div>
            <div className="col-md-4">
            </div>
          </div>
          <Modal open={openSetUsageConfirmationModel} title={WorkQueueConstant.CONFIRMATION_TITLE}
            onClose={() => {
              handleSetConfirmationModalOnClose();
            }} actions={[
              {
                label: 'Cancel',
                action: () => {
                  handleSetConfirmationModalOnClose();
                },
                props: {
                  variant: Variants.Transparent,
                  className: "cancelEDIpopUp"
                },
              }, {
                label: 'Confirm',
                action: () => {
                  ShowExpirypopup();
                }
              }]}>
            {!showLoader && <Label bold> {confirmationMessage} </Label>}
          </Modal>
        </Modal>
      </div>
      <div>
        <div >
          <ModalComponent openModel={openGenericConfirmationModal} showLoader={showLoader} ActionOnClose={GenericConfirmationModalOnClose}
            ActionOnConfirmation={GenericConfirmationModalOnAction} totalrecord={props.selectedData.length}>
          </ModalComponent>
        </div>
      </div>
      <div >
        <Modal open={changeInvoiceCycleModel} title={WorkQueueConstant.INVOICE_VAIDATION_MSG} showHeader={!showLoader} showFooter={!showLoader} onClose={() => {
          HandleInvoiceCycleClose();
        }} actions={[
          {
            label: 'Cancel',
            action: () => {
              HandleInvoiceCycleClose();
            },
            props: {
              variant: Variants.Transparent,
              className: "cancelEDIpopUp"
            },
          }, {
            label: 'Submit',
            action: () => {
              HandleInvoiceCycleChange(invoiceCycleNo);
            },
            props: {
              variant: Variants.Filled,
              className: "modalsubmit"
            }
          }
        ]}>
          <div className="row">
            <div className="col-md-4">
            </div>
            <div className="col-md-4">
              {showLoader && <div className="invoicechangeLoader"><Loading /></div>}
              {!showLoader && <div>
                <FormField label="Invoice Cycle Number">
                  <TextInput className="inputborder" value={invoiceCycleNo} onChange={e => setInvoiceCycleNo(e.target.value)}   onBlur={(e) => ValidateInput(e.target.value)} />
                </FormField>
              </div>
              }
            </div>
            <div className="col-md-4">
            </div>
          </div>
          <Modal className="invoiceconfirm" open={invoiceCycleConfirmationModel} title={WorkQueueConstant.CONFIRMATION_TITLE}
            onClose={() => {
              InvoiceCycleConfirmationModalOnClose();
            }} actions={[
              {
                label: 'Cancel',
                action: () => {
                  InvoiceCycleConfirmationModalOnClose();
                },
                props: {
                  variant: Variants.Transparent,
                  className: "cancelEDIpopUp"
                },
              }, {
                label: 'Confirm',
                action: () => {
                  HandleChangeInvoiceCycleNo();
                }
              }]}>
            {!showLoader && <Label bold> {confirmationMessage} </Label>}
          </Modal>
        </Modal>
      </div>
      <div >
        <Modal open={LDCStatusModel} showFooter={!showLoader} onClose={() => {
          HandleLDCAccountStatusModelClose();
        }} actions={[
          {
            label: 'Cancel',
            action: () => {
              HandleLDCAccountStatusModelClose();
            },
            props: {
              variant: Variants.Transparent,
              className: "cancelEDIpopUp"
            },
          }, {
            label: 'Submit',
            action: () => {
              UpdateLDCAccountStatus();
            },
            props: {
              variant: Variants.Filled,
              className: "modalsubmit"
            }
          }
        ]}>
          <div className="row">
            {showLoader && <div className="ldcchangeLoader"><Loading /></div>}
            {!showLoader && <div className="ldcdropdown">
              <label>{"LDC Account Status"}</label>
              <DropdownComponent DDLOptions={LDCStatusDDLOptions} selectedOption={LDCStatusCode} onSelect={HandleLDCAccountStatus} />

            </div>
            }

          </div>
          <Modal className="ldcconfirm" open={LDCStatusConfirmationModel} title={WorkQueueConstant.CONFIRMATION_TITLE}
            onClose={() => {
              UpdateLDCStatusConfirmationModalOnClose();
            }} actions={[
              {
                label: 'Cancel',
                action: () => {
                  UpdateLDCStatusConfirmationModalOnClose();
                },
                props: {
                  variant: Variants.Transparent,
                  className: "cancelEDIpopUp"
                },
              }, {
                label: 'Confirm',
                action: () => {
                  SetLDCAccountStatus();
                }
              }]}>
            {!showLoader && <Label bold> {confirmationMessage} </Label>}
          </Modal>
        </Modal>
      </div>
    </>
  );

  //#endregion
};

export default ActionComponent;