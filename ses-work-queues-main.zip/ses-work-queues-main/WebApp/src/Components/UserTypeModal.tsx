// import { Flexbox, Modal, RadioButton, Variants, Text, Prominences, TextTypes } from "@sede-enterprise/shell-ds-react-framework";
// import * as WorkQueueConstant from "../Utility/Constant";
// import { useState } from "react";

// const UserTypeModalComponent = (props) => {
//   const [checked, setChecked] = useState(WorkQueueConstant.B2C);
//   const SelectUserType = (event) => {
//     setChecked(event.target.value);
//   };

//   return (
//     <Modal title={
//       <span className="custom-modal-font">
//       {WorkQueueConstant.USERTYPE_TITLE_MSG} 
//       </span>}
//       description={WorkQueueConstant.USERTYPE_TITLE_DESCRIPTION}
//       open={props.openModel} onClose={() => {

//       }} closable={false}
//       actions={[
//         {
//           label: 'Proceed',
//           action: () => {
//             props.actionOnUserSelection(checked);
//           },
//           props: {
//             variant: Variants.Filled,
//             className: "modalsubmit"
//           }
//         }
//       ]}>
//       <div className="row">
//         <div className="col-md-1">
//         </div>
//         <div className="col-md-11">
//           <Flexbox flexDirection="column" rowGap="24px">
//             <RadioButton label={<>
//               <Text type={TextTypes.Span} prominence={Prominences.Strong} bold>{WorkQueueConstant.B2B}</Text> <Text prominence={Prominences.Subtle} type={TextTypes.Span}>{WorkQueueConstant.USERTYPE_B2B_DESC}</Text>
//             </>} name={WorkQueueConstant.B2B} value={WorkQueueConstant.B2B} onChange={SelectUserType} checked={checked === WorkQueueConstant.B2B} />
//             <RadioButton label={<>
//               <Text type={TextTypes.Span} prominence={Prominences.Strong} bold>{WorkQueueConstant.B2C}</Text> <Text prominence={Prominences.Subtle} type={TextTypes.Span}>{WorkQueueConstant.USERTYPE_B2C_DESC}</Text>
//             </>} name={WorkQueueConstant.B2C} value={WorkQueueConstant.B2C} onChange={SelectUserType} checked={checked === WorkQueueConstant.B2C} />
//           </Flexbox>
//         </div>
//       </div>
//     </Modal>
//   );
// };

// export default UserTypeModalComponent;