const DropdownComponent = (props) => {
  return (

    <select className="form-select" id="floatingSelect" aria-label="Floating label select example"
      onChange={(e) => props.onSelect(e.target.value)} disabled = {props.disableDropDown != null?props.disableDropDown:false}
      value={props.selectedOption} >
      {props.DDLOptions.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>

  );
};

export default DropdownComponent;