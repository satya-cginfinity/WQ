// import { Popconfirm, Sentiments, Button } from "@sede-enterprise/shell-ds-react-framework";
// import { QuestionMarkCircleSolid } from "@sede-enterprise/shell-ds-react-framework/build/esm/components/Icon/components";

// const PopupComponent =(props) => {

//     return(
//     <Popconfirm title={<Popconfirm.Title text={props.Title} />} description={<Popconfirm.Description
//         text= {props.Description} />}
//         sentiment={Sentiments.Warning} icon={<QuestionMarkCircleSolid />}  className={props.ClassName}
//         actions={[{
//           label: 'Cancel',
//           action: () => {
//             props.CancelAction(); 
//           }                 
//         }, {
//           label: 'Confirm',
//           action: () => { 
//             props.ConfirmAction(); 
//           }
//         }]} style={{
//           maxWidth: '300px'
//         }} >
//         <Button className="popup" id= {props.ButtonID}   variant="transparent"></Button>
//       </Popconfirm>
//     );
// };

// export default PopupComponent;