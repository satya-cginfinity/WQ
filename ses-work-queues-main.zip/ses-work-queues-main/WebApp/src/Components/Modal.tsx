import { Label, Loading, Modal, Variants } from "@sede-enterprise/shell-ds-react-framework";
import * as WorkQueueConstant from "../Utility/Constant";

const ModalComponent =(props) => {
const confirmationMessage = props.totalrecord === 1 ? WorkQueueConstant.CONFIRMATION_MESSAGE.replace("X", props.totalrecord).replace("rows","row"): WorkQueueConstant.CONFIRMATION_MESSAGE.replace("X", props.totalrecord);
    return(
      <Modal showHeader={!props.showLoader} showFooter={!props.showLoader} title={WorkQueueConstant.CONFIRMATION_TITLE}
      open={props.openModel} onClose={() => {
        props.ActionOnClose();
      }}
      actions={[
        {
          label: 'Cancel',
          action: () => {
            props.ActionOnClose();
          },
          props: {
            variant: Variants.Transparent,
            className: "cancelEDIpopUp"
          },
        }, {
          label: 'Confirm',
          action: () => {
            props.ActionOnConfirmation();
          },
          props: {
            variant: Variants.Filled,
            className: "modalsubmit"
          }
        }
      ]}>
        {props.showLoader && <div className="remmodalLoader"><Loading /></div>}        
        {!props.showLoader && <Label bold> {confirmationMessage} </Label>}
    </Modal>
    );
};

export default ModalComponent;