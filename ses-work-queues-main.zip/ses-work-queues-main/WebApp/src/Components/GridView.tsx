import { useCallback, useRef } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import React from "react";

const GridView = (props) => {

  const rowData = props.rowData;
  const columnDefs = props.colDef;
  const gridRef = useRef<AgGridReact>(null);

  const onload = useCallback(() => {
    gridRef.current!.api.showLoadingOverlay();
    if (props.agref !== undefined)
      props.agref(gridRef);
  }, [props]);

  const handleSelectionChanged = (event) => {
    const selectedNodes = event.api.getSelectedNodes();
    const selectedIds = selectedNodes.map((node) => node.data);
    props.selectedGridData(selectedIds);
  };

  const defaultColDef = { sortable: true, editable: true,suppressFilterSearch: true };
  // handling page size popup it was opening outside of grid and disturbing UI layout
  const popArea = document.querySelector("#root")?.getBoundingClientRect().height; 
  document.body.style.height = popArea + 'px';

  return (
    <>
      <div>
        <div className="ag-theme-alpine">
          <AgGridReact
            ref={gridRef}
            rowData={rowData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            rowSelection="multiple"
            onSelectionChanged={handleSelectionChanged}
            pagination={true}
            paginationPageSize={50}
            paginationPageSizeSelector={[50, 100, 500]}
            popupParent={document.body}
            alwaysShowHorizontalScroll={true}
            onGridReady={onload}
            rowBuffer={20}
            suppressRowVirtualisation={false}
            suppressColumnVirtualisation={false}
            cacheQuickFilter={true}
          />
        </div>
      </div>
    </>
  );
};

export default React.memo(GridView);
