
function Setting() {
  return (
    <div>
      <h4>To edit to settings!</h4>
    </div>
  )
}

export default Setting
