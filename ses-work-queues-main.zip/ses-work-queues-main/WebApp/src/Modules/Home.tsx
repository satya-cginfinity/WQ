import "../Assets/Common.css";
import { useEffect } from "react";
import * as WorkQueueConstant from "../Utility/Constant";


function Home() {  

  function SetTokenDetails(data) {
    if(!data.hasOwnProperty('error')){
      localStorage.setItem('access-token',data.token);
      localStorage.setItem('token-expiration',data.exp);
      localStorage.setItem('refresh-token',data.refresh_token);
      localStorage.setItem('email',data.email);
      localStorage.setItem("LoggedIn", "true");
      window.location.assign(WorkQueueConstant.REACT_APP_DASHBOARD as string);
    }
    else{
      console.log(data.error.toString());
    }
  }

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    fetch(`${WorkQueueConstant.GET_TOKEN_BY_CODE + code}`, {
      method: 'GET',
      headers: {
        'Accept': 'Application/json',
        'Content-Type': 'Application/json'
      }
    })
      .then((res) => res.json())
      .then((data) => SetTokenDetails(data));
  }, []);

  return (
    <></>
  );
}
export default Home;
