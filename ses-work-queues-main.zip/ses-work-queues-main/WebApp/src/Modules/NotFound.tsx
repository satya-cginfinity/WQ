
function NotFound(){

    window.location.assign(import.meta.env.VITE_BASEURL as string);
  return <></>;
}

export default NotFound;