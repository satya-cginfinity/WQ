import { useEffect, useRef, useState } from "react";
import dayjs from "dayjs";
import { Alert,Sentiments, SingleDatePicker,Sizes, Tabs, RangeDatePicker, CalendarValueType} from "@sede-enterprise/shell-ds-react-framework";
import { AgGridReact } from "ag-grid-react";
import { fetchContractExpiringAccounts, fetchPrebilled } from "../API/mp2API";
import { ConvertDateToString,GetColDefValue, GetColParamValue,} from "../Utility/GridHelper";
import * as WorkQueueConstant from "../Utility/Constant";
import GridView from "../Components/GridView";
import ActionComponent from "../Components/Action";
import DateTimeLabel from "../Components/DateTimeLabel";
import { useSearchParams } from "react-router-dom";
import { FilterPersistence } from "../Utility/FilterPersistence";

const gridCache = {
  PREBILL: {
    rowData: null,
    filterModel: null
  },
  CONTRACT_EXPIRATION_ACCOUNTS: {
    rowData: null,
    filterModel: null
  }
};

const PreBillValidation = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const urlTab = searchParams.get('tab') || WorkQueueConstant.PREBILL;
  
  // Helper function to parse date from URL params
  const parseDateFromUrl = (paramName: string, defaultValue: CalendarValueType = null) => {
    const dateStr = searchParams.get(paramName);
    return dateStr ? dayjs(dateStr) : defaultValue;
  };

  // Helper function to parse filter model from URL params
  const parseFilterFromUrl = (tabName: string) => {
    const filterStr = searchParams.get(`${tabName}_filters`);
    try {
      return filterStr ? JSON.parse(decodeURIComponent(filterStr)) : null;
    } catch (error) {
      console.warn('Failed to parse filter from URL:', error);
      return null;
    }
  };

  // Helper function to update filter in URL
  const updateFilterInUrl = (tabName: string, filterModel: any) => {
    const newSearchParams = new URLSearchParams(searchParams);
    if (filterModel && Object.keys(filterModel).length > 0) {
      newSearchParams.set(`${tabName}_filters`, encodeURIComponent(JSON.stringify(filterModel)));
    } else {
      newSearchParams.delete(`${tabName}_filters`);
    }
    setSearchParams(newSearchParams);
  };

  // Initialize dates from URL params or defaults
  const [selectedTabOption, setSelectedTabOption] = useState(urlTab);

  //#region Prebill validation Variables
  const [prebilledRowData, setprebilledRowData] = useState([]);
  const [prebilledColDefs, setprebilledColDefs] = useState([]);
  const [prebillAgRef, setprebillAgRef] = useState(useRef<AgGridReact>(null));
  //#endregion

  //region contract expiration account variables
  const [contractExpirationRowData, setContractExpirationRowData] = useState([]);
  const [contractExpirationColDefs, setContractExpirationColDefs] = useState([]);
  const [contractExpirationAgRef, setContractExpirationAgRef] = useState(useRef<AgGridReact>(null));
// region

  const [colParam, setColParam] = useState([]);
  const [agRef, setAgRef] = useState(useRef<AgGridReact>(null));
  const [showDatefilter, setShowDatefilter] = useState(false);
  const [showDropDown, setShowDropDown] = useState(false);
  const [selectedDateFilterDate, setSelectedDateFilterDate] = useState(null);
  
  // Initialize dates from sessionStorage first, then URL params or defaults
  const initializeMinDate = () => {
    const savedFilters = FilterPersistence.load('prebill', WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS);
    if (savedFilters?.minDate) {
      return dayjs(savedFilters.minDate);
    }
    return parseDateFromUrl('minDate', dayjs(new Date()));
  };
  
  const initializeMaxDate = () => {
    const savedFilters = FilterPersistence.load('prebill', WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS);
    if (savedFilters?.maxDate) {
      return dayjs(savedFilters.maxDate);
    }
    return parseDateFromUrl('maxDate', dayjs(new Date()).add(30, 'day'));
  };
  
  const [selectedMinDate, setSelectedMinDate] = useState<CalendarValueType>(initializeMinDate());
  const [selectedMaxDate, setSelectedMaxDate] = useState<CalendarValueType>(initializeMaxDate());
  const [actionNotification, setActionNotification] = useState("");
  const [showAlert, setShowAlert] = useState(false);
  const [enableSearchGrid, setEnableSearchGrid] = useState(false);
  const [enableActionComponent, setEnableActionComponent] = useState(false);
  const [disableActionButton, setDisableActionButton] = useState(false);
  const [enableB2BUser, setEnableB2BUser] = useState(false);
  const [selectedIds, setSelectedIds] = useState([]);
  const [tab,setTab]= useState(WorkQueueConstant.PREBILL)
  const [lastRefreshed, setLastRefreshed] = useState<Date | null>(null);

  // Initialize filters from URL
  useEffect(() => {
    const prebillFilter = parseFilterFromUrl('PREBILL');
    const contractFilter = parseFilterFromUrl('CONTRACT_EXPIRATION_ACCOUNTS');
    
    if (prebillFilter) {
      gridCache.PREBILL.filterModel = prebillFilter;
    }
    if (contractFilter) {
      gridCache.CONTRACT_EXPIRATION_ACCOUNTS.filterModel = contractFilter;
    }
  }, []);

  const excelparams = {
    columnKeys: colParam,
  };
  const GetSelectedGridData = (arg) => {
    setSelectedIds(arg);
  };
  const LoadLoader = () => {
    if (agRef.current !== undefined && agRef.current !== null) {
      agRef.current!.api.showLoadingOverlay();
      agRef.current!.api.setColumnsPinned(colParam, null);
      agRef.current!.api.setFilterModel(null);
      agRef.current!.api.deselectAll();
    }
  };

  // Updated useEffect to handle date changes and trigger API calls
  useEffect(() => {
    if (showDatefilter && selectedTabOption === WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS) {
      // Clear cache when dates change to force fresh data
      gridCache.CONTRACT_EXPIRATION_ACCOUNTS.rowData = null;
      gridCache.CONTRACT_EXPIRATION_ACCOUNTS.filterModel = null;
      // Clear filters from URL when dates change
      updateFilterInUrl('CONTRACT_EXPIRATION_ACCOUNTS', null);
      HandleDateChangeOperation();
    }
  }, [selectedMinDate, selectedMaxDate]);

  const HandleDateChangeOperation = () => {
    LoadLoader();
    if (selectedTabOption === WorkQueueConstant.PREBILL) {
      GetPrebilledData();
    }
    else if (selectedTabOption === WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS) {
        gridCache.CONTRACT_EXPIRATION_ACCOUNTS.rowData = null;
        gridCache.CONTRACT_EXPIRATION_ACCOUNTS.filterModel = null;
      GetContractExpirationData();
    }
    
  };

  // Updated function to handle date changes and update URL
  const HandleOnChangeMinMaxDate = (selectedDate) => {
    if (selectedDate) {
      const newMinDate = selectedDate[0];
      const newMaxDate = selectedDate[1];
      
      setSelectedMinDate(newMinDate);
      setSelectedMaxDate(newMaxDate);
      
      // Update URL params with new dates
      const newSearchParams = new URLSearchParams(searchParams);
      newSearchParams.set('minDate', newMinDate.format('YYYY-MM-DD'));
      newSearchParams.set('maxDate', newMaxDate.format('YYYY-MM-DD'));
      setSearchParams(newSearchParams);
      
      // Save to sessionStorage for cross-page persistence
      FilterPersistence.save('prebill', WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS, {
        minDate: newMinDate.format('YYYY-MM-DD'),
        maxDate: newMaxDate.format('YYYY-MM-DD')
      });
    } else {
      setSelectedMinDate(null);
      setSelectedMaxDate(null);
      
      // Remove date params from URL
      const newSearchParams = new URLSearchParams(searchParams);
      newSearchParams.delete('minDate');
      newSearchParams.delete('maxDate');
      setSearchParams(newSearchParams);
      
      // Clear from sessionStorage
      FilterPersistence.save('prebill', WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS, {
        minDate: null,
        maxDate: null
      });
    }
  };
  const getDatePlaceholders = (): [string, string] => {
    const today = new Date();
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + 30);
  
    const formatDate = (date: Date) => {
      return date.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      }).replace(/ /g, ' ');
    };
  
    return [formatDate(today), formatDate(futureDate)];
  };

  useEffect(() => {
      SetUserSelection(localStorage.getItem("userType"));
  }, []);

  useEffect(() => {
    // Set showDatefilter based on the current tab (including on page refresh)
    if (selectedTabOption === WorkQueueConstant.PREBILL || selectedTabOption === WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS) {
      setShowDatefilter(true);
    }

    // Load data with persisted dates on initial load
    if (selectedTabOption === WorkQueueConstant.PREBILL && !gridCache.PREBILL.rowData) {
      GetPrebilledData();
    }

    if (selectedTabOption === WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS && !gridCache.CONTRACT_EXPIRATION_ACCOUNTS.rowData) {
      GetContractExpirationData();
    }
  }, [selectedTabOption]);
  //#region Pre-billed Validation methods
  ;
const handleRefresh = () => {
  if (selectedTabOption === WorkQueueConstant.PREBILL) {
    gridCache.PREBILL.rowData = null;
    gridCache.PREBILL.filterModel = null;
    // Clear filters from URL
    updateFilterInUrl('PREBILL', null);
    LoadLoader();
    GetPrebilledData();
  } else if (selectedTabOption === WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS) {
    gridCache.CONTRACT_EXPIRATION_ACCOUNTS.rowData = null;
    gridCache.CONTRACT_EXPIRATION_ACCOUNTS.filterModel = null;
    // Clear filters from URL
    updateFilterInUrl('CONTRACT_EXPIRATION_ACCOUNTS', null);
    
    // Reset date filters to default values
    const defaultMinDate = dayjs(new Date());
    const defaultMaxDate = dayjs(new Date()).add(30, 'day');
    setSelectedMinDate(defaultMinDate);
    setSelectedMaxDate(defaultMaxDate);
    
    // Update URL params with default dates
    const newSearchParams = new URLSearchParams(searchParams);
    newSearchParams.set('minDate', defaultMinDate.format('YYYY-MM-DD'));
    newSearchParams.set('maxDate', defaultMaxDate.format('YYYY-MM-DD'));
    setSearchParams(newSearchParams);
    
    // Don't call GetContractExpirationData() here - let the useEffect handle it
  }
};
const GetPrebilledData = async () => {
  try {
    const cache = gridCache.PREBILL;
    if (cache.rowData) {
      setColParam(GetColParamValue(cache.rowData));
      setprebilledColDefs(GetColDefValue(cache.rowData));
      setprebilledRowData(cache.rowData);
      setTimeout(() => {
        if (prebillAgRef.current && prebillAgRef.current.api && cache.filterModel) {
          prebillAgRef.current.api.setFilterModel(cache.filterModel);
          prebillAgRef.current.api.onFilterChanged();
        }
      }, 500);
      setLastRefreshed(new Date());
      return;
    }

    LoadLoader();
    const result = await fetchPrebilled();
    const resultMsg = JSON.parse(result.message);

    if (resultMsg) {
      const allColDefs = GetColDefValue(resultMsg);
      const hiddenFields = [
        WorkQueueConstant.ACCT_ID,
        WorkQueueConstant.LDC_ACCT_ID,
        WorkQueueConstant.Monthly_Usage_Id,
        WorkQueueConstant.METER_ID
      ];
      const updatedColDefs = allColDefs.map(col => ({
        ...col,
        hide: hiddenFields.includes(col.field)
      }));
      setprebilledColDefs(updatedColDefs);
      setColParam(GetColParamValue(resultMsg));
      setprebilledRowData(resultMsg);
      setLastRefreshed(new Date());

      gridCache.PREBILL.rowData = resultMsg;
      
      // Apply persisted filters after data load
      setTimeout(() => {
        if (prebillAgRef.current && prebillAgRef.current.api && gridCache.PREBILL.filterModel) {
          prebillAgRef.current.api.setFilterModel(gridCache.PREBILL.filterModel);
          prebillAgRef.current.api.onFilterChanged();
        }
      }, 500);
    } else {
      setColParam([]);
      setprebilledColDefs([]);
      setprebilledRowData([]);
      setLastRefreshed(new Date());
    }
  } catch (ex) {
    console.log("Error Message Pre bill data." + ex);
    setColParam([]);
    setprebilledColDefs([]);
    setprebilledRowData([]);
    setLastRefreshed(new Date());
  }
};
  // Enhanced GetPrebilledAgref with better event handling
  const GetPrebilledAgref = (gridRef) => {
    setAgRef(gridRef);
    setprebillAgRef(gridRef);
    
    // Set up event listener when grid is ready
    if (gridRef && gridRef.current) {
      const setupEventListener = () => {
        const api = gridRef.current?.api;
        if (api) {
          // Use onGridReady event to ensure proper timing
          const onFilterChanged = () => {
            const filterModel = api.getFilterModel();
            gridCache.PREBILL.filterModel = filterModel;
            updateFilterInUrl('PREBILL', filterModel);
            console.log('PREBILL filter changed:', filterModel); // Debug log
          };
          
          api.addEventListener('filterChanged', onFilterChanged);
          
          // Also listen for grid ready to apply persisted filters
          api.addEventListener('gridReady', () => {
            setTimeout(() => {
              if (gridCache.PREBILL.filterModel) {
                api.setFilterModel(gridCache.PREBILL.filterModel);
                api.onFilterChanged();
                console.log('Applied PREBILL filter:', gridCache.PREBILL.filterModel); // Debug log
              }
            }, 200);
          });
        }
      };
      
      // Try immediately or wait for grid to be ready
      if (gridRef.current.api) {
        setupEventListener();
      } else {
        setTimeout(setupEventListener, 100);
      }
    }
  };

  //#endregion

   //#region ContractExpiration methods
  
  const GetContractExpirationData = async () => {
  try {
    const cache = gridCache.CONTRACT_EXPIRATION_ACCOUNTS;
    if (cache.rowData) {
      setColParam(GetColParamValue(cache.rowData));
      setContractExpirationColDefs(GetColDefValue(cache.rowData));
      setContractExpirationRowData(cache.rowData);
      setTimeout(() => {
        if (contractExpirationAgRef.current && contractExpirationAgRef.current.api && cache.filterModel) {
          contractExpirationAgRef.current.api.setFilterModel(cache.filterModel);
          contractExpirationAgRef.current.api.onFilterChanged();
        }
      }, 500);
      return;
    }

    LoadLoader();
    const minDate = selectedMinDate ? ConvertDateToString(selectedMinDate) : "";
    const maxDate = selectedMaxDate ? ConvertDateToString(selectedMaxDate) : "";
    const result = await fetchContractExpiringAccounts(minDate, maxDate);
    const resultMsg = JSON.parse(result.message);

    if (resultMsg) {
      setColParam(GetColParamValue(resultMsg));
      setContractExpirationColDefs(GetColDefValue(resultMsg));
      setContractExpirationRowData(resultMsg);

      gridCache.CONTRACT_EXPIRATION_ACCOUNTS.rowData = resultMsg;
      
      // Apply persisted filters after data load
      setTimeout(() => {
        if (contractExpirationAgRef.current && contractExpirationAgRef.current.api && gridCache.CONTRACT_EXPIRATION_ACCOUNTS.filterModel) {
          contractExpirationAgRef.current.api.setFilterModel(gridCache.CONTRACT_EXPIRATION_ACCOUNTS.filterModel);
          contractExpirationAgRef.current.api.onFilterChanged();
        }
      }, 500);
    } else {
      setColParam([]);
      setContractExpirationColDefs([]);
      setContractExpirationRowData([]);
    }
  } catch (ex) {
    console.error("Error fetching Contract Expiration data:", ex);
    setColParam([]);
    setContractExpirationColDefs([]);
    setContractExpirationRowData([]);
  }
};
  // Enhanced GetContracExpAgref with better event handling
  const GetContracExpAgref = (gridRef) => {
    setAgRef(gridRef);
    setContractExpirationAgRef(gridRef);
    
    // Set up event listener when grid is ready
    if (gridRef && gridRef.current) {
      const setupEventListener = () => {
        const api = gridRef.current?.api;
        if (api) {
          // Use onGridReady event to ensure proper timing
          const onFilterChanged = () => {
            const filterModel = api.getFilterModel();
            gridCache.CONTRACT_EXPIRATION_ACCOUNTS.filterModel = filterModel;
            updateFilterInUrl('CONTRACT_EXPIRATION_ACCOUNTS', filterModel);
            console.log('CONTRACT_EXPIRATION_ACCOUNTS filter changed:', filterModel); // Debug log
          };
          
          api.addEventListener('filterChanged', onFilterChanged);
          
          // Also listen for grid ready to apply persisted filters
          api.addEventListener('gridReady', () => {
            setTimeout(() => {
              if (gridCache.CONTRACT_EXPIRATION_ACCOUNTS.filterModel) {
                api.setFilterModel(gridCache.CONTRACT_EXPIRATION_ACCOUNTS.filterModel);
                api.onFilterChanged();
                console.log('Applied CONTRACT_EXPIRATION_ACCOUNTS filter:', gridCache.CONTRACT_EXPIRATION_ACCOUNTS.filterModel); // Debug log
              }
            }, 200);
          });
        }
      };
      
      // Try immediately or wait for grid to be ready
      if (gridRef.current.api) {
        setupEventListener();
      } else {
        setTimeout(setupEventListener, 100);
      }
    }
  };
  //#endregion

  const GetActionNotification = (arg) => {
    setActionNotification(arg);
    if (selectedTabOption === WorkQueueConstant.PREBILL) {
      LoadLoader();
      GetPrebilledData();
      GetContractExpirationData()
    }
    setShowAlert(true);
    setTimeout(() => {
      setShowAlert(false);
    }, 10000);
  };

const HandleTabClickInitialization = () => {
  setSelectedDateFilterDate(null);

  const currentTab = selectedTabOption;

  if (gridCache[currentTab] && agRef.current && agRef.current.api) {
    gridCache[currentTab].filterModel = agRef.current.api.getFilterModel();
    // Update filter in URL when switching tabs
    updateFilterInUrl(currentTab, gridCache[currentTab].filterModel);

    // Save date filters to sessionStorage for CONTRACT_EXPIRATION_ACCOUNTS tab
    if (currentTab === WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS) {
      FilterPersistence.save('prebill', currentTab, {
        minDate: selectedMinDate ? dayjs(selectedMinDate).format('YYYY-MM-DD') : null,
        maxDate: selectedMaxDate ? dayjs(selectedMaxDate).format('YYYY-MM-DD') : null
      });
    }

    const allRows: any[] = [];
    agRef.current.api.forEachNodeAfterFilter(node => {
      allRows.push(node.data);
    });

    gridCache[currentTab].rowData = allRows;
  }
};

// Updated HandleTabClick to preserve date params
const HandleTabClick = (tab) => {
  HandleTabClickInitialization();
  setTab(tab);
  
  // Preserve existing date parameters when changing tabs
  const newSearchParams = new URLSearchParams(searchParams);
  newSearchParams.set('tab', tab);
  setSearchParams(newSearchParams);

  if (tab === WorkQueueConstant.PREBILL) {
    setShowDatefilter(true);
    setAgRef(prebillAgRef);
    setSelectedTabOption(WorkQueueConstant.PREBILL);
    if (!gridCache.PREBILL.rowData) {
      GetPrebilledData();
    }
  }
  if (tab === WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS) {
    setShowDatefilter(true);
    setAgRef(contractExpirationAgRef);
    setSelectedTabOption(WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS);

    // Restore date filters from sessionStorage first, then URL, then defaults
    const savedFilters = FilterPersistence.load('prebill', WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS);
    if (savedFilters?.minDate && savedFilters?.maxDate) {
      setSelectedMinDate(dayjs(savedFilters.minDate));
      setSelectedMaxDate(dayjs(savedFilters.maxDate));
    } else if (searchParams.get('minDate') && searchParams.get('maxDate')) {
      setSelectedMinDate(parseDateFromUrl('minDate', dayjs(new Date())));
      setSelectedMaxDate(parseDateFromUrl('maxDate', dayjs(new Date()).add(30, 'day')));
    }

    if (!gridCache.CONTRACT_EXPIRATION_ACCOUNTS.rowData) {
      GetContractExpirationData();
    }
  }
};
  const billingTabitemsB2B = [
    {
      label: WorkQueueConstant.PREBILL,
      key: WorkQueueConstant.PREBILL,
      children: (
        <GridView
          rowData={prebilledRowData}
          colDef={prebilledColDefs}
          selectedGridData={GetSelectedGridData}
          agref={GetPrebilledAgref}
        />
      ),
    },
    {
      label: WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS,
      key: WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS,
      children: (
        <GridView
          rowData={contractExpirationRowData}
          colDef={contractExpirationColDefs}
          selectedGridData={GetSelectedGridData}
          agref={GetContracExpAgref}
        />
      ),
    },
  ];

  
  const SetB2BUserScreen=()=>{
  setEnableB2BUser(true);
  setDisableActionButton(true);
  setSelectedTabOption(urlTab);
  setTab(urlTab);
  setEnableSearchGrid(true);
  setEnableActionComponent(true);
  }


useEffect(() => {
  const ref = selectedTabOption === "PREBILL" ? prebillAgRef : contractExpirationAgRef;

  if (selectedTabOption === "PREBILL") {
    if (!gridCache.PREBILL.rowData) {
      GetPrebilledData();
    } else {
      setprebilledColDefs(GetColDefValue(gridCache.PREBILL.rowData));
      setColParam(GetColParamValue(gridCache.PREBILL.rowData));
      setprebilledRowData(gridCache.PREBILL.rowData);

      setTimeout(() => {
        if (ref.current && gridCache.PREBILL.filterModel) {
          ref.current.api.setFilterModel(gridCache.PREBILL.filterModel);
          ref.current.api.onFilterChanged();
        }
      }, 100);
    }
  }

  if (selectedTabOption === "CONTRACT_EXPIRATION_ACCOUNTS") {
    if (!gridCache.CONTRACT_EXPIRATION_ACCOUNTS.rowData) {
      GetContractExpirationData();
    } else {
      setContractExpirationColDefs(GetColDefValue(gridCache.CONTRACT_EXPIRATION_ACCOUNTS.rowData));
      setColParam(GetColParamValue(gridCache.CONTRACT_EXPIRATION_ACCOUNTS.rowData));
      setContractExpirationRowData(gridCache.CONTRACT_EXPIRATION_ACCOUNTS.rowData);

      setTimeout(() => {
        if (ref.current && gridCache.CONTRACT_EXPIRATION_ACCOUNTS.filterModel) {
          ref.current.api.setFilterModel(gridCache.CONTRACT_EXPIRATION_ACCOUNTS.filterModel);
          ref.current.api.onFilterChanged();
        }
      }, 100);
    }
  }
}, [selectedTabOption]);

  const SetUserSelection = (userType) => {
    SetB2BUserScreen();
    setEnableSearchGrid(true);
    setEnableActionComponent(true);
  };
  return (
    <>
      <div className="row">
        <div className="row ">
          <div className="col-md-12 billingalertdiv">
            {showAlert && (
              <div className="col-md-6 billingalert">
                <Alert size={Sizes.Small} sentiment={Sentiments.Information}>
                  {actionNotification}
                </Alert>
              </div>
            )}
          </div>
        </div>
        <div className="row g-3">
          <div className="col-md-4 mt-0 g-4 billingfilterrow">
            {showDropDown && (
              <div className="form-floating">
                <label htmlFor="floatingSelect">
                  {WorkQueueConstant.FILTERS}
                </label>
              </div>
            )}
           {showDatefilter && (
          <>
            {tab === WorkQueueConstant.CONTRACT_EXPIRATION_ACCOUNTS && (
              <>
                <label htmlFor="DateRange">Contract End Date</label>
                <div className="col-md-12 mtp">
                  <RangeDatePicker
                    id="DateRange"
                    placeholder={getDatePlaceholders()}
                    size={Sizes.Medium}
                    onChange={HandleOnChangeMinMaxDate}
                    value={[selectedMinDate, selectedMaxDate]}
                    inputReadOnly
                  />
                </div>
              </>
            )}
          </>
      )}
</div>
</div>

        <div className="row g-3">
          {enableActionComponent && (
            <>
            {tab === WorkQueueConstant.PREBILL &&(
            <div className="col-md-12 mb-3 d-flex flex-column align-items-end">
           <DateTimeLabel date={lastRefreshed}/>
           </div>
            )}
            <div className="col-md-12 mb-3">
              <ActionComponent
                selectedData={selectedIds}
                gridRef={agRef}
                excelparams={excelparams}
                activeTab={selectedTabOption}
                recacheDisabled={false}
                actionNotification={GetActionNotification}
                onClick={handleRefresh}  
                enableActionComponent
              />
            </div>
            </>
          )}
        </div>
        {enableB2BUser && (
           <Tabs
            items={billingTabitemsB2B}
            activeKey={searchParams.get('tab') || WorkQueueConstant.PREBILL} 
            className="tabPanel"
            emphasis={false}
            onTabClick={HandleTabClick}
            />
        )}
      </div>
    </>
  );
};

export default PreBillValidation;
