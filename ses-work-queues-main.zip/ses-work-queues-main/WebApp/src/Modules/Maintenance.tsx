
import { 
  EmptyState,
} from '@sede-enterprise/shell-ds-react-framework';
import {CityCityFalse } from '@sede-enterprise/shell-ds-react-framework/build/esm/components/Pictogram/components';


function Maintenance(){
  return <EmptyState title="Work In Progress!" pictogram={<CityCityFalse />}/>;
}

export default Maintenance;