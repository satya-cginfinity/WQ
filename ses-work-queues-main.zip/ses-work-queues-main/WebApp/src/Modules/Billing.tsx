import React, { useEffect, useRef, useState } from "react";
import dayjs from "dayjs";
import { Alert, Button, Sentiments, SingleDatePicker, Sizes, Tabs, TextInput } from "@sede-enterprise/shell-ds-react-framework";
import { AgGridReact } from "ag-grid-react";
import { fetchInvoiceBatchLogErrors, fetchUnratedUsage , fetchDuplicateMonthlyUsage, fetchUnbilledUsage,fetchPendingFirstBill } from "../API/mp2API";
import { ConvertDateToString, GetColDefValue, GetColParamValue } from "../Utility/GridHelper";
import * as WorkQueueConstant from "../Utility/Constant";
import GridView from "../Components/GridView";
import ActionComponent from "../Components/Action";
import SearchGridHeaderComponent from "../Components/SearchGridHeader";
import DropdownComponent from "../Components/Dropdown";
import { useSearchParams } from 'react-router-dom';
import { createRefreshMap } from "../Utility/RefreshHelper";
import { GetDDLOptions } from "../Utility/DDLHelper";
import { gridCache } from "../Utility/GridCache";
import { FilterPersistence } from "../Utility/FilterPersistence";


const Billing = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const urlTab = searchParams.get('tab') || WorkQueueConstant.UNRATED_USAGE;
  
  // Helper function to parse date from URL params for specific tab
  const parseDateFromUrl = (tabName: string, defaultValue = null) => {
    const paramName = `${tabName}_date`;
    const dateStr = searchParams.get(paramName);
    return dateStr ? dayjs(dateStr) : defaultValue;
  };

  // Helper function to update date in URL for specific tab
  const updateDateInUrl = (tabName: string, dateValue) => {
    const newSearchParams = new URLSearchParams(searchParams);
    const paramName = `${tabName}_date`;
    if (dateValue) {
      newSearchParams.set(paramName, dayjs(dateValue).format('YYYY-MM-DD'));
    } else {
      newSearchParams.delete(paramName);
    }
    setSearchParams(newSearchParams);
  };

  const [selectedTabOption, setSelectedTabOption] = useState(urlTab);

   //#region InvoicePreview Variables
  const [variance, setVariance] = useState("");
  const [varianceType, setVarianceType] = useState("");
  const [selectedIds, setSelectedIds] = useState([]);
  const [selectedIPDDLOption, setSelectedIPDDLOption] = useState('');
  const [disabledIPFilter, setDisabledIPFilter] = useState(true);
  const [disabledRecacheAction, setDisabledRecacheAction] = useState(false);

  //#endregion

  //#region UnratedUsage Variables
  const [unratedUsageRowData, setUnratedUsageRowData] = useState([]);
  const [unratedUsageColDefs, setUnratedUsageColDefs] = useState([]);
  const [unratedUsageAgRef, setUnratedUsageAgRef] = useState(useRef<AgGridReact>(null));
  //#endregion

  //#region Duplicate Usages Variables
  const [duplicateUsageRowData, setDuplicateUsageRowData] = useState([]);
  const [duplicateUsageColDefs, setDuplicateUsageColDefs] = useState([]);
  const [duplicateUsageAgRef, setDuplicateUsageAgRef] = useState(useRef<AgGridReact>(null));
  //#endregion

  //#region InvoiceBatchLogError Variables
  const [invoiceBatchLogErrorRowData, setInvoiceBatchLogErrorRowData] = useState([]);
  const [invoiceBatchLogErrorColDefs, setInvoiceBatchLogErrorColDefs] = useState([]);
  const [invoiceBatchLogErrorAgRef, setInvoiceBatchLogErrorAgRef] = useState(useRef<AgGridReact>(null));
  //#endregion

//#region Unbilled35 days Variables
  const [unbilledUsageRowData, setUnbilledUsageRowData] = useState([]);
  const [unbilledUsageColDefs, setUnbilledUsageColDefs] = useState([]);
  const [unbilledUsageAgRef, setUnbilledUsageAgRef] = useState(useRef<AgGridReact>(null));
  //#endregion

  //#region Pending First Bill Variables
  const [pendingFirstBillRowData, setPendingFirstBillRowData] = useState([]);
  const [pendingFirstBillColDefs, setPendingFirstBillColDefs] = useState([]);
  const [pendingFirstBillAgRef, setPendingFirstBillAgRef] = useState(useRef<AgGridReact>(null));
  //#endregion

  const [colParam, setColParam] = useState([]);
  const [agRef, setAgRef] = useState(useRef<AgGridReact>(null));
  const [showDatefilter, setShowDatefilter] = useState(false);
  const [showDropDown, setShowDropDown] = useState(false);
  const [selectedDateFilterDate, setSelectedDateFilterDate] = useState(() => {
    // Initialize with the current tab's date from URL
    const tabToParamMap = {
      [WorkQueueConstant.UNRATED_USAGE]: 'unrated',
      [WorkQueueConstant.INVOICE_BATCH_LOG_ERROR]: 'invoice', 
      [WorkQueueConstant.UNBILLED_35_DAYS]: 'unbilled'
    };
    const paramName = tabToParamMap[urlTab];
    if (paramName) {
      const dateStr = searchParams.get(`${paramName}_date`);
      return dateStr ? dayjs(dateStr) : null;
    }
    return null;
  });
  const [actionNotification, setActionNotification] = useState('');
  const [showAlert, setShowAlert] = useState(false);
  const [enableSearchGrid, setEnableSearchGrid] = useState(false);
  const [enableActionComponent, setEnableActionComponent] = useState(false);
  const [disableActionButton, setDisableActionButton] = useState(false);
  const [enableB2BUser, setEnableB2BUser] = useState(true);
  const [isRestoringDate, setIsRestoringDate] = useState(false);


  const excelparams = {
    columnKeys: colParam
  };

  const LoadLoader = () => {
    if (agRef.current !== undefined && agRef.current !== null) {
      agRef.current!.api.showLoadingOverlay();
      agRef.current!.api.setColumnsPinned(colParam, null);
      agRef.current!.api.setFilterModel(null);
      agRef.current!.api.deselectAll();
    }
  };

  const HideLoader = () => {
    if (agRef.current !== undefined && agRef.current !== null) {
      agRef.current!.api.hideOverlay();
    }
  };

  const GetSelectedGridData = (arg) => {
    setSelectedIds(arg);
  };

  useEffect(() => {
    if (showDatefilter && selectedDateFilterDate !== null && selectedDateFilterDate !== undefined && !isRestoringDate) {
      const currentTabCache = gridCache[selectedTabOption];
      
      // Check if this is the same date that's already cached for this tab
      const isSameCachedDate = currentTabCache && 
                              currentTabCache.dateFilter && 
                              JSON.stringify(currentTabCache.dateFilter) === JSON.stringify(selectedDateFilterDate);
      
      // Check if we have cached data with this date filter
      const hasCachedDataForDate = currentTabCache && 
                                  currentTabCache.rowData && 
                                  isSameCachedDate;
      
      if (!hasCachedDataForDate) {
        console.log('Date filter changed or no cached data, triggering API call for tab:', selectedTabOption);
        const timeoutId = setTimeout(() => {
          HandleDateChangeOperation();
        }, 10);
        return () => clearTimeout(timeoutId);
      } else {
        console.log('Using cached data for date:', selectedDateFilterDate);
      }
    }
  }, [selectedDateFilterDate, selectedTabOption])

  const HandleDateChangeOperation = () => {
    
    if (selectedTabOption === WorkQueueConstant.UNRATED_USAGE) {
      gridCache.UNRATED_USAGE.rowData = null;
      gridCache.UNRATED_USAGE.filterModel = null;
      LoadLoader();
      GetUnrateData();
    }
    else if (selectedTabOption === WorkQueueConstant.INVOICE_BATCH_LOG_ERROR) {
      gridCache.INVOICE_BATCH_LOG_ERROR.rowData = null;
      gridCache.INVOICE_BATCH_LOG_ERROR.filterModel = null;
      LoadLoader();
      GetInvoiceBatchLogErrorData();
    }
     else if (selectedTabOption === WorkQueueConstant.UNBILLED_35_DAYS) { 
      gridCache.UNBILLED_35_DAYS.rowData = null;
      gridCache.UNBILLED_35_DAYS.filterModel = null;
      LoadLoader();
      GetUnbilledUsage();
    }
  }

  const HandleOnChangeDateFilter = (selectedDate) => {
    setSelectedDateFilterDate(selectedDate);
    
    // Update URL parameter with new date for current tab
    const tabToParamMap = {
      [WorkQueueConstant.UNRATED_USAGE]: 'unrated',
      [WorkQueueConstant.INVOICE_BATCH_LOG_ERROR]: 'invoice',
      [WorkQueueConstant.UNBILLED_35_DAYS]: 'unbilled'
    };
    const paramName = tabToParamMap[selectedTabOption];
    if (paramName) {
      updateDateInUrl(paramName, selectedDate);
    }
    
    // Save to sessionStorage for cross-page persistence
    FilterPersistence.save('billing', selectedTabOption, {
      dateFilter: selectedDate ? dayjs(selectedDate).format('YYYY-MM-DD') : null
    });
    
    if (gridCache[selectedTabOption]) {
      gridCache[selectedTabOption].dateFilter = selectedDate;
    }
  }

  const SetGridFilter = (filterName) => {
    var filterSelect: any = {};
    filterName.forEach(element => {
      const filterModel = [
        { filterType: 'set', values: GetFilterData(element) },
        null
      ];
      filterSelect[element] = {
        filtertype: "multi",
        filterModels: filterModel
      };
    });
    agRef.current!.api.setFilterModel(filterSelect);
    agRef.current!.api.onFilterChanged();
    agRef.current!.api.setColumnsPinned(filterName, 'left');
  };

  const SetReverseFilter = (filterName) => {
    var filterSelect: any = {};
    filterName.forEach(element => {
      const filterModel = [
        { filterType: 'set', values: GetReverseFilter(element) },
        null
      ];
      filterSelect[element] = {
        filtertype: "multi",
        filterModels: filterModel
      };
    });
    agRef.current!.api.setFilterModel(filterSelect);
    agRef.current!.api.onFilterChanged();
    agRef.current!.api.setColumnsPinned(filterName, 'left');
  };

  const GetReverseFilter = (columnName) => {
    const gridHeaderValues: any = [];
    agRef.current!.api.forEachNode(node => gridHeaderValues.push(node.data));
    const gridColumnArray = gridHeaderValues.map(row => row[columnName]);
    const filteredValues: any = [];
    const excludeValues: any = [];

    if (columnName === WorkQueueConstant.PREVIEW_PRODUCT_TYPE) {
      excludeValues.push(WorkQueueConstant.RESI_FIXED_CHANGE, WorkQueueConstant.RESI_FLAT_FEE, WorkQueueConstant.RESI_HOLDOVER);
      let includeValues = gridColumnArray.filter(record => !excludeValues.includes(record));
      includeValues.forEach(element => {
        filteredValues.push(element);
      });
    }
    else if (columnName === WorkQueueConstant.DPP_FLAG) {
      filteredValues.push('Y');
    }
    else if (columnName === WorkQueueConstant.PREVIEW_TDSP) {
      gridColumnArray.forEach(element => {
        if (!isNaN(element) && Math.floor(element) !== Math.ceil(element))
          filteredValues.push(element.toString());
      });
    }
    else if (columnName === WorkQueueConstant.NO_PA_INSTALL) {
      gridColumnArray.forEach(element => {
        if (element === 1) { filteredValues.push(element.toString()); }
      });
    }
    else if (columnName === WorkQueueConstant.BB_COUNT) {
      gridColumnArray.forEach(element => {
        if (element === 1) { filteredValues.push(element.toString()); }
      });
    }
    else if (columnName === WorkQueueConstant.RATE) {
      gridColumnArray.forEach(element => {
        if ((element > 0) && (element != null)) { filteredValues.push(element.toString()); }
      });
    }
    return filteredValues;
  };

  const GetFilterData = (columnName) => {
    const varianceValues: any = [];
    agRef.current!.api.forEachNode(node => varianceValues.push(node.data));
    const varianceArray = varianceValues.map(row => row[columnName]);
    const filteredVarianceValues: any = [];

    if (columnName === WorkQueueConstant.PREVIEW_PRODUCT_TYPE) {
      filteredVarianceValues.push(WorkQueueConstant.RESI_FIXED_CHANGE, WorkQueueConstant.RESI_FLAT_FEE, WorkQueueConstant.RESI_HOLDOVER);
    }
    else if (columnName === WorkQueueConstant.DPP_FLAG) {
      filteredVarianceValues.push('Y');
    }
    else if (columnName === WorkQueueConstant.PREVIEW_TDSP) {
      varianceArray.forEach(element => {
        if (!isNaN(element) && Math.floor(element) !== Math.ceil(element))
          filteredVarianceValues.push(element.toString());
      });
    }
    else if (columnName === WorkQueueConstant.NO_PA_INSTALL) {
      varianceArray.forEach(element => {
        if (element === 0 || element > 1) { filteredVarianceValues.push(element.toString()); }
      });
    }
    else if (columnName === WorkQueueConstant.BB_COUNT) {
      varianceArray.forEach(element => {
        if (element > 1) { filteredVarianceValues.push(element.toString()); }
      });
    }
    else if (columnName === WorkQueueConstant.RATE) {
      varianceArray.forEach(element => {
        if (element === 0)
          filteredVarianceValues.push(element.toString());
        else if (element === null) { filteredVarianceValues.push(element); }
      });
    }
    else if (columnName === WorkQueueConstant.DOL_PCT_VAR_DIFF || columnName === WorkQueueConstant.KWH_PCT_VAR_DIFF) {
      varianceArray.forEach(element => {
        if (element > variance) { filteredVarianceValues.push(element.toString()); }
      });
    }
    else if (columnName === WorkQueueConstant.LAST_INVOICE_NO) {
      filteredVarianceValues.push('');
    }
    return filteredVarianceValues;
  };

  const HandleFilter = (dropdownValue) => {
    agRef.current!.api.setFilterModel(null);
    var filterColumnList: string[] = [];
    // Unpin all filtered columns
    agRef.current!.api.setColumnsPinned(colParam, null);
    const varianceBlock = document.getElementById('varianceBlock');
    if (varianceBlock) {
      varianceBlock.style.display = 'none';
      setVariance("");
    }
    setSelectedIPDDLOption(dropdownValue);
    if (gridCache[selectedTabOption]) {
      gridCache[selectedTabOption].selectedIPDDLOption = dropdownValue;
    }
    switch (dropdownValue) {
      case WorkQueueConstant.BUNDLED_RATES_TDSP:
        filterColumnList = [WorkQueueConstant.PREVIEW_PRODUCT_TYPE, WorkQueueConstant.PREVIEW_TDSP];
        SetGridFilter(filterColumnList);
        break;

      case WorkQueueConstant.BB_INVOICE_BB_COUNT:
        filterColumnList = [WorkQueueConstant.BB_COUNT];
        SetGridFilter(filterColumnList);
        break;

      case WorkQueueConstant.INVOICE_DPP:
        filterColumnList = [WorkQueueConstant.DPP_FLAG, WorkQueueConstant.NO_PA_INSTALL];
        SetGridFilter(filterColumnList);
        break;

      case WorkQueueConstant.INVOICE_RATE:
        filterColumnList = [WorkQueueConstant.RATE];
        SetGridFilter(filterColumnList);
        break;

      case WorkQueueConstant.INVOICE_VARIANCE_$$:
      case WorkQueueConstant.INVOICE_VARIANCE_KWH:
        if (varianceBlock)
          varianceBlock.style.display = 'block';
        setVarianceType(dropdownValue);
        break;

      case WorkQueueConstant.FIRST_TIME_BILLERS:
        filterColumnList = [WorkQueueConstant.LAST_INVOICE_NO];
        SetGridFilter(filterColumnList);
        break;

      case WorkQueueConstant.REVERSE_BUNDLED_RATES_TDSP:
        filterColumnList = [WorkQueueConstant.PREVIEW_PRODUCT_TYPE, WorkQueueConstant.PREVIEW_TDSP];
        SetReverseFilter(filterColumnList);
        break;

      case WorkQueueConstant.REVERSE_BB_INVOICE_BB_COUNT:
        filterColumnList = [WorkQueueConstant.BB_COUNT];
        SetReverseFilter(filterColumnList);
        break;

      case WorkQueueConstant.REVERSE_INVOICE_DPP:
        filterColumnList = [WorkQueueConstant.DPP_FLAG, WorkQueueConstant.NO_PA_INSTALL];
        SetReverseFilter(filterColumnList);
        break;

      case WorkQueueConstant.REVERSE_INVOICE_RATE:
        filterColumnList = [WorkQueueConstant.RATE];
        SetReverseFilter(filterColumnList);
    }
  };


  const FilterByVariance = () => {
    var filterColumnList: any = [];
    if (variance !== null && variance !== "") {
      if (varianceType === WorkQueueConstant.INVOICE_VARIANCE_KWH) {
        filterColumnList = [WorkQueueConstant.KWH_PCT_VAR_DIFF]
        SetGridFilter(filterColumnList);
      }
      else if (varianceType === WorkQueueConstant.INVOICE_VARIANCE_$$)
        filterColumnList = [WorkQueueConstant.DOL_PCT_VAR_DIFF]
      SetGridFilter(filterColumnList);
    }
    else {
      alert(WorkQueueConstant.VARIANCE_EMPTY);
    }
  };

  //#region Unrated Usage methods
  const GetUnrateDataWithDate = async (dateValue) => {
    try{
      let clickedDate = dateValue ? ConvertDateToString(dateValue) : "";
      const result = await fetchUnratedUsage(clickedDate);  
      const resultMsg = JSON.parse(result.message);
      if (resultMsg) {
        setColParam(GetColParamValue(resultMsg));
        setUnratedUsageColDefs(GetColDefValue(resultMsg));
        setUnratedUsageRowData(resultMsg);
        gridCache.UNRATED_USAGE.rowData = resultMsg;
      } else {
        setColParam([]);
        setUnratedUsageColDefs([]);
        setUnratedUsageRowData([]);
      }
      HideLoader();
    }
    catch(error){
      console.log('Error Message.' + error);
      setColParam([])
      setUnratedUsageColDefs([]);
      setUnratedUsageRowData([]);
   
      HideLoader();
    }
  };

  const GetUnrateData = async () => {
    return GetUnrateDataWithDate(selectedDateFilterDate);
  };
  const GetUnratedUsageAgref = (arg) => {
    setAgRef(arg);
    setUnratedUsageAgRef(arg);
  };

  //#endregion

  //tooltip for the Filter
  useEffect(() => {
    const observer = new MutationObserver(() => {
      document.querySelectorAll('.ag-label-ellipsis').forEach(el => {
        if (el.textContent && !el.getAttribute('title')) {
          el.setAttribute('title', el.textContent);
        }
      });
    
    });
    observer.observe(document.body, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, []);

  //#region InvoiceBatchLogError methods

 const GetInvoiceBatchLogErrorDataWithDate = async (dateValue) => {
  try{
    let clickedDate = dateValue ? ConvertDateToString(dateValue) : "";
    const result = await fetchInvoiceBatchLogErrors(clickedDate);   
    const resultMsg = JSON.parse(result.message);

    if (resultMsg) {
      setColParam(GetColParamValue(resultMsg));
      setInvoiceBatchLogErrorColDefs(GetColDefValue(resultMsg));
      setInvoiceBatchLogErrorRowData(resultMsg);
      gridCache.INVOICE_BATCH_LOG_ERROR.rowData = resultMsg;
    } else {
      setColParam([]);
      setInvoiceBatchLogErrorColDefs([]);
      setInvoiceBatchLogErrorRowData([]);
    }
    HideLoader();
  }
    catch(error){
      console.log('Error Message.' + error);
      setColParam([])
      setInvoiceBatchLogErrorColDefs([]);
      setInvoiceBatchLogErrorRowData([]);
      HideLoader();
    }
  };

 const GetInvoiceBatchLogErrorData = async () => {
   return GetInvoiceBatchLogErrorDataWithDate(selectedDateFilterDate);
 };
  const GetInvoiceBatchLogErrorAgref = (arg) => {
    setAgRef(arg);
    setInvoiceBatchLogErrorAgRef(arg);
  };


    //#region GetDuplicateMonthlyUsage methods
  
  const GetDuplicateMonthlyUsage = async () => {
    try {
      const result = await fetchDuplicateMonthlyUsage();
      const resultMsg = JSON.parse(result.message);

      if (resultMsg) {
        setColParam(GetColParamValue(resultMsg));
        setDuplicateUsageColDefs(GetColDefValue(resultMsg));
        setDuplicateUsageRowData(resultMsg);
        gridCache.DUPLICATE_USAGE.rowData = resultMsg;
      } else {
        setColParam([]);
        setDuplicateUsageColDefs([]);
        setDuplicateUsageRowData([]);
      }
    } catch (error) {
      console.error("Error fetching Duplicate Usage data:", error);
      setColParam([]);
      setDuplicateUsageColDefs([]);
      setDuplicateUsageRowData([]);
    }
  };
  const GetDuplicateMonthlyUsageAgref = (arg) => {
    setAgRef(arg);
    setDuplicateUsageAgRef(arg);
  };

    //#region GetUnbilledUsage methods
  
  const GetUnbilledUsageWithDate = async (dateValue) => {
    try {
      let clickedDate = dateValue ? ConvertDateToString(dateValue) : "";
      const result = await fetchUnbilledUsage(clickedDate); 
      const resultMsg = JSON.parse(result.message);

      if (resultMsg) {
        setColParam(GetColParamValue(resultMsg))
        setUnbilledUsageColDefs(GetColDefValue(resultMsg));
        setUnbilledUsageRowData(resultMsg);
        gridCache.UNBILLED_35_DAYS.rowData = resultMsg;
      } else {
       setColParam([])
        setUnbilledUsageColDefs([]);
        setUnbilledUsageRowData([]);
      }
      HideLoader();
    } catch (error) {
      console.error("Error fetching Unbilled 35 data:", error);
      setColParam([]);
      setUnbilledUsageColDefs([]);
      setUnbilledUsageRowData([]);
      HideLoader();
    }
  };

  const GetUnbilledUsage = async () => {
    return GetUnbilledUsageWithDate(selectedDateFilterDate);
  };
  const GetUnbilledUsageAgref = (arg) => {
    setAgRef(arg);
    setUnbilledUsageAgRef(arg);
  };

  //#region GetPendingFirstBill methods
  
  const GetPendingFirstBill = async () => {
    try {
      const result = await fetchPendingFirstBill();
      const resultMsg = JSON.parse(result.message);

      if (resultMsg) {
        setColParam(GetColParamValue(resultMsg))
        setPendingFirstBillColDefs(GetColDefValue(resultMsg));
        setPendingFirstBillRowData(resultMsg);
        gridCache.PENDING_FIRST_BILL.rowData = resultMsg;
      } else {
        setColParam([])
        setPendingFirstBillColDefs([]);
        setPendingFirstBillRowData([]);
      }
    } catch (error) {
      console.error("Error fetching Pending First Bill data:", error);
       setColParam([])
       setPendingFirstBillColDefs([]);
       setPendingFirstBillRowData([]);
    }
  };

  const GetPendingFirstBillUsageAgref = (arg) => {
    setAgRef(arg);
    setPendingFirstBillAgRef(arg);
  };


  //handle refresh region
const refreshMap = createRefreshMap({
  unratedUsage: () => { GetUnrateData(); },
  invoiceBatchLogError: () => { GetInvoiceBatchLogErrorData(); },
  duplicateUsage: () => { GetDuplicateMonthlyUsage(); },
  unbilled35days: () => { GetUnbilledUsage(); },
  pendingFirstBill: () => { GetPendingFirstBill(); }
});

  //end handle refresh region

  const handleRefresh = () => {
    const refreshConfig = refreshMap[selectedTabOption];
    if (refreshConfig) {
      gridCache[refreshConfig.cacheKey].rowData = null;
      gridCache[refreshConfig.cacheKey].filterModel = null;
      
      // Reset date filter for tabs that use date filtering
      const tabsWithDateFilter = [
        WorkQueueConstant.UNRATED_USAGE,
        WorkQueueConstant.INVOICE_BATCH_LOG_ERROR,
        WorkQueueConstant.UNBILLED_35_DAYS
      ];
      
      if (tabsWithDateFilter.includes(selectedTabOption)) {
        // Clear the date filter
        setSelectedDateFilterDate(null);
        
        // Remove date parameter from URL for current tab
        const tabToParamMap = {
          [WorkQueueConstant.UNRATED_USAGE]: 'unrated',
          [WorkQueueConstant.INVOICE_BATCH_LOG_ERROR]: 'invoice',
          [WorkQueueConstant.UNBILLED_35_DAYS]: 'unbilled'
        };
        const paramName = tabToParamMap[selectedTabOption];
        if (paramName) {
          const newSearchParams = new URLSearchParams(searchParams);
          newSearchParams.delete(`${paramName}_date`);
          setSearchParams(newSearchParams);
        }
        
        // Clear date filter from cache
        gridCache[refreshConfig.cacheKey].dateFilter = null;
        
        // Directly call the API with null date - bypassing useEffect
        LoadLoader();
        if (selectedTabOption === WorkQueueConstant.UNRATED_USAGE) {
          GetUnrateDataWithDate(null);
        } else if (selectedTabOption === WorkQueueConstant.INVOICE_BATCH_LOG_ERROR) {
          GetInvoiceBatchLogErrorDataWithDate(null);
        } else if (selectedTabOption === WorkQueueConstant.UNBILLED_35_DAYS) {
          GetUnbilledUsageWithDate(null);
        }
      } else {
        // For tabs without date filter, proceed normally
        LoadLoader();
        refreshConfig.fn();
      }
    }
  };
  
  const GetActionNotification = (arg) => {
    setActionNotification(arg);
    if (selectedTabOption === WorkQueueConstant.INVOICE_BATCH_LOG_ERROR && arg === WorkQueueConstant.SET_CLOSEBATCHLOGERRORS_SUCCESS) {
      gridCache.INVOICE_BATCH_LOG_ERROR = { rowData: null, filterModel: null, dateFilter: null, selectedIPDDLOption: WorkQueueConstant.DEFAULT };
      LoadLoader();
      GetInvoiceBatchLogErrorData();
    }
    else if (selectedTabOption === WorkQueueConstant.UNRATED_USAGE && arg === WorkQueueConstant.CHANGE_INVOICE_CYCLE_SUCCESS) {
      gridCache.UNRATED_USAGE = { rowData: null, filterModel: null, dateFilter: null, selectedIPDDLOption: WorkQueueConstant.DEFAULT };
      LoadLoader();
      GetUnrateData()
    }
    else if (selectedTabOption === WorkQueueConstant.DUPLICATE_USAGE) {
      gridCache.DUPLICATE_USAGE = { rowData: null, filterModel: null, dateFilter: null, selectedIPDDLOption: WorkQueueConstant.DEFAULT };
      LoadLoader();
      GetDuplicateMonthlyUsage()
    }
    else if (selectedTabOption === WorkQueueConstant.UNBILLED_35_DAYS) {
      gridCache.UNBILLED_35_DAYS = { rowData: null, filterModel: null, dateFilter: null, selectedIPDDLOption: WorkQueueConstant.DEFAULT };
      LoadLoader();
      GetUnbilledUsage()
    }
    else if (selectedTabOption === WorkQueueConstant.PENDING_FIRST_BILL) {
      gridCache.PENDING_FIRST_BILL = { rowData: null, filterModel: null, dateFilter: null, selectedIPDDLOption: WorkQueueConstant.DEFAULT };
      LoadLoader();
      GetPendingFirstBill();
    }
    setShowAlert(true);
    setTimeout(() => {
      setShowAlert(false);
    }, 10000);
  }

  const HandleTabClickInitialization = (tab) => {
    setDisabledIPFilter(true);

    // Empty Search header value on tab change
    const searchElement = document.querySelector(".txtSearch") as HTMLElement;
    if (searchElement && searchElement.childNodes[1] !== undefined) {
      const clearSearchElment = searchElement.childNodes[1] as HTMLElement;
      clearSearchElment.click();
    }

    // Save current tab's filter state, filtered rows AND date filter before switching
    const currentTab = selectedTabOption;
    if (gridCache[currentTab] && agRef.current && agRef.current.api) {
      gridCache[currentTab].filterModel = agRef.current.api.getFilterModel();
      gridCache[currentTab].dateFilter = selectedDateFilterDate;
      gridCache[currentTab].selectedIPDDLOption = selectedIPDDLOption;
      
      // Save to sessionStorage as well
      FilterPersistence.save('billing', currentTab, {
        dateFilter: selectedDateFilterDate ? dayjs(selectedDateFilterDate).format('YYYY-MM-DD') : null,
        selectedIPDDLOption: selectedIPDDLOption
      });
      
      const allRows: any[] = [];
      agRef.current.api.forEachNodeAfterFilter(node => {
        allRows.push(node.data);
      });
      gridCache[currentTab].rowData = allRows;
    }
    // Instantly restore date filter and dropdown for new tab
    const newTabCache = gridCache[tab];
    
    // Get the tab's date from sessionStorage first, then URL parameter, then cache
    const tabToParamMap = {
      [WorkQueueConstant.UNRATED_USAGE]: 'unrated',
      [WorkQueueConstant.INVOICE_BATCH_LOG_ERROR]: 'invoice',
      [WorkQueueConstant.UNBILLED_35_DAYS]: 'unbilled'
    };
    const paramName = tabToParamMap[tab];
    
    // Try sessionStorage first
    const savedFilters = FilterPersistence.load('billing', tab);
    let restoredDate: dayjs.Dayjs | null = null;
    
    if (savedFilters?.dateFilter) {
      restoredDate = dayjs(savedFilters.dateFilter);
    } else if (paramName) {
      restoredDate = parseDateFromUrl(paramName);
    } else {
      restoredDate = newTabCache?.dateFilter || null;
    }
    
    // Set flag to prevent API call when restoring date
    setIsRestoringDate(true);
    setSelectedDateFilterDate(restoredDate);
    setTimeout(() => setIsRestoringDate(false), 100);
    
    setSelectedIPDDLOption(savedFilters?.selectedIPDDLOption || newTabCache?.selectedIPDDLOption || WorkQueueConstant.DEFAULT);
 
    // Hide Variance block 
    const varianceBlock = document.getElementById('varianceBlock');
    if (varianceBlock) {
      varianceBlock.style.display = 'none';
      setVariance("");
    }
    // Invoice Preview DDL Option hide
    setShowDropDown(false);
  }

  const HandleTabClick = (tab) => {
    HandleTabClickInitialization(tab);
    
    // Preserve existing date parameter when changing tabs
    const newSearchParams = new URLSearchParams(searchParams);
    newSearchParams.set('tab', tab);
    setSearchParams(newSearchParams);

    if (tab === WorkQueueConstant.UNRATED_USAGE) {
      setShowDatefilter(true);
      setAgRef(unratedUsageAgRef);
      setSelectedTabOption(WorkQueueConstant.UNRATED_USAGE);
    }
    else if (tab === WorkQueueConstant.INVOICE_BATCH_LOG_ERROR) {
      setShowDatefilter(true);
      setAgRef(invoiceBatchLogErrorAgRef);
      setSelectedTabOption(WorkQueueConstant.INVOICE_BATCH_LOG_ERROR);
    }
    else if (tab === WorkQueueConstant.DUPLICATE_USAGE) {
      setShowDatefilter(false);
      setAgRef(duplicateUsageAgRef);
      setSelectedTabOption(WorkQueueConstant.DUPLICATE_USAGE);
    }
    else if (tab === WorkQueueConstant.UNBILLED_35_DAYS) {
      setShowDatefilter(true);
      setAgRef(unbilledUsageAgRef);
      setSelectedTabOption(WorkQueueConstant.UNBILLED_35_DAYS);
    }
    else if (tab === WorkQueueConstant.PENDING_FIRST_BILL) {
      setShowDatefilter(false);
      setAgRef(pendingFirstBillAgRef);
      setSelectedTabOption(WorkQueueConstant.PENDING_FIRST_BILL);
    }
  };
  const billingTabitems = [{
    label: WorkQueueConstant.UNRATED_USAGE,
    key: WorkQueueConstant.UNRATED_USAGE,
    children: <GridView rowData={unratedUsageRowData} colDef={unratedUsageColDefs} selectedGridData={GetSelectedGridData} agref={GetUnratedUsageAgref} />,
  },
  {
    label: WorkQueueConstant.DUPLICATE_USAGE,
    key: WorkQueueConstant.DUPLICATE_USAGE,
    children: <GridView rowData={duplicateUsageRowData} colDef={duplicateUsageColDefs} selectedGridData={GetSelectedGridData} agref={GetDuplicateMonthlyUsageAgref} />,
  },
  {
    label: WorkQueueConstant.UNBILLED_35_DAYS,
    key: WorkQueueConstant.UNBILLED_35_DAYS,
    children: <GridView rowData={unbilledUsageRowData} colDef={unbilledUsageColDefs} selectedGridData={GetSelectedGridData} agref={GetUnbilledUsageAgref} />,
  },
  {
    label: WorkQueueConstant.INVOICE_BATCH_LOG_ERROR,
    key: WorkQueueConstant.INVOICE_BATCH_LOG_ERROR,
    children: <GridView rowData={invoiceBatchLogErrorRowData} colDef={invoiceBatchLogErrorColDefs} selectedGridData={GetSelectedGridData} agref={GetInvoiceBatchLogErrorAgref} />,
  },
  {
    label: WorkQueueConstant.PENDING_FIRST_BILL,
    key: WorkQueueConstant.PENDING_FIRST_BILL,
    children: <GridView rowData={pendingFirstBillRowData} colDef={pendingFirstBillColDefs} selectedGridData={GetSelectedGridData} agref={GetPendingFirstBillUsageAgref} />,
  }
  ];

 useEffect(() => {
  const urlTab = searchParams.get('tab') || WorkQueueConstant.UNRATED_USAGE;
  
  // Clean up old dateFilter parameter if it exists
  const newSearchParams = new URLSearchParams(searchParams);
  if (newSearchParams.has('dateFilter')) {
    newSearchParams.delete('dateFilter');
    setSearchParams(newSearchParams);
  }
  
  setEnableB2BUser(true);
  setDisabledRecacheAction(false);
  setDisableActionButton(true);
  setSelectedTabOption(urlTab);
  setEnableSearchGrid(true);
  setEnableActionComponent(true);
  
  // Initialize each tab's date filter from sessionStorage or URL parameters
  const tabToParamMap = {
    [WorkQueueConstant.UNRATED_USAGE]: 'unrated',
    [WorkQueueConstant.INVOICE_BATCH_LOG_ERROR]: 'invoice',
    [WorkQueueConstant.UNBILLED_35_DAYS]: 'unbilled'
  };
  
  Object.entries(tabToParamMap).forEach(([tabKey, paramName]) => {
    // Try sessionStorage first, then fall back to URL
    const savedFilters = FilterPersistence.load('billing', tabKey);
    let dateValue: dayjs.Dayjs | null = null;
    
    if (savedFilters?.dateFilter) {
      dateValue = dayjs(savedFilters.dateFilter);
    } else {
      dateValue = parseDateFromUrl(paramName);
    }
    
    if (dateValue && gridCache[tabKey]) {
      gridCache[tabKey].dateFilter = dateValue;
      // If we got it from sessionStorage but not in URL, update URL
      if (savedFilters?.dateFilter && !searchParams.get(`${paramName}_date`)) {
        updateDateInUrl(paramName, dateValue);
      }
    }
  });
  
  // Set the current tab's date filter
  const currentTabParam = tabToParamMap[urlTab];
  if (currentTabParam) {
    const savedFilters = FilterPersistence.load('billing', urlTab);
    let dateValue: dayjs.Dayjs | null = null;
    
    if (savedFilters?.dateFilter) {
      dateValue = dayjs(savedFilters.dateFilter);
    } else {
      dateValue = parseDateFromUrl(currentTabParam);
    }
    
    if (dateValue) {
      setSelectedDateFilterDate(dateValue);
    }
  }
  
  // Set showDatefilter based on the current tab (including on page refresh)
  if (urlTab === WorkQueueConstant.UNRATED_USAGE || urlTab === WorkQueueConstant.INVOICE_BATCH_LOG_ERROR || urlTab === WorkQueueConstant.UNBILLED_35_DAYS) {
    setShowDatefilter(true);
  } else {
    setShowDatefilter(false);
  }
}, []);

useEffect(() => {
  // Handle tab switching and restore cached data with filters
  const tabConfig = {
    [WorkQueueConstant.UNRATED_USAGE]: {
      cache: gridCache.UNRATED_USAGE,
      setColDefs: setUnratedUsageColDefs,
      setRowData: setUnratedUsageRowData,
      fetchData: GetUnrateData,
      ref: unratedUsageAgRef
    },
    [WorkQueueConstant.INVOICE_BATCH_LOG_ERROR]: {
      cache: gridCache.INVOICE_BATCH_LOG_ERROR,
      setColDefs: setInvoiceBatchLogErrorColDefs,
      setRowData: setInvoiceBatchLogErrorRowData,
      fetchData: GetInvoiceBatchLogErrorData,
      ref: invoiceBatchLogErrorAgRef
    },
    [WorkQueueConstant.DUPLICATE_USAGE]: {
      cache: gridCache.DUPLICATE_USAGE,
      setColDefs: setDuplicateUsageColDefs,
      setRowData: setDuplicateUsageRowData,
      fetchData: GetDuplicateMonthlyUsage,
      ref: duplicateUsageAgRef
    },
    [WorkQueueConstant.UNBILLED_35_DAYS]: {
      cache: gridCache.UNBILLED_35_DAYS,
      setColDefs: setUnbilledUsageColDefs,
      setRowData: setUnbilledUsageRowData,
      fetchData: GetUnbilledUsage,
      ref: unbilledUsageAgRef
    },
    [WorkQueueConstant.PENDING_FIRST_BILL]: {
      cache: gridCache.PENDING_FIRST_BILL,
      setColDefs: setPendingFirstBillColDefs,
      setRowData: setPendingFirstBillRowData,
      fetchData: GetPendingFirstBill,
      ref: pendingFirstBillAgRef
    }
  };

  const config = tabConfig[selectedTabOption];
  if (!config) return;

  if (!config.cache.rowData) {
    setTimeout(() => config.fetchData(), 0);
  } else {
    // Immediately set cached data for instant tab switching
    const cachedData = config.cache.rowData;
    const colDefs = GetColDefValue(cachedData);
    const colParams = GetColParamValue(cachedData);
    
    // Set data synchronously for instant response
    config.setColDefs(colDefs);
    setColParam(colParams);
    config.setRowData(cachedData);
    // Restore date filter if it was set for this tab
    if (config.cache.dateFilter) {
      setTimeout(() => {
        if (showDatefilter) {
          // Set flag to prevent API call when restoring date
          setIsRestoringDate(true);
          setSelectedDateFilterDate(config.cache.dateFilter);
          // Update URL parameter with restored date for current tab
          const tabToParamMap = {
            [WorkQueueConstant.UNRATED_USAGE]: 'unrated',
            [WorkQueueConstant.INVOICE_BATCH_LOG_ERROR]: 'invoice',
            [WorkQueueConstant.UNBILLED_35_DAYS]: 'unbilled'
          };
          const paramName = tabToParamMap[selectedTabOption];
          if (paramName) {
            updateDateInUrl(paramName, config.cache.dateFilter);
          }
          setTimeout(() => setIsRestoringDate(false), 100);
        }
      }, 100);
    }

    // Restore filters asynchronously to avoid blocking UI
    if (config.cache.filterModel && config.ref?.current?.api) {
      setTimeout(() => {
        if (config.ref?.current?.api) {
          config.ref.current.api.setFilterModel(config.cache.filterModel);
          config.ref.current.api.onFilterChanged();
        }
      }, 100);
    }
  }
}, [selectedTabOption]);

  return (
    <>
      <div className="row">
        <div className="row ">
          <div className="col-md-12 billingalertdiv">
            {showAlert && <div className="col-md-6 billingalert">
              <Alert size={Sizes.Small} sentiment={Sentiments.Information} >
                {actionNotification}
              </Alert>
            </div>
            }
          </div>
        </div>
        <div className="row g-3">
          <div className="col-md-4 mt-0 g-4 billingfilterrow">
            {showDropDown && <div className="form-floating">
              <DropdownComponent DDLOptions={GetDDLOptions()} onSelect={HandleFilter} selectedOption={selectedIPDDLOption} disableDropDown={disabledIPFilter} />
              <label htmlFor="floatingSelect">{WorkQueueConstant.FILTERS}</label>
            </div>
            }
            {showDatefilter && <div className="col-md-6 mtp">
              <SingleDatePicker id="EQDateFilter" placeholder="Select Date" size={Sizes.Medium}
                onChange={HandleOnChangeDateFilter} value={selectedDateFilterDate} inputReadOnly
              />
            </div>}
          </div>
          <div className="col-md-4 mt-3">
            <div className="row variancerow">
              <div id="varianceBlock" className="col-md-12 variancehide">
                <div className="row g-1 mr-2">
                  <div className="col-md-6">
                    <TextInput type="text" id="txtVariance"
                      onChange={e => setVariance(e.target.value)}
                      value={variance}
                      placeholder="Enter the variance"
                      className="texFilter" />
                  </div>
                  <div className="col-md-6">
                    <Button sentiment={Sentiments.Primary}
                      type="button"
                      data-bs-toggle=""
                      onClick={FilterByVariance}
                      aria-expanded="false">
                      Filter
                    </Button>
                  </div>
                </div>
              </div>
            </div>

          </div>

          {enableSearchGrid && <div className="col-md-4">
            <SearchGridHeaderComponent excelparams={excelparams} gridRef={agRef} actionNotification={GetActionNotification} />
          </div>}
        </div>

        <div className="row g-3">
          {enableActionComponent && <div className="col-md-12 mb-3">
            <ActionComponent 
              selectedData={selectedIds} 
              gridRef={agRef} 
              excelparams={excelparams} 
              activeTab={selectedTabOption} 
              actionNotification={GetActionNotification} 
              recacheDisabled={disabledRecacheAction} 
              actionDisabled={disableActionButton} 
              onClick={handleRefresh}
              />
          </div>}
        </div>
        <Tabs 
          items={billingTabitems} 
          activeKey={searchParams.get('tab') || WorkQueueConstant.UNRATED_USAGE} 
          className="tabPanel" 
          emphasis={false} 
          onTabClick={HandleTabClick} 
          destroyInactiveTabPane={false}
        />
      </div>
    </>
  );
}

export default Billing;