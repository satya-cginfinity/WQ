import { useEffect, useRef, useState } from "react";
import { AgGridReact } from "ag-grid-react";
import { Label, useFileXhrUploader, FileUploader, OnError, OnProgress, Alert, Variants, Sizes, Modal, FileType, CalendarValueType, SingleDatePicker } from "@sede-enterprise/shell-ds-react-framework";
import { Sentiments } from "@sede-enterprise/shell-ds-react-framework";

import GridView from "../Components/GridView";
import { fetchInvoiceBatchLogErrors, fetchUnratedUsage } from "../API/mp2API";
import { GetColDefValueExceptionQueue, GetColParamValue, ConvertDateToString } from "../Utility/GridHelper";
import { isUserAuthenticated } from "../Utility/Auth";
import * as WorkQueueConstant from "../Utility/Constant";
import ActionComponent from "../Components/Action";
import SearchGridHeaderComponent from "../Components/SearchGridHeader";
import DropdownComponent from "../Components/Dropdown";


const ExceptionQueue = () => {

  const [rowDataBilling, setRowDataBilling] = useState([]);
  const [colDefs, setColcolumnDefs] = useState([]);
  const [colParam, setcolParam] = useState([]);
  const [agRef, setagRef] = useState(useRef<AgGridReact>(null));
  const [ETDDLOptions, setExpTypeDDL] = useState(getExpTypeDDL(WorkQueueConstant.BILLING));
  const [selectedETDDLOption, setSelectedETDDLOption] = useState('');
  const [toggleFileUploader, setFileuploaderToggle] = useState(false);
  const [showFileuploaderFlag, setShowfileuploaderFlag] = useState(false);
  const [selectedIds, setSelectedIds] = useState([]);
  const [showETDatefilter, setShowETDatefilter] = useState(true);
  const [selectedETDate, setSelectedETDate] = useState(null);

  const handleOnCloseUploader = () => setFileuploaderToggle(false);

  useEffect(() => {
    handleETDateSelect();
  }, [selectedETDate])


  const handleOnChangeETDateFilter = (selectedETDate) => {
    if (selectedETDate) {
      setSelectedETDate(selectedETDate);
    } else {
      setSelectedETDate(null)
    }
  }

  function handleETDateSelect() {
    console.log('handleETDateSelect' + selectedETDate);
    loadLoader();
    if (selectedETDDLOption === WorkQueueConstant.UNRATED_USAGE) {
      GetUnrateData();
    }
    else if (selectedETDDLOption === WorkQueueConstant.INVOICE_BATCH_LOG_ERROR) {
      GetInvoiceBatchLogErrorData();
    }
  }


  const toggleETDateFilter = (flag) => {
    setShowETDatefilter(flag);
  };

  const GetUnrateData = async () => {
    try {
      let clickedDate = ConvertDateToString(selectedETDate);
      console.log(clickedDate + "selectedETDate");
      const result = await fetchUnratedUsage(clickedDate);
      let resultMsg = JSON.parse(result.message);
      if (result && result.status === WorkQueueConstant.SUCCESS && resultMsg.length !== 'undefined' && resultMsg.length > 0) {        
        setcolParam(GetColParamValue(resultMsg))
        setColcolumnDefs(GetColDefValueExceptionQueue(resultMsg));
        setRowDataBilling(resultMsg);
      }
      else { 
        if(resultMsg.length === 0 )     
          console.log('Record is empty' + resultMsg);
        else
          console.log('Error Message : ' + resultMsg.error);
        setcolParam([]);
        setColcolumnDefs([]);
        setRowDataBilling([]);
      }
    }
    catch (ex) {
      console.log('Error Message.' + ex);
      setcolParam([]);
      setColcolumnDefs([]);
      setRowDataBilling([]);
    }
    setSelectedETDDLOption(WorkQueueConstant.UNRATED_USAGE);
  }

  useEffect(() => {
    GetUnrateData();
  }, []);

  const GetInvoiceBatchLogErrorData = async () => {
    try {
    let clickedDate = ConvertDateToString(selectedETDate);
    console.log(clickedDate + "selectedETDate");
    const result = await fetchInvoiceBatchLogErrors(clickedDate);
    let resultMsg = JSON.parse(result.message);
    if (result && result.status === WorkQueueConstant.SUCCESS && resultMsg.length !== 'undefined' && resultMsg.length > 0) {      
      setcolParam(GetColParamValue(resultMsg))
      setColcolumnDefs(GetColDefValueExceptionQueue(resultMsg));
      setRowDataBilling(resultMsg);
    }
    else {
      if(resultMsg.length === 0 )     
        console.log('Record is empty' + resultMsg);
      else
        console.log('Error Message : ' + resultMsg.error);
      setcolParam([]);
      setColcolumnDefs([]);
      setRowDataBilling([]);
    }
  }
  catch(ex){
    console.log('Error Message.' + ex);
      setcolParam([]);
      setColcolumnDefs([]);
      setRowDataBilling([]);
  }
    setSelectedETDDLOption(WorkQueueConstant.INVOICE_BATCH_LOG_ERROR);
  }

  const excelparams = {
    columnKeys: colParam
  };

  const loadLoader = () => {
    if (agRef.current !== undefined && agRef.current !== null) {
      agRef.current!.api.setFilterModel(null);
      agRef.current!.api.showLoadingOverlay();
    }
  };


  const getAgref = (arg) => {
    setagRef(arg);
  };

  const handleEQTabclick = (tab) => {
    const ETOptions = getExpTypeDDL(tab);
    setExpTypeDDL(ETOptions);
    setSelectedETDDLOption('');

    if (tab === WorkQueueConstant.BILLING) {
      loadLoader();
      setSelectedETDate(null);
      setSelectedETDDLOption(WorkQueueConstant.BILLING);
      GetUnrateData();
      toggleETDateFilter(true);
      setShowfileuploaderFlag(false);
    }
    else {
      toggleETDateFilter(false);
    }
  };

  const toggleShowfileUploader = () => {
    setShowfileuploaderFlag(!showFileuploaderFlag);
  };
  const ShowfileUploaderAlert = () => {
    setShowfileuploaderFlag(false);
  };


  const handleOnClose = () => {
    var fileUploadElement = document.getElementById("fileuploader");
    var fileUploadHTMLElement: HTMLElement = fileUploadElement!.children[0].children[3] as HTMLElement;
    if (fileUploadHTMLElement.textContent !== WorkQueueConstant.EXCEPTION_TEXT_CONTENT)
      fileUploadHTMLElement.click();
    setFileuploaderToggle(false);
    const newOptions = getExpTypeDDL(WorkQueueConstant.EDI_TRANSACTION);
    setExpTypeDDL(newOptions);
    setSelectedETDDLOption(WorkQueueConstant.DEFAULT);

  }
  function getExpTypeDDL(category) {
    switch (category) {
      case WorkQueueConstant.BILLING:
        return [
          { value: WorkQueueConstant.UNRATED_USAGE, label: WorkQueueConstant.UNRATED_USAGE },
          { value: WorkQueueConstant.INVOICE_BATCH_LOG_ERROR, label: WorkQueueConstant.INVOICE_BATCH_LOG_ERROR },
        ];
      case WorkQueueConstant.EDI_TRANSACTION:
        return [
          { value: WorkQueueConstant.DEFAULT, label: WorkQueueConstant.DEFAULT, default: 1 },
          { value: WorkQueueConstant.EDI_RESUBMITTABLE, label: WorkQueueConstant.EDI_RESUBMITTABLE },

        ];
      default:
        return [];
    }
  }

  
  const handleETDDLOnselect = (value) => {
    setSelectedETDDLOption(value);
    if (value === WorkQueueConstant.EDI_RESUBMITTABLE) {
      setSelectedETDDLOption(value);
      setFileuploaderToggle(true);
    } else {
      setSelectedETDDLOption(value);
      handleTabChange(value);
      setSelectedETDate(null);
    }

  };
  const handleTabChange = (dropdownValue) => {
    loadLoader();
    let eqDateFilter: HTMLInputElement = document.getElementById('EQDateFilter') as HTMLInputElement;
    if (eqDateFilter!.value === '') {
      if (dropdownValue === WorkQueueConstant.UNRATED_USAGE) {
        GetUnrateData();
      }
      else if (dropdownValue === WorkQueueConstant.INVOICE_BATCH_LOG_ERROR) {
        GetInvoiceBatchLogErrorData();
      }
    }
    else {
      setSelectedETDate(null);
    }
  }
  const url = WorkQueueConstant.EXCEPTION_UPLOAD_URL;
  const {
    handleOnUpload,
    handleOnDrop,
    handleOnRemoveFile
  } = useFileXhrUploader({
    url
  });

  const dropFilesAction = (files: File[], onProgress: OnProgress, onError: OnError) => {
    handleOnDrop(files, onProgress, onError);
    handleOnUpload();
  };

  setTimeout(ShowfileUploaderAlert, 10000);

  const props = {
    dropFilesAction,
    removeFileAction: handleOnRemoveFile
  };
  //Unless file has been selected , submit button should not do anything
  const clearUploader = () => {
    var fileUploadElement = document.getElementById("fileuploader");
    var fileUploadHTMLElement: HTMLElement = fileUploadElement!.children[0].children[3] as HTMLElement;
    if (fileUploadHTMLElement.textContent !== WorkQueueConstant.EXCEPTION_TEXT_CONTENT) {
      fileUploadHTMLElement.click();
      toggleShowfileUploader();
      handleOnCloseUploader();
      const newOptions = getExpTypeDDL(WorkQueueConstant.EDI_TRANSACTION);
      setExpTypeDDL(newOptions);
      setSelectedETDDLOption('');
    }
  };

  const getselectedGridData = (arg) => {
    setSelectedIds(arg);
  };

  return (
    <>
      <div className="row">
        <div className="row titleBody">
          <Label className="eqp">{WorkQueueConstant.EXCEPTION_TITLE}</Label>
        </div>
        <div className="row g-3 mrn mgt">
          <div className="col-md-4 mt-0">
            <div className="form-floating">
              <DropdownComponent DDLOptions={ETDDLOptions} selectedOption={selectedETDDLOption} onSelect={handleETDDLOnselect} />
              <br></br>
              <label htmlFor="floatingSelect">{WorkQueueConstant.EXCEPTION_TYPE}</label>
            </div>
          </div>
         
          <div className="col-md-4">
          {showETDatefilter && <div className="row col-md-6">
            <SingleDatePicker id="EQDateFilter" placeholder="Select Date" size={Sizes.Medium}
              onChange={handleOnChangeETDateFilter} value={selectedETDate} inputReadOnly
            />
          </div>}
            {showFileuploaderFlag && <div className="row  mrtn26">
              <div>
                <Alert  onClick={toggleShowfileUploader} size={Sizes.Large} sentiment={Sentiments.Positive} >
                
                    {WorkQueueConstant.FILE_UPLOAD_SUCCESS}
                </Alert>
              </div>
            </div>
            }
          </div>
          <div className="col-md-4 mt-3">
            <SearchGridHeaderComponent excelparams={excelparams} gridRef={agRef}></SearchGridHeaderComponent>
          </div>
        </div>
        <div className="row mrtn14">
          <div className="col-md-12 mrn mb-1 g-3">
            <ActionComponent selectedData={selectedIds} gridRef={agRef} excelparams={excelparams} />
          </div>
        </div>

        <nav>
          <div className="nav nav-tabs tabstyle" id="nav-tab" role="tablist">
            <button
              className="nav-link active"
              id="nav-billing-tab"
              data-bs-toggle="tab"
              data-bs-target="#nav-billing"
              type="button"
              role="tab"
              aria-controls="nav-billing"
              aria-selected="true"
              onClick={() => handleEQTabclick(WorkQueueConstant.BILLING)}
            >
              Billing
            </button>
            <button
              className="nav-link"
              id="nav-editransaction-tab"
              data-bs-toggle="tab"
              data-bs-target="#nav-editransaction"
              type="button"
              role="tab"
              aria-controls="nav-editransaction"
              aria-selected="false"
              onClick={() => handleEQTabclick(WorkQueueConstant.EDI_TRANSACTION)}
            >
              EDI Transaction
            </button>
          </div>
        </nav>

        <div>
          <Modal
            open={toggleFileUploader} title="Upload File"
            onClose={() => {
              handleOnClose();
            }}
            actions={[
              {
                label: 'Cancel',
                action: () => {
                  handleOnClose();
                },
                props: {
                  variant: Variants.Transparent,
                  className : "cancelEDIpopUp"
                },
              }, {
                label: 'Submit',
                action: () => {
                  clearUploader();
                },
                props: {
                  variant: Variants.Filled,
                  className: "Modal_Submit"
                }
              }
            ]}
          >
            <FileUploader {...props} id="fileuploader" fileType={FileType.Single} acceptedFileTypes={['.xlsx']} />

          </Modal>
        </div>

        <div className="tab-content navExcept" id="nav-tabContent">
          <div
            className="tab-pane fade show active"
            id="nav-billing"
            role="tabpanel"
            aria-labelledby="nav-billing-tab"
          >
            <div><GridView rowData={rowDataBilling} colDef={colDefs} excelparams={excelparams} agref={getAgref} selectedGridData={getselectedGridData} /></div>

          </div>
          <div
            className="tab-pane fade"
            id="nav-editransaction"
            role="tabpanel"
            aria-labelledby="nav-editransaction-tab"
          >
            <GridView rowData={[]} colDef={[]} excelparams={excelparams} />
          </div>
        </div>
      </div>
    </>
  );
}

export default ExceptionQueue;
