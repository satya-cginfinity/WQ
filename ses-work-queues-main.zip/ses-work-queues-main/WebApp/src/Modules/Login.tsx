import { Avatar, Sizes } from "@sede-enterprise/shell-ds-react-framework";
import "../App.css";

function Login() {

  return (
    <>
      <div className="App">
        <header className="App-header">          
          {/* Need to update once login page UI decided */}
          <Avatar label="Click this icon above to login" size={Sizes.Large} className="loginavtar" ></Avatar>
        </header>
      </div>
    </>
  );
}

export default Login