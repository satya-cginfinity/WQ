import axios from "axios";
import * as WorkQueueConstant from "../Utility/Constant";
import { ApiHeaders } from "./APIHelper";

//#region Fusion API's

export const fetchBillingPreview = async (enableReache = false) => {
  let response;
  try {
    let url = WorkQueueConstant.REACT_APP_GETBILLINGPREVIEW as string + "?recache=" + enableReache;

    const result = await axios.get(url, {
        headers:await ApiHeaders()
    })
    response = result.data;
  } catch (error) {
    console.error("Error fetching data:", error);
  }
  return response;
};

export const fetchUnbilled35Days = async (checkDate) => {
  let response;
  try {
    let url = WorkQueueConstant.REACT_APP_GETUNBILLED35DAYS + checkDate;
    const result = await axios.get(url as string,{
        headers:await ApiHeaders()
    })
    response = result.data;
  } catch (error) {
    console.error("Error fetching data:", error);
  }
  return response;
};

export const SetPreviewUsageHold = async (invoiceID) => {
  let response;
  try {
    const result = await axios.post(WorkQueueConstant.REACT_APP_PREVIEWUSAGEHOLD as string, invoiceID,{
        headers:await ApiHeaders()
    });
    response = result.data;
  }
  catch (error) {
    console.error('Error setting data:', error);
  }
  return response;
};

export const MonthlyUsage = async (monthlyUsageIDs, expirationDate) => {
  let response;
  let details = {
    USAGE_IDS: monthlyUsageIDs,
    INVOICE_HOLD_EXPIRATION_DATE: expirationDate
  };

  try {
    const result = await axios.put(WorkQueueConstant.REACT_APP_MONTHLYUSAGE, details, {
      headers:await ApiHeaders()
    });
    response = result.data;
  }
  catch (error) {
    console.error('Error setting data:', error);
  }
  return response;
};

export const FetchInvoiceHolidays = async () => {
  let response;
  try {
    const result = await axios.get(WorkQueueConstant.REACT_APP_INVOICEHOLIDAYS as string,{
      headers:await ApiHeaders()
    })
    response = result.data;
  } catch (error) {
    console.error("Error fetching data:", error);
  }
  return response;
};

export const CloseMultipleBatchLogErrors = async (details) => {
  let response;
  try {
    const result = await axios.post(WorkQueueConstant.REACT_APP_CLOSEMULTIPLEBATCHLOGERRORS as string, details,{
      headers:await ApiHeaders()
  })
    response = result.data;
  }
  catch (error) {
    console.error('Error setting data:', error);
  }
  return response;
};

export const ChangeInvoiceCycle = async (details) => {
  let response;
  try {
    const result = await axios.post(WorkQueueConstant.REACT_APP_CHANGEINVOICECYCLE as string, details,{
        headers:await ApiHeaders()
    })
    response = result.data;
  }
  catch (error) {
    console.error('Error setting data:', error);
  }
  return response;
};

export const ChangeLDCAccountStatus = async (details:any) => {
  let response;
  try {
    const result = await axios.post(WorkQueueConstant.REACT_APP_CHANGELDCACCOUNTSTATUS as string,details,{
      headers:await ApiHeaders()
    })
    response = result.data;
  }
  catch (error) {
    console.error('Error setting data:', error);
  }
  return response;
};

//#endregion

