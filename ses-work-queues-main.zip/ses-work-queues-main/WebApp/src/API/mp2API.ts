import axios from "axios";
import * as WorkQueueConstant from "../Utility/Constant";
import { GetApiOptions, ApiHeaders } from "./APIHelper";

//#region Fusion API's

export const fetchUnratedUsage = async (creationDate) => {
  let response;
  try {
    let url = WorkQueueConstant.REACT_APP_GETUNRATEDUSAGE + creationDate;
    
    const result = await axios.get(url as string, {
      headers:await ApiHeaders()
    })
    response = result.data;
  } catch (error) {
    console.error("Error fetching data:", error);
  }
  return response;
};

export const fetchInvoiceBatchLogErrors = async (creationdate) => {
  let response;
  try {
    let url = WorkQueueConstant.REACT_APP_GETINVOICEBATCHLOGERROR + creationdate;
    const result = await axios.get(url as string,{
      headers:await ApiHeaders()
    })
    response = result.data
  } catch (error) {
    console.error("Error fetching data:", error);
  }
  return response;
};

export const fetchPrebilled = async (checkDate?) => {
  let response;
  try {
    let url = WorkQueueConstant.REACT_APP_GETPREBILLED;
    
    const result = await axios.get(url as string, {
      headers:await ApiHeaders()
    })
    response = result.data;
  } catch (error) {
    console.error("Error fetching data:", error);
  }
  return response;
};

export const fetchContractExpiringAccounts = async (minDate?: string, maxDate?: string) => {
  let response;
  try {
    let url = WorkQueueConstant.REACT_APP_GETCONTRACTEXPIRINGACCOUNTS;

    const params= new URLSearchParams();
    params.append('minDate', minDate ||'')
    params.append('maxDate', maxDate ||'')
    url+= `?${params.toString()}`

    const result = await axios.get(url, {
      headers: await ApiHeaders()
    });
    response = result.data;
  } catch (error) {
    console.error("Error fetching data:", error);
  }
  return response;
}

  export const fetchDuplicateMonthlyUsage = async () => {
    let response;
    try {
      let url = WorkQueueConstant.REACT_APP_GETDUPLICATEMONTHLYUSAGE;

      const result = await axios.get(url, {
        headers: await ApiHeaders()
      });
      response = result.data;
    } catch (error) {
      console.error("Error fetching data:", error);
    }
    return response;
  }

  export const fetchUnbilledUsage = async (checkDate) => {
    let response;
    try {
      let url = WorkQueueConstant.REACT_APP_GETUNBILLED35DAYS + checkDate;

      const result = await axios.get(url, {
        headers: await ApiHeaders()
      });
      response = result.data;
    } catch (error) {
      console.error("Error fetching data:", error);
    }
    return response;
  };

   export const fetchPendingFirstBill = async () => {
    let response;
    try {
      let url = WorkQueueConstant.REACT_APP_GETPENDINGFIRSTBILL;

      const result = await axios.get(url, {
        headers: await ApiHeaders()
      });
      response = result.data;
    } catch (error) {
      console.error("Error fetching data:", error);
    }
    return response;
  }
//#endregion
//#region Refresh Token API

export const regenerateToken = async (refreshToken) => {
  let response;
  try {
    let url = WorkQueueConstant.REGENERATE_TOKEN + refreshToken;
    const result = await axios.get(url as string,{
      headers: GetApiOptions()
    } )
    response = result.data
  } catch (error) {
    console.error("Error fetching data:", error);
  }
  return response;
};
//#endregion