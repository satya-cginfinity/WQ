import { getAccessToken } from "../Utility/Auth";

//#region API's Helpers
export const GetApiOptions = () => {  
     let headers= {
        "Content-Type": "Application/json",
        "Access-Control-Allow-Origin": "*"        
      }
  return headers;
};
//#endregion

//#region Fusion API's Helpers
export const ApiHeaders = async () => {   
   const headers= {        
      'Accept': 'application/json' ,       
      'Content-Type': 'Application/json',
      'Access-Control-Allow-Origin': '*',
      "access-token": await getAccessToken()
    }
return headers;
};
//#endregion