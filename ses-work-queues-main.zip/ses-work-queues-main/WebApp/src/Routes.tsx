import { createBrowserRouter, RouterProvider } from "react-router-dom";

import SideNavigation from "./Components/SideNavigation";
import Home from "./Modules/Home";
import Login from "./Modules/Login";
import Billing from "./Modules/Billing";
import NotFound from "./Modules/NotFound";
import PreBillValidation from "./Modules/PreBillValidation"

function Routes() {
  const router = createBrowserRouter([
    {
      path: "/home",
      element: <Home />,
    },
    {
      path: "/",
      element: <Login />,
    },
    {
      path: "*",
      element: <NotFound />,
    },
    {
      path: "/",
      element: <SideNavigation />,
      errorElement: <Login />,
      children: [
        {
          path: "billing",
          element: <Billing />,
        },
        {
          path:"prebillvalidation",
          element:<PreBillValidation/>
        }
        // {
        //   path: "edi",
        //   element: <Maintenance />,
        // },
        // {
        //   path: "ar",
        //   element: <Maintenance />,
        // },
        // {
        //   path: "datavalidation",
        //   element: <Maintenance />,
        // }        
      ],
    }
  ]);

  return <RouterProvider router={router}></RouterProvider>;
}

export default Routes;
