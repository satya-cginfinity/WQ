import { CalendarValueType } from "@sede-enterprise/shell-ds-react-framework/build/esm/components/DatePicker/components/Calendar/Calendar.types";
import * as WorkQueueConstant from "../Utility/Constant";

export const GetColDefValueExceptionQueue = (data) => {
  const keys = Object.keys(data[0]);
  const colDef: any = [];
  colDef.length = 0;
  colDef.push({
    headerCheckboxSelection: true,
    checkboxSelection: true,
    width: 20,
    headerCheckboxSelectionFilteredOnly: true
  });
  keys.forEach(key => colDef.push({ field: key, filter: true, floatingFilter: true, suppressFloatingFilterButton: true }));
  return colDef;
};

export const GetColDefValue = (data) => {
  const keys = Object.keys(data[0]);
  const colDef: any = [];
  colDef.length = 0;
  colDef.push({
    headerCheckboxSelection: true,
    checkboxSelection: true,
    width: 20,
    headerCheckboxSelectionFilteredOnly: true
  });
  keys.forEach(key => colDef.push({ field: key, filter: true, floatingFilter: true }));
  return colDef;
};

export const GetColDefValueBillingInvoicePreview = (data) => {
  const keys = Object.keys(data[0]);
  const colDef: any = [];
  colDef.length = 0;
  colDef.push({
    headerCheckboxSelection: true,
    checkboxSelection: true,
    width: 20,
    headerCheckboxSelectionFilteredOnly: true
  });
  keys.forEach(key => colDef.push({
    field: key,
    filter: 'agMultiColumnFilter',
    filterParams: {
      filters: [
        {
          filter: "agSetColumnFilter",
        },
        {
          filter: WorkQueueConstant.Varchar_Columns.includes(key) ? "agTextColumnFilter" : "agNumberColumnFilter",
        }
      ],
    },
    floatingFilter: true,    
  }));
  return colDef;
};

export const GetColParamValue = (data) => {
  const keys = Object.keys(data[0]);
  const colPar: any = [];
  colPar.length = 0;
  keys.forEach(key => colPar.push(key));
  return colPar;
};

export const ConvertDateToString = (value: CalendarValueType) => {
  if (!value) return "";
  var year = `${value?.year()}`;
  var month = `${value?.month() + 1}`;
  if (Number(month) < 10) {
    month = '0' + month;
  };
  var day = `${value?.date()}`;
  if (Number(day) < 10) {
    day = '0' + day;
  };
  return year + month + day;
};

export const ConvertDateToStringWithHyphen = (value: CalendarValueType) => {
  if (!value) return "";
  var year = `${value?.year()}`;
  var month = `${value?.month() + 1}`;
  if (Number(month) < 10) {
    month = '0' + month;
  };
  var day = `${value?.date()}`;
  if (Number(day) < 10) {
    day = '0' + day;
  };
  return year +'-'+ month +'-'+day;
};

export const ConvertDateTimeToString = (value: Date) => {
  if (!value) return "";
  var date = `${value?.getDate()}`;
  if(Number(date)<10){
    date = '0'+date;
  }
  var month = `${value?.getMonth() + 1}`;
  if(Number(month)<10){
    month = '0' + month;
  }
  var year = `${value?.getFullYear()}`;
  return year + month + date;
};

