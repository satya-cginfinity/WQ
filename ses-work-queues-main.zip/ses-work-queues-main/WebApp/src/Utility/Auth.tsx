import { regenerateToken } from "../API/mp2API";


export  const isUserAuthenticated = () => {
    if(localStorage.getItem("access-token") !== null && localStorage.getItem("access-token") !== undefined)
        return true;
    else
        window.location.assign(import.meta.env.VITE_BASEURL as string);
};

export const getAccessToken = async () => {
    var redirectToLogin = true;
    var accessToken = localStorage.getItem("access-token");
    var refreshToken = localStorage.getItem("refresh-token"); 
    var tokenExpirationTimestamp = Number(localStorage.getItem("token-expiration")?.toString());
    var currentTimestamp = ((new Date().getTime()) / 1000);

    if(accessToken !== null){
        var isTokenExpired = tokenExpirationTimestamp < currentTimestamp;

        if(isTokenExpired){
            if(refreshToken !== null){
                //calling refresh token api, get new access token and return it.
                //if refresh token is also expired then will redirect to login
                const data = await regenerateToken(refreshToken);

                if(!data.hasOwnProperty('error')){
                    localStorage.setItem('access-token',data.token);
                    localStorage.setItem('token-expiration',data.exp);
                    localStorage.setItem('refresh-token',data.refresh_token);
                    return data.token;
                  }
            }
        }
        else
            return accessToken.toString();
    }
    
    if(redirectToLogin){
        localStorage.setItem("LoggedIn", "false");
        window.location.assign(import.meta.env.VITE_BASEURL as string);
    }
};
