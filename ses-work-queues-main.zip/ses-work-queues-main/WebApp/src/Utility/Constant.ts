// EDI Transaction DropDown Options
export const DEFAULT = "-----Please Select-----";
export const EDI_RESUBMITTABLE = "EDI Re-Submittable";

// Exception Queue Tab Options
//export const BILLING = "Billing";
export const EDI_TRANSACTION = "EDI Transaction";

// Side Navigation Items
export const BILLING = "Billing";
export const EDI = "EDI";
export const AR = "AR";
export const DATA_VALIDATION = "Data Validation";
export const COLLAPSE = "Collapse";
export const PREBILL = "Pre-Bill Validations";
export const CONTRACT_EXPIRATION_ACCOUNTS = "Contract Expiration Accounts";



// Billing Page Tab Options
export const INVOICE_PREVIEW = "Invoice Preview";
export const UNRATED_USAGE = "Unrated Usage";
export const UNBILLED_35_DAYS = "Unbilled 35 Days";
export const INVOICE_BATCH_LOG_ERROR = "Invoice Batch Log Errors";
export const MATCHED_UNBILLED_810_867 = "810 867 Matched Unbilled";
export const DUPLICATE_USAGE = "Duplicate Usage"
export const PENDING_FIRST_BILL = "Pending First Bill"


// Billing Preview External Filter Options
export const BUNDLED_RATES_TDSP = "Bundled rates with TDSP charges";
export const BB_INVOICE_BB_COUNT = "BB invoices with more than 1 on BB count";
export const INVOICE_DPP =
  "Invoices with DPP with more than 1 DPP or DPP count = 0 ";
export const INVOICE_RATE = "Invoices where rate column = 0 or null";
export const INVOICE_VARIANCE_KWH = "Invoices with a variance (KWH) > x%";
export const INVOICE_VARIANCE_$$ = "Invoices with a variance ($$) > x%";
export const FIRST_TIME_BILLERS = "First time billers";
//Opposite of above
export const REVERSE_BUNDLED_RATES_TDSP = "Unbundled Rate and TDSP Charges";
export const REVERSE_BB_INVOICE_BB_COUNT = "BB Invoice with 1 BB count";
export const REVERSE_INVOICE_DPP = "DPP Invoice with 1 DPP count";
export const REVERSE_INVOICE_RATE = "Rate > 0 or not null";


// Billing Preview Internal Filters selection
export const PREVIEW_TDSP = "PREVIEW_TDSP";
export const BB_COUNT = "BB_COUNT";
export const RATE = "RATE";
export const PREVIEW_PRODUCT_TYPE = "PREVIEW_PRODUCT_TYPE";
export const DPP_FLAG = "DPP_FLAG";
export const NO_PA_INSTALL = "NO_PA_INSTALL";
export const DOL_PCT_VAR_DIFF = "DOL_PCT_VAR_DIFF";
export const KWH_PCT_VAR_DIFF = "KWH_PCT_VAR_DIFF";
export const RESI_FIXED_CHANGE = "RESI FIXED CHANGE PASS THROUGH";
export const RESI_FLAT_FEE = "RESI FLAT FEE";
export const RESI_HOLDOVER = "RESI HOLDOVER";
export const LAST_INVOICE_NO = "LAST_INVOICE_NO";

//Billing Preview Tag constant
export const BILLING_TITLE = "Billing Preview";
export const FILTERS = "Filters";
export const VARIANCE_EMPTY = "Variance cannot be empty";

//Exception Queue Tag constant
export const FILE_UPLOAD_SUCCESS = " File uploaded successfully.";
export const EXCEPTION_TYPE = "Exception Type";
export const EXCEPTION_TITLE = "Exception Queue";
export const EXCEPTION_UPLOAD_URL =
  "https://sds-image-uploader.azurewebsites.net/post";
export const EXCEPTION_TEXT_CONTENT = "Choose file";

//Action Component constants
export const SEARCH_VALIDATION_MESSAGE =
  "Please enter any column name to search";
export const SEARCH_PLACEHOLDER = "Enter column name";

//Billing Preview Column Definition
export const Varchar_Columns = [
  "BRAND",
  "LDC_ACCT_NO",
  "ACCT_NO",
  "ACCT_NM",
  "CUST_TYPE",
  "DPP_FLAG",
  "BUDGET_BILL_FLAG",
  "PREVIEW_PRODUCT_TYPE",
  "PREVIEW_INV_DT",
  "PREVIEW_DUE_DT",
  "HAS_TAX_EXEMPT_IN",
  "LAST_INVOICE_NO",
  "LAST_PRODUCT_TYPE",
  "LAST_INV_DUE_DT",
];

//Status Code constant
export const SUCCESS = "200";
export const ACCEPTED = 202;

export const SET_USAGE_HOLD = "Set Usage Hold";
export const REMOVE_USAGE_SUCCESS = "Removed usage hold IDs successfully."
export const SET_USAGE_SUCCESS = "Settings usage hold IDs done successfully."
export const ACTION_ERROR = "Request cannot be processed. Please try after some time.";
export const EXPIRATION_DATE_SELECTION_WARNING = "Please select the expiration date.";
export const CONFIRMATION_MESSAGE = "Are you ready to perform action on X selected rows?";
export const CONFIRMATION_TITLE = "Confirm to proceed?";
export const NO_RECORDS_TO_EXPORT = "There are no records currently to export";
export const CHANGE_INVOICE_CYCLE_SUCCESS = "Changed invoices cycle number successfully";
export const INVOICE_VAIDATION_MSG = "Enter value between 1 to 30:";
export const DATA_PREPARING_NOTIFICATION = "Please reload after few seconds, Invoice Preview data is preparing.";
export const FUSION_PREPARING_NOTIFICATION = "InvoiceBillPreviewB2C-Error: A notification will be sent when the requested data has been prepared.";
export const RECACHE_ENABLE_SUCCESS = "Request completed successfully, please wait for few seconds then reload.";
export const UPDATE_LDC_ACCOUNT_SUCCESS = "Updated LDC account status successfully";
export const DATA_ACCEPTED_NOTIFICATION = "Please reload after few seconds, your request accepted and still processing due to large data.";

//Fusion Endpoint
export const REACT_APP_MONTHLYUSAGE = import.meta.env.VITE_API_BASE_URL + "/MonthlyUsage";
export const REACT_APP_GETBILLINGPREVIEW = import.meta.env.VITE_API_BASE_URL + "/InvoiceBillPreviewB2C";
// export const REACT_APP_GETINVOICEBATCHLOGERROR = import.meta.env.VITE_API_BASE_URL + "/InvoiceBatchLogError?messageDate=";
export const REACT_APP_PREVIEWUSAGEHOLD = import.meta.env.VITE_API_BASE_URL + "/PreviewUsageHold";
// export const REACT_APP_GETUNRATEDUSAGE = import.meta.env.VITE_API_BASE_URL + "/UnratedUsage?creationDate=";
export const REACT_APP_CLOSEBATCHLOGERRORS = import.meta.env.VITE_API_BASE_URL + "/CloseBatchLogErrors";
export const REACT_APP_INVOICEHOLIDAYS = import.meta.env.VITE_API_BASE_URL + "/InvoiceHolidays";
export const REACT_APP_CLOSEMULTIPLEBATCHLOGERRORS = import.meta.env.VITE_API_BASE_URL + "/CloseMultipleBatchLogDetails";
export const REACT_APP_CHANGEINVOICECYCLE = import.meta.env.VITE_API_BASE_URL + "/ChangeInvoiceCycle";
export const REACT_APP_CHANGELDCACCOUNTSTATUS = import.meta.env.VITE_API_BASE_URL + "/ChangeLdcAcctStatus";

//legacy endpoints
export const REACT_APP_GETPREBILLED= import.meta.env.VITE_API_BASE_URL + "/GetPrebilledFailedAccounts";
export const REACT_APP_GETCONTRACTEXPIRINGACCOUNTS= import.meta.env.VITE_API_BASE_URL + "/GetContractExpiringAccounts";
export const REACT_APP_GETUNRATEDUSAGE = import.meta.env.VITE_API_BASE_URL + "/GetUnratedUsage?creationDate=";
export const REACT_APP_GETINVOICEBATCHLOGERROR = import.meta.env.VITE_API_BASE_URL + "/GetInvoiceBatchLogErrorsB2B?messageDate=";
export const REACT_APP_GETDUPLICATEMONTHLYUSAGE = import.meta.env.VITE_API_BASE_URL + "/GetDuplicateMonthlyUsage";
export const REACT_APP_GETUNBILLED35DAYS = import.meta.env.VITE_API_BASE_URL + "/GetUnbilled35?checkDate=";
export const REACT_APP_GETPENDINGFIRSTBILL = import.meta.env.VITE_API_BASE_URL + "/GetPendingFirstBill";

//Url's
export const LOGIN_URL = import.meta.env.VITE_API_BASE_URL?.replace('/api', '') + "/login/sso";
export const GET_TOKEN_BY_CODE = import.meta.env.VITE_API_BASE_URL?.replace('/api', '') + "/getTokenByCode?code=";
export const REGENERATE_TOKEN = import.meta.env.VITE_API_BASE_URL?.replace('/api', '') + "/regenerateToken?refresh_token=";
export const REACT_APP_DASHBOARD = import.meta.env.VITE_BASEURL + "/prebillvalidation";
export const REACT_APP_DASHBOARD_B2B = import.meta.env.VITE_BASEURL + "/prebillvalidation";


// Actions options
export const CLICK_ACTION = "Click to Perform Action";
export const REMOVE_USAGE_HOLD = "Remove Usage Hold";
export const CLOSE_BATCH_LOG_ERRORS = "Close Batch Log Error";
export const MIN_RECORD = "Select atleast 1 record to perform action - ";
export const CHANGE_INVOICE_CYCLE = "Change Invoice Cycle";
export const CHANGE_LDC_ACCOUNT_STATUS = "Change LDC Account Status";


//Invoice Batch log Error Message;
export const SET_CLOSEBATCHLOGERRORS_SUCCESS = "Closed batch log errors successfully."
export const SET_CLOSEBATCHLOGERRORS_ERROR = "Request cannot be processed. Please try after some time.";

// B2B and B2C vendors
export const SHELLENERGYSOLUTION_NE = "Shell Energy Solutions NE";
export const SHELLENERGYSOLUTION_CA = "Shell Energy Solutions - CA";

// User Types
export const B2B = "B2B";
export const B2C = "B2C";

// User type modal 
export const USERTYPE_TITLE_MSG = "Welcome User";
export const USERTYPE_TITLE_DESCRIPTION = "Please select your user type:";
export const USERTYPE_B2B_DESC = " - I support our large business customers."
export const USERTYPE_B2C_DESC = " - I support our residential and SMB customers."

// LDC account status 
export const LDCACCOUNTSTATUS_CANC = "CANC";
export const LDCACCOUNTSTATUS_TERM = "TERM";
export const LDCACCOUNTSTATUS_VOID = "VOID";

// set and remove usage internal status
export const USAGEHOLD_SUCCESS = "SUCCESS";
export const USAGEHOLD_ACCEPTED = "ACCEPTED";
export const USAGEHOLD_ERROR = "ERROR";

// Ag grid column id
export const INVOICE_ID = "INVOICE_ID"
export const LDC_ACCT_NO="LDC_ACCT_NO"
export const CREATION_DT="CREATION_DT"
export const MONTHLY_USAGE_ID="MONTHLY_USAGE_ID"
export const BATCH_LOG_ID="BATCH_LOG_ID"
export const ACCT_NM="ACCT_NM"
export const LDCAcctNo="LDC Acct No"
export const BillingAcctNo="Acct No"
export const CustomerAcctNo="Customer No"
export const BillingAcctName="Acct Name"
export const ACCT_ID="Acct Id"
export const LDC_ACCT_ID="LDC Acct Id"
export const Monthly_Usage_Id="Monthly Usage Id"
export const METER_ID="Meter Id"
