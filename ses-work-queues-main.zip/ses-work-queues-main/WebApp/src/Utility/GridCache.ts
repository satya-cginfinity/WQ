import * as WorkQueueConstant from "../Utility/Constant"
import dayjs from "dayjs";

type DateFilterType = typeof dayjs.prototype | null;

export const gridCache = {
  INVOICE_BATCH_LOG_ERROR: {
    rowData: null,
    filterModel: null,
    dateFilter: null as DateFilterType,
    selectedIPDDLOption: WorkQueueConstant.DEFAULT
  },
 UNRATED_USAGE: {
    rowData: null,
    filterModel: null,
    dateFilter: null as DateFilterType,
    selectedIPDDLOption: WorkQueueConstant.DEFAULT
  },
 DUPLICATE_USAGE: {
    rowData: null,
    filterModel: null,
    dateFilter: null as DateFilterType,
    selectedIPDDLOption: WorkQueueConstant.DEFAULT
  },
 UNBILLED_35_DAYS: {
    rowData: null,
    filterModel: null,
    dateFilter: null as DateFilterType,
    selectedIPDDLOption: WorkQueueConstant.DEFAULT
  },
 PENDING_FIRST_BILL: {
    rowData: null,
    filterModel: null,
    dateFilter: null as DateFilterType,
    selectedIPDDLOption: WorkQueueConstant.DEFAULT
  }
};
