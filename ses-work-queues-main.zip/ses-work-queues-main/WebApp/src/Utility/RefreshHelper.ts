import * as WorkQueueConstant from "./Constant";

export interface RefreshItem {
  cacheKey: string;
  fn: () => void; 
}

export type RefreshMap = Record<string, RefreshItem>;

export function createRefreshMap(fns: {
  unratedUsage: () => void;
  invoiceBatchLogError: () => void;
  duplicateUsage: () => void;
  unbilled35days: () => void;
  pendingFirstBill: () => void;
}): RefreshMap {
  return {
    [WorkQueueConstant.UNRATED_USAGE]: {
      cacheKey: "UNRATED_USAGE",
      fn: fns.unratedUsage
    },
    [WorkQueueConstant.INVOICE_BATCH_LOG_ERROR]: {
      cacheKey: "INVOICE_BATCH_LOG_ERROR",
      fn: fns.invoiceBatchLogError
    },
    [WorkQueueConstant.DUPLICATE_USAGE]: {
      cacheKey: "DUPLICATE_USAGE",
      fn: fns.duplicateUsage
    },
    [WorkQueueConstant.UNBILLED_35_DAYS]: {
      cacheKey: "UNBILLED_35_DAYS",
      fn: fns.unbilled35days
    },
    [WorkQueueConstant.PENDING_FIRST_BILL]: {
      cacheKey: "PENDING_FIRST_BILL",
      fn: fns.pendingFirstBill
    }
  };
}