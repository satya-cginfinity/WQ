let email;
email = localStorage.getItem("email")?.toString();

export const GetUserFullName = () => {
  let fullName = email.split('@')[0];
  return fullName;
};

export const GetUserNameDotSeperated = () => {
  let userName = GetUserFirstName() + "." + GetUserLastName();
  return userName;
};

export const GetUserFirstName = () => {
  let fullName = GetUserFullName();
  let firstName = fullName.split('.')[0].charAt(0).toUpperCase() + fullName.split('.')[0].substr(1);
  return firstName;
};

export const GetUserLastName = () => {
  let fullName = GetUserFullName();
  let lastName = fullName.split('.')[1].charAt(0).toUpperCase() + fullName.split('.')[1].substr(1);
  return lastName;
};

export const GetUserNameSpaceSeperated = () => {
  let userName = GetUserFirstName() + " " + GetUserLastName();
  return userName;
};



