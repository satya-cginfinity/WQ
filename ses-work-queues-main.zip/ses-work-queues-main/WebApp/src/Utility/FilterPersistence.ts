interface FilterData {
  dateFilter?: string | null;
  minDate?: string | null;
  maxDate?: string | null;
  selectedIPDDLOption?: string;
  filterModel?: any;
  timestamp: number;
}

interface StorageData {
  [page: string]: {
    [tab: string]: FilterData;
  };
}

export const FilterPersistence = {
  STORAGE_KEY: 'workqueue_filters',
  EXPIRATION_TIME: 24 * 60 * 60 * 1000, // 24 hours in milliseconds

  /**
   * Save filters for a specific page and tab
   * @param page - The page name (e.g., 'billing', 'prebill')
   * @param tab - The tab name within the page
   * @param filters - The filter data to save
   */
  save: (page: string, tab: string, filters: Partial<FilterData>) => {
    try {
      const existing = FilterPersistence.load(page, tab) || {};
      const stored = FilterPersistence.getAll();
      
      if (!stored[page]) {
        stored[page] = {};
      }
      
      stored[page][tab] = {
        ...existing,
        ...filters,
        timestamp: Date.now()
      };
      
      sessionStorage.setItem(FilterPersistence.STORAGE_KEY, JSON.stringify(stored));
    } catch (error) {
      console.error('Failed to save filters to sessionStorage:', error);
      // If storage is full, clear old data and retry
      if (error instanceof Error && error.name === 'QuotaExceededError') {
        FilterPersistence.clearExpired();
        try {
          const stored = FilterPersistence.getAll();
          if (!stored[page]) {
            stored[page] = {};
          }
          stored[page][tab] = {
            ...filters,
            timestamp: Date.now()
          };
          sessionStorage.setItem(FilterPersistence.STORAGE_KEY, JSON.stringify(stored));
        } catch (retryError) {
          console.error('Failed to save filters after clearing expired data:', retryError);
        }
      }
    }
  },

  /**
   * Load filters for a specific page and tab
   * @param page - The page name
   * @param tab - The tab name within the page
   * @returns The saved filter data or null if not found/expired
   */
  load: (page: string, tab: string): FilterData | null => {
    try {
      const stored = sessionStorage.getItem(FilterPersistence.STORAGE_KEY);
      if (!stored) return null;
      
      const parsed: StorageData = JSON.parse(stored);
      const filters = parsed[page]?.[tab];
      
      if (!filters) return null;
      
      // Check if filters have expired
      if (filters.timestamp && Date.now() - filters.timestamp > FilterPersistence.EXPIRATION_TIME) {
        FilterPersistence.clear(page, tab);
        return null;
      }
      
      return filters;
    } catch (error) {
      console.error('Failed to load filters from sessionStorage:', error);
      return null;
    }
  },

  /**
   * Get all stored filters
   * @returns All stored filter data
   */
  getAll: (): StorageData => {
    try {
      const stored = sessionStorage.getItem(FilterPersistence.STORAGE_KEY);
      return stored ? JSON.parse(stored) : {};
    } catch (error) {
      console.error('Failed to get all filters from sessionStorage:', error);
      return {};
    }
  },

  /**
   * Clear filters for a specific page/tab or all filters
   * @param page - Optional page name
   * @param tab - Optional tab name (requires page to be specified)
   */
  clear: (page?: string, tab?: string) => {
    try {
      if (!page) {
        sessionStorage.removeItem(FilterPersistence.STORAGE_KEY);
        return;
      }
      
      const existing = FilterPersistence.getAll();
      
      if (tab) {
        if (existing[page]) {
          delete existing[page][tab];
          // Remove page if no tabs left
          if (Object.keys(existing[page]).length === 0) {
            delete existing[page];
          }
        }
      } else {
        delete existing[page];
      }
      
      sessionStorage.setItem(FilterPersistence.STORAGE_KEY, JSON.stringify(existing));
    } catch (error) {
      console.error('Failed to clear filters from sessionStorage:', error);
    }
  },

  /**
   * Clear expired filters (older than 24 hours)
   */
  clearExpired: () => {
    try {
      const stored = FilterPersistence.getAll();
      const now = Date.now();
      let modified = false;
      
      Object.keys(stored).forEach(page => {
        Object.keys(stored[page]).forEach(tab => {
          const filters = stored[page][tab];
          if (filters.timestamp && now - filters.timestamp > FilterPersistence.EXPIRATION_TIME) {
            delete stored[page][tab];
            modified = true;
          }
        });
        
        // Remove page if no tabs left
        if (Object.keys(stored[page]).length === 0) {
          delete stored[page];
        }
      });
      
      if (modified) {
        sessionStorage.setItem(FilterPersistence.STORAGE_KEY, JSON.stringify(stored));
      }
    } catch (error) {
      console.error('Failed to clear expired filters:', error);
    }
  },

  /**
   * Check if filters exist for a specific page and tab
   * @param page - The page name
   * @param tab - The tab name
   * @returns true if filters exist and are not expired
   */
  exists: (page: string, tab: string): boolean => {
    const filters = FilterPersistence.load(page, tab);
    return filters !== null;
  }
};

// Clear expired filters on module load
FilterPersistence.clearExpired();
