import * as WorkQueueConstant from "../Utility/Constant";

 export const GetDDLOptions = () => {
    return [
      { value: WorkQueueConstant.DEFAULT, label: WorkQueueConstant.DEFAULT, default: 1 },
      { value: WorkQueueConstant.BUNDLED_RATES_TDSP, label: WorkQueueConstant.BUNDLED_RATES_TDSP },
      { value: WorkQueueConstant.REVERSE_BUNDLED_RATES_TDSP, label: WorkQueueConstant.REVERSE_BUNDLED_RATES_TDSP },
      { value: WorkQueueConstant.BB_INVOICE_BB_COUNT, label: WorkQueueConstant.BB_INVOICE_BB_COUNT },
      { value: WorkQueueConstant.REVERSE_BB_INVOICE_BB_COUNT, label: WorkQueueConstant.REVERSE_BB_INVOICE_BB_COUNT },
      { value: WorkQueueConstant.INVOICE_DPP, label: WorkQueueConstant.INVOICE_DPP },
      { value: WorkQueueConstant.REVERSE_INVOICE_DPP, label: WorkQueueConstant.REVERSE_INVOICE_DPP },
      { value: WorkQueueConstant.INVOICE_RATE, label: WorkQueueConstant.INVOICE_RATE },
      { value: WorkQueueConstant.REVERSE_INVOICE_RATE, label: WorkQueueConstant.REVERSE_INVOICE_RATE },
      { value: WorkQueueConstant.FIRST_TIME_BILLERS, label: WorkQueueConstant.FIRST_TIME_BILLERS },
      { value: WorkQueueConstant.INVOICE_VARIANCE_KWH, label: WorkQueueConstant.INVOICE_VARIANCE_KWH },
      { value: WorkQueueConstant.INVOICE_VARIANCE_$$, label: WorkQueueConstant.INVOICE_VARIANCE_$$ }
    ];
  };