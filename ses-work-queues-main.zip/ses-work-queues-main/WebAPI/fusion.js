// //#region Libraries
// const express = require("express");
// var router = express.Router();
// const request = require('request');
// var util = require('./common');
// const sessionStorage = require('sessionstorage');
// var Constants = require('./Utility/constants');
// //#endregion

// //#region Fusion API's

// router.get('/InvoiceBillPreviewB2C', async (req, res) => {
//   try {
//     var param = "";
//     if(req.query.recache === 'true'){
//       param = "&_RECACHE=" + req.query.recache;
//     }

//     var options = await util.getFusionApiOptions(Constants.INVOICE_BILL_PREVIEW_B2C.replace("{recache}", param));
//     request(options, function (error, response) {
//       try {
//         if (error) {
//           res.json(util.formatError(response, 'InvoiceBillPreviewB2C: ', error));
//         }
//         else if (res && response?.body) {
//           if (response && response.statusCode == Constants.SUCCESS) {
//             res.json(util.formatSuccessResponse(JSON.parse(response?.body)));
//           }
//           else {
//             res.json(util.formatError(response, 'InvoiceBillPreviewB2C-Error: ', JSON.parse(response?.body)?.message?.toString()));
//           }
//         }
//       }
//       catch (ex) {
//         res.json(util.formatError(response, 'InvoiceBillPreviewB2C API -Exception: ', ex.message?.toString()));
//       }
//     });
//   }
//   catch (ex) {
//     res.json(util.formatError(null, 'InvoiceBillPreviewB2C-Exception: ', ex.message?.toString()));
//   }
// });

// router.get('/UnratedUsage', async (req, res) => {
//   try {

//     var param = "";
//     if(req.query.creationDate){
//       param = "CREATION_DATE=" + req.query.creationDate + Constants.DEFAULT_TIMESTAMP + "&";
//     }

//     var url = Constants.UNRATED_USAGE.replace("{creation_date_param}", param);
//     var options = await util.getFusionApiOptions(url);

//     request(options, function (error, response) {
//       try {
//         if (error) {
//           res.json(util.formatError(response, 'UnratedUsage: ', error));
//         }
//         else if (res && response?.body) {
//           if (response && response.statusCode == Constants.SUCCESS) {
//             res.json(util.formatSuccessResponse(JSON.parse(response?.body)));
//           }
//           else {
//             res.json(util.formatError(response, 'UnratedUsage-Error: ', response?.body?.toString()));
//           }

//         }
//       }
//       catch (ex) {
//         res.json(util.formatError(response, 'UnratedUsage-API-Exception: ', ex.message?.toString()));
//       }
//     });
//   }
//   catch (ex) {
//     res.json(util.formatError(null, 'UnratedUsage-Exception: ', ex.message?.toString()));
//   }
// });

// router.get('/InvoiceBatchLogError', async (req, res) => {
//   try {

//     var param = "";
//     if(req.query.messageDate){
//       param = "MESSAGE_DATE=" + req.query.messageDate + "&";
//     }

//     var url = Constants.INVOICE_BATCH_LOG_ERROR.replace("{message_date_param}", param);
//     var options = await util.getFusionApiOptions(url);

//     request(options, function (error, response) {
//       try {
//         if (error) {
//           res.json(util.formatError(response, 'InvoiceBatchLogError: ', error));
//         }
//         else if (res && response.body) {
//           if (response && response.statusCode == Constants.SUCCESS) {
//             res.json(util.formatSuccessResponse(JSON.parse(response?.body)));
//           }
//           else {
//             res.json(util.formatError(response, 'InvoiceBatchLogError-Error: ', JSON.parse(response?.body)?.message?.toString()));
//           }

//         }
//       }
//       catch (ex) {
//         res.json(util.formatError(response, 'InvoiceBatchLogError-API-Exception: ', ex.message?.toString()));
//       }
//     });
//   }
//   catch (ex) {
//     res.json(util.formatError(null, 'InvoiceBatchLogError-Exception: ', ex.message?.toString()));
//   }
// });

// router.post('/PreviewUsageHold', async (req, res) => {
//   try {
//     var options = await util.putAndPostFusionApiOptions(Constants.PREVIEW_USAGE_HOLD,JSON.stringify(req.body),Constants.POST);

//     request(options, function (error, response) {
//       try {
//         if (error) {
//           res.json(util.formatError(response, 'PreviewUsageHold: ', error));
//         }
//         else if (res && response?.body) {
//           if (response && response.statusCode == Constants.CREATED) {
//             res.json(util.formatSuccessResponse(JSON.parse(response?.body)));
//           }
//           else {
//             res.json(util.formatError(response, 'PreviewUsageHold-Error: ', JSON.parse(response?.body)?.message?.toString()));
//           }

//         }
//       }
//       catch (ex) {
//         res.json(util.formatError(response, 'PreviewUsageHold-API-Exception: ', ex.message?.toString()));
//       }
//     });
//   }
//   catch (ex) {
//     res.json(util.formatError(null, 'PreviewUsageHold-Exception: ', ex.message?.toString()));
//   }
// });

// router.put('/MonthlyUsage', async (req, res) => {
//   try {
//     let bulkAPIPayload = {
//       ENDPOINT: Constants.MONTHLY_USAGE,
//       METHOD: 'PUT',
//       PAYLOADS: req.body.USAGE_IDS.map(id => ({
//         USAGE_IDS: [id],
//         INVOICE_HOLD_EXPIRATION_DATE: req.body.INVOICE_HOLD_EXPIRATION_DATE,
//       })),
//       TEST_MODE: 0
//     }

//     var options = await util.putAndPostFusionApiOptions(Constants.BULK, JSON.stringify(bulkAPIPayload), Constants.POST);

//     request(options, function (error, response) {

//       try {
//         if (error) {
//           res.json(util.formatError(response, 'BulkApi-MonthlyUsage-API: ', error));
//         }
//         else if (res && response?.body) {
//           console.log(response);
//           if (response && response.statusCode == Constants.SUCCESS) {
//             res.json(util.formatSuccessResponse(JSON.parse(response?.body)));
//           }
//           else if(response && response.statusCode == Constants.PROCESSING) {
//             res.json(util.formatSuccessResponse(response?.body, response.statusCode));
//           }
//           else {
//             res.json(util.formatError(response, 'BulkApi-MonthlyUsage-API: ', response?.body));
//           }
//         }
//         else if (res && response.statusCode == Constants.NO_CONTENT) {
//           var msg = JSON.stringify({ "msg": Constants.NO_CONTENT_MSG });
//           var result = JSON.stringify({ "status": Constants.NO_CONTENT, "Message": msg });
//           res.json(util.formatSuccessResponse(result, Constants.NO_CONTENT));
//         }
//       }
//       catch (ex) {
//         res.json(util.formatError(response, 'BulkApi-MonthlyUsage-API-Exception: ', ex.message?.toString()));
//       }
//     });
//   }
//   catch (ex) {
//     res.json(util.formatError(null, 'BulkApi-MonthlyUsage-API-Exception: ', ex.message?.toString()));
//   }
// });


// router.put('/CloseBatchLogErrors', async (req, res) => {
//   try {

//     var options = await util.putAndPostFusionApiOptions(Constants.CLOSE_BATCH_LOG_ERRORS, JSON.stringify(req.body));

//     request(options, function (error, response) {
//       try {
//         if (error) {
//           res.json(util.formatError(response, 'CloseBatchLogErrors: ', error));
//         }
//         else if (res && response?.body) {
//           if (response && response.statusCode == Constants.SUCCESS) {
//             res.json(util.formatSuccessResponse(JSON.parse(response?.body)));
//           }
//           else {
//             res.json(util.formatError(response, 'CloseBatchLogErrors-Error: ', JSON.parse(response?.body)?.message?.toString()));
//           }
//         }
//         else if(res && response.statusCode == Constants.NO_CONTENT){
//           var msg = JSON.stringify({"msg":Constants.NO_CONTENT_MSG});
//           var closeBatchLogResult = JSON.stringify({"status":Constants.NO_CONTENT,"Message" : msg});
//           res.json(util.formatSuccessResponse(closeBatchLogResult, Constants.NO_CONTENT));
//         }
//       }
//       catch (ex) {
//         res.json(util.formatError(response, 'CloseBatchLogErrors-API-Exception: ', ex.message?.toString()));
//       }
//     });
//   }
//   catch (ex) {
//     res.json(util.formatError(null, 'CloseBatchLogErrors-Exception: ', ex.message?.toString()));
//   }
// });

// router.get('/InvoiceHolidays', async (req, res) => {
//   try {
//     var bhOptions = await util.getFusionApiOptions(Constants.INVOICE_HOLIDAY_ID);
//     //Get Invoice Holiday Calendar ID
//     request(bhOptions, async function (error, response) {
//       if (response?.body) {
//           var ResponseBody = JSON.parse(response.body);  
//           if (response && response.statusCode === 200) {
//             var invoiceHolidayId = ResponseBody.rows[0].CALENDAR_ID;

//             //#region Get Invoice Holiday list based on Calendar ID
//             var options = await util.getFusionApiOptions(Constants.INVOICE_HOLIDAYS.replace("{calendar_id}", invoiceHolidayId));
//             request(options, function (error, response) {
//               try {
//                 if (error) {
//                   res.json(util.formatError(response, 'InvoiceHolidays: ', error));
//                 }
//                 else if (res && response?.body) {
//                   if (response && response.statusCode == Constants.SUCCESS) {
//                     var data = JSON.parse(response?.body);
//                     var dateArray = data.rows.map(({HOLIDAY_DATE}) => HOLIDAY_DATE);
//                     res.json(util.formatSuccessResponse(dateArray));
//                   }
//                   else {
//                     res.json(util.formatError(response, 'InvoiceHolidays-Error: ', JSON.parse(response?.body)?.message?.toString()));
//                   }
//                 }
//               }
//               catch (ex) {
//                 res.json(util.formatError(response, 'InvoiceHolidays-API-Exception: ', ex.message?.toString()));
//               }
//             });
//             //#endregion
//           }
//       }});
//   }
//   catch (ex) {
//     res.json(util.formatError(null, 'InvoiceHolidays-Exception: ', ex.message?.toString()));
//   }
// });

// router.post('/Bulk', async (req, res) => {
//   try {

//     var options = await util.putAndPostFusionApiOptions(Constants.BULK, JSON.stringify(req.body),Constants.POST);

//     request(options, function (error, response) {
//       try {
//         if (error) {
//           res.json(util.formatError(response, 'Bulk: ', error));
//         }
//         else if (res && response?.body) {
//           if (response && response.statusCode == Constants.SUCCESS) {
//             res.json(util.formatSuccessResponse(JSON.parse(response?.body)));
//           }
//           else {
//             res.json(util.formatError(response, 'Bulk-Error: ', JSON.parse(response?.body)?.message?.toString()));
//           }
//         }
//         else if(res && response.statusCode == Constants.NO_CONTENT){
//           var msg = JSON.stringify({"msg":Constants.NO_CONTENT_MSG});
//           var closeBatchLogResult = JSON.stringify({"status":Constants.NO_CONTENT,"Message" : msg});
//           res.json(util.formatSuccessResponse(closeBatchLogResult, Constants.NO_CONTENT));
//         }
//       }
//       catch (ex) {
//         res.json(util.formatError(response, 'Bulk-API-Exception: ', ex.message?.toString()));
//       }
//     });
//   }
//   catch (ex) {
//     res.json(util.formatError(null, 'Bulk-Exception: ', ex.message?.toString()));
//   }
// });

// router.post('/CloseMultipleBatchLogDetails', async (req, res) => {
//   try {
//     var body = req.body;
//     body.ENDPOINT = Constants.BULK_CLOSE_BATCH_LOG_DETAILS;
//     body.METHOD = Constants.PUT;
//     body.TEST_MODE = 0;

//     var options = await util.putAndPostFusionApiOptions(Constants.BULK, JSON.stringify(body), Constants.POST);
//     request(options, function (error, response) {
//       try {
//         if (error) {
//           res.json(util.formatError(response, 'CloseMultipleBatchLogDetails: ', error));
//         }
//         else if (res && response?.body) {
//           if (response && response.statusCode == Constants.SUCCESS) {
//             res.json(util.formatSuccessResponse(JSON.parse(response?.body)));
//           }
//           else {
//             console.log(JSON.parse(response?.body)[0].data?.message);
//             res.json(util.formatError(response, 'CloseMultipleBatchLogDetails-Error: ', JSON.parse(response?.body)[0].data?.message?.toString()));
//           }
//         }
//         else if(res && response.statusCode == Constants.NO_CONTENT){
//           var msg = JSON.stringify({"msg":Constants.NO_CONTENT_MSG});
//           var closeBatchLogResult = JSON.stringify({"status":Constants.NO_CONTENT,"Message" : msg});
//           res.json(util.formatSuccessResponse(closeBatchLogResult, Constants.NO_CONTENT));
//         }
//       }
//       catch (ex) {
//         res.json(util.formatError(response, 'CloseMultipleBatchLogDetails-API-Exception: ', ex.message?.toString()));
//       }
//     });
//   }
//   catch (ex) {
//     res.json(util.formatError(null, 'CloseMultipleBatchLogDetails-Exception: ', ex.message?.toString()));
//   }
// });

// router.post('/ChangeInvoiceCycle', async (req, res) => {
//   try {
//     var body = req.body;
//     body.ENDPOINT = Constants.BULK_CHANGE_INVOICE_CYCLE;
//     body.METHOD = Constants.PUT;
//     body.TEST_MODE = 0;

//     var options = await util.putAndPostFusionApiOptions(Constants.BULK, JSON.stringify(body), Constants.POST);
//     request(options, function (error, response) {
//       try {
//         if (error) {
//           res.json(util.formatError(response, 'ChangeInvoiceCycle: ', error));
//         }
//         else if (res && response?.body) {
//           if (response && response.statusCode == Constants.SUCCESS) {
//             res.json(util.formatSuccessResponse(JSON.parse(response?.body)));
//           }
//           else {
//             console.log(JSON.parse(response?.body)[0].data?.message);
//             res.json(util.formatError(response, 'ChangeInvoiceCycle-Error: ', JSON.parse(response?.body)[0].data?.message?.toString()));
//           }
//         }
//         else if(res && response.statusCode == Constants.NO_CONTENT){
//           var msg = JSON.stringify({"msg":Constants.NO_CONTENT_MSG});
//           var closeBatchLogResult = JSON.stringify({"status":Constants.NO_CONTENT,"Message" : msg});
//           res.json(util.formatSuccessResponse(closeBatchLogResult, Constants.NO_CONTENT));
//         }
//       }
//       catch (ex) {
//         res.json(util.formatError(response, 'ChangeInvoiceCycle-API-Exception: ', ex.message?.toString()));
//       }
//     });
//   }
//   catch (ex) {
//     res.json(util.formatError(null, 'ChangeInvoiceCycle-Exception: ', ex.message?.toString()));
//   }
// });

// router.post('/ChangeLdcAcctStatus', async (req, res) => {
//   try {
//     var body = req.body;

//     //#region Interaction Params
//     var interactionBody ={ 
//       "PAYLOADS" : [],
//       "ENDPOINT" : Constants.BULK_FUSION_INTERACTION,
//       "METHOD" : Constants.POST,
//       "TEST_MODE" : 0
//     };

//     req.body.PAYLOADS.forEach(x=>{
//       interactionBody.PAYLOADS.push({ "INTERACTION" : {
//         RELATE_ID : x.SERVICE_ID,
//         RELATE_CLASS : "cLDCACCOUNT",
//         INTERACTION_NUMBER : "",
//         INTERACTION_DATE : util.getCurrentDate() ,
//         DESCRIPTION : "LDC Account "+ x.LDC_ACCT_NO +" Status changed by user "+ body.NAME +" based on Unbilled review process.",
//         CONTACT_NAME : body.NAME,
//         USER_NAME : body.USER_NAME,
//         TYPE_CODE : "OQ",
//         SUB_TYPE_CODE : ""
//       }});
//     });

//     var interactionOptions = await util.putAndPostFusionApiOptions(Constants.BULK, JSON.stringify(interactionBody), Constants.POST);
    
//     delete body.NAME;
//     delete body.USER_NAME;
//     req.body.PAYLOADS.forEach(x=>{
//       delete x.LDC_ACCT_NO;
//     });
//     console.log(interactionOptions);
//     //#endregion

//     //#region Change LDC ACCT STATUS Params
//     body.ENDPOINT = Constants.BULK_FUSION_SERVICE;
//     body.METHOD = Constants.PUT;
//     body.TEST_MODE = 0;
//     var options = await util.putAndPostFusionApiOptions(Constants.BULK, JSON.stringify(body), Constants.POST);
//     //#endregion

//     request(options, function (error, response) {
//       try {
//         if (error) {
//           res.json(util.formatError(response, 'ChangeLdcAcctStatus: ', error));
//         }
//         else if (res && response?.body) { 
//           if (response && response.statusCode == Constants.SUCCESS) {

//             //#region Call interaction API
//             request(interactionOptions, function (error, innerResponse) {
//               try {
//                 if (error) {
//                   res.json(util.formatError(innerResponse, 'ChangeLdcAcctStatusInteraction: ', error));
//                 }
//                 else if (res && innerResponse?.body) {
//                   if (innerResponse && innerResponse.statusCode == Constants.SUCCESS) {
//                     res.json(util.formatSuccessResponse(JSON.parse(innerResponse?.body)));
//                   }
//                   else {
//                     //console.log(innerResponse);
//                     res.json(util.formatError(innerResponse, 'ChangeLdcAcctStatusInteraction-Error: ', JSON.parse(innerResponse?.body)?.message?.toString()));
//                   }
//                 }
//               }
//               catch (ex) {
//                 res.json(util.formatError(innerResponse, 'ChangeLdcAcctStatusInteraction-API-Exception: ', ex.message?.toString()));
//               }
//             });
//             //#endregion
//           }
//           else {
//             res.json(util.formatError(response, 'ChangeLdcAcctStatus-Error: ', JSON.parse(response?.body)?.message?.toString()));
//           }
//         }
//         else if(res && response.statusCode == Constants.NO_CONTENT){
//           var msg = JSON.stringify({"msg":Constants.NO_CONTENT_MSG});
//           var closeBatchLogResult = JSON.stringify({"status":Constants.NO_CONTENT,"Message" : msg});
//           res.json(util.formatSuccessResponse(closeBatchLogResult, Constants.NO_CONTENT));
//         }
//       }
//       catch (ex) {
//         res.json(util.formatError(response, 'ChangeLdcAcctStatus-API-Exception: ', ex.message?.toString()));
//       }
//     });
//   }
//   catch (ex) {
//     res.json(util.formatError(null, 'ChangeLdcAcctStatus-Exception: ', ex.message?.toString()));
//   }
// });

// //#endregion

// //#region Generate Session

// router.post('/GetSessionId', (req, res) => {
//   try {
//     var options = util.postApiOptions(Constants.GET_SESSION_ID);
//     request(options, function (error, response) {
//       try {
//         if (error) {
//           res.json(util.formatError(response, 'GetSessionId: ', error));
//         }
//         else if (res && response?.body) {
//           if (response && response.statusCode == Constants.SUCCESS) {
//             sessionStorage.setItem("session_id", JSON.parse(response?.body).session_id);
//             res.json(util.formatSuccessResponse(JSON.parse(response?.body)));
//           }
//           else {
//             res.json(util.formatError(response, 'GetSessionId-Error: ', JSON.parse(response?.body)?.Message?.toString()));
//           }
//         }
//       }
//       catch (ex) {
//         res.json(util.formatError(response, 'GetSessionId-API-Exception: ', ex.message?.toString()));
//       }
//     });
//   }
//   catch (ex) {
//     res.json(util.formatError(null, 'GetSessionId-Exception: ', ex.message?.toString()));
//   }
// });

// //#endregion

// module.exports = router;
