//#region Libraries
require('dotenv-expand').expand(require('dotenv').config());
const https = require('https');
let sessionStorage = require('sessionstorage');
// const request = require('request');
const base64url = require('base64url');
const crypto = require('crypto');
var Constants = require('./Utility/constants');
const jwt = require('jsonwebtoken');
//#endregion

//#region General Helpers

const getApiOptions = function (url) {
  var options = {
    'method': 'GET',
    'agent': new https.Agent({
      'secureOptions': require('constants').SSL_OP_LEGACY_SERVER_CONNECT
    }),
    'url': url,
    'headers': {
      'X-ApiKey': process.env.API_KEY
    }
  };
  return options;
}

const postApiOptions = function (url) {
  var options = {
    'method': 'POST',
    'agent': new https.Agent({
      'secureOptions': require('constants').SSL_OP_LEGACY_SERVER_CONNECT
    }),
    'url': url,
    'headers': {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      "CLIENTID": process.env.CLIENT_ID,
      "CLIENTSECRET": process.env.CLIENT_SECRET
    })
  };
  return options;
}

const getCurrentDate = function () {
  var date = new Date();
  return date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
}

//#endregion

//#region Fusion Helpers

const getFusionApiOptions = async function (url) {
  var currentTimeStamp = getTimestamp();
  var sessionExpirationTimestamp = sessionStorage.getItem(Constants.SESSION_EXP_TIMESTAMP);

  if (sessionStorage.getItem(Constants.SESSION_ID_KEY) === null || currentTimeStamp > sessionExpirationTimestamp) {
    // await getSessionId();
  }
  var options = {
    'method': 'GET',
    'agent': new https.Agent({
      'secureOptions': require('constants').SSL_OP_LEGACY_SERVER_CONNECT
    }),
    'url': url,
    'headers': {
      'Cookie': Constants.COOKIE_NAME + sessionStorage.getItem(Constants.SESSION_ID_KEY)
    }
  };

  return options;
}

const putAndPostFusionApiOptions = async function (url, data, requestType = Constants.PUT) {
  var currentTimeStamp = getTimestamp();
  var sessionExpirationTimestamp = sessionStorage.getItem(Constants.SESSION_EXP_TIMESTAMP);

  if (sessionStorage.getItem(Constants.SESSION_ID_KEY) === null || currentTimeStamp > sessionExpirationTimestamp) {
    // await getSessionId();
  }

  var options = {
    'method': requestType,
    'agent': new https.Agent({
      'secureOptions': require('constants').SSL_OP_LEGACY_SERVER_CONNECT
    }),
    'url': url,
    'headers': {
      'Cookie': Constants.COOKIE_NAME + sessionStorage.getItem(Constants.SESSION_ID_KEY),
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: data
  };
  return options;
}

//#endregion

//#region Fusion API's

// const getSessionId = function () {
//   return new Promise((resolve, reject) => {
//     var options = postApiOptions(Constants.GET_SESSION_ID);
//     request(options, function (error, response) {
//       if (error)
//         reject(error);
//       else {
        // if (response?.body) {
        //   var ResponseBody = JSON.parse(response.body);
        //   if (response && response.statusCode === 200) {
        //     sessionStorage.setItem(Constants.SESSION_ID_KEY, ResponseBody.session_id);
        //     sessionStorage.setItem(Constants.SESSION_EXP_TIMESTAMP, getTimestamp(44));
        //     console.log('Session Id: ' + ResponseBody.session_id);
        //   }
        //   else {
        //     console.log("Error Message: " + ResponseBody.Message);
        //   }
        // }
//         resolve({ response });
//       }

//     });
//   });

// }

// const generateSessionId = new Promise((resolve, reject) => {
  // getSessionId();

// })

//#endregion

//#region Common Utility

const generateCodeChallenge = function () {
  var code_challenge = base64url.encode(crypto.createHash('sha256').update(Constants.CODE_VERIFIER).digest());
  return code_challenge;
};

function generateRandomCode(length) {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;
  let counter = 0;
  while (counter < length) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
    counter += 1;
  }
  return result;
}

function decodeToken(token) {
  var token = jwt.decode(token);
  return token;
}

function getTimestamp(minutes = 0) {
  let currentDate = new Date();
  currentDate.setMinutes(currentDate.getMinutes() + minutes);
  return currentDate.getTime() / 1000;
}

//#endregion

//#region Formatting Utility

const formatError = function (response, apiName, error) {
  var obj = new Object();
  obj.error = apiName + error;
  var errorMessage = JSON.stringify(obj);
  if (response && response?.statusCode == Constants.NOT_AUTHENTICATED) {
    // getSessionId();
  }
  return {
    status: response && response?.statusCode ? response?.statusCode : Constants.INTERNAL_SERVER_ERROR,
    message: errorMessage
  };
}

const formatSuccessResponse = function (responseBody, statusCode = Constants.SUCCESS) {
  return {
    status: statusCode,
    message: responseBody
  };
}

//#endregion

module.exports = { getCurrentDate, getApiOptions, putAndPostFusionApiOptions, getFusionApiOptions, postApiOptions, generateRandomCode, formatError, formatSuccessResponse, generateCodeChallenge, decodeToken };