//#region Libraries
require('dotenv-expand').expand(require ('dotenv').config());
const express = require("express");
var router = express.Router();
const passport = require('passport');
const SSOStrategy = require('passport-openidconnect').Strategy;
const sessionStorage = require('sessionstorage');
var Constants = require('./Utility/constants');
var util = require('./common');
//#endregion

//#region Initialization
const baseUri = `${process.env.SIMAAS_BASE_URI}`;
const authorizationURL = `${baseUri}/as/authorization.oauth2?code_challenge=${util.generateCodeChallenge()}&`;
const userInfoURL = `${baseUri}/idp/userinfo.openid`;
const tokenURL = `${baseUri}/as/token.oauth2`;
//#endregion

//#region Configure Passport Strategy - OIDC

passport.use('oidc' ,new SSOStrategy({
  issuer: baseUri,
  clientID: process.env.SIMAAS_CLIENT_ID,
  clientSecret: process.env.SIMAAS_CLIENT_SECRET,
  authorizationURL: authorizationURL,
  userInfoURL: userInfoURL,
  tokenURL: tokenURL,
  callbackURL: process.env.SIMAAS_REDIRECT_URI,
  scope: "profile PingCentral-Role",
  passReqToCallback: true
},
  function (req, issuer, userId, profile, accessToken, refreshToken, params, cb) {

    console.log('issuer:', issuer);
    console.log('userId:', userId);
    console.log('accessToken:', accessToken);
    console.log('refreshToken:', refreshToken);
    console.log('params:', params);

    req.session.accessToken = accessToken;

    return cb(null, profile);
  }));

passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser((user, done) => {
  done(null, user);
});
//#endregion

//#region Authentication/Callbacks
router.get("/login/sso", passport.authenticate('oidc'));

router.get('/oauth/callback', async (req, res, next) => {
  // get the code parameter
  const code = req.query.code;

  // get the error parameters
  const error = req.query.error;
  const errorDescription = req.query.error_description;

  if (error) {
    console.error('Error:', error);
    console.error('Error Description:', errorDescription);
    res.json({ message: Constants.AUTH_FAILED_MSG });
  }

  // trade code for access token
  // via the token endpoint on SIMAAS API
  // using the client id and client secret as basic auth
  var authHeader =
    'Basic ' +
    Buffer.from(
      `${process.env.SIMAAS_CLIENT_ID}:${process.env.SIMAAS_CLIENT_SECRET}`
    ).toString('base64');

  const response = await fetch(tokenURL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: authHeader,
    },
    body: new URLSearchParams({
      grant_type: 'authorization_code',
      redirect_uri: process.env.SIMAAS_REDIRECT_URI,
      code,
      code_verifier: util.generateCodeChallenge(),
    }),
  });

  console.log({
    grant_type: 'authorization_code',
    redirect_uri: process.env.SIMAAS_REDIRECT_URI,
    code,
    code_verifier: util.generateCodeChallenge(),
  })

  const data = await response.json();
   console.log('sso-token:', data);
  var randomCode = util.generateRandomCode(5);
  sessionStorage.setItem(randomCode, data);
  res.redirect(process.env.AUTH_SUCCESS_URL+randomCode);
});

router.get('/regenerateToken', async (req, res, next) => {
  var authHeader =
    'Basic ' +
    Buffer.from(
      `${process.env.SIMAAS_CLIENT_ID}:${process.env.SIMAAS_CLIENT_SECRET}`
    ).toString('base64');

  const response = await fetch(tokenURL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: authHeader,
    },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: req.query.refresh_token
    }),
  });

  const data = await response.json();
  var decodedToken = util.decodeToken(data.access_token);

  res.json({ 
    token: data.access_token,
    refresh_token: data.refresh_token,
    exp: decodedToken?.exp
  });
});

router.get("/getTokenByCode", (req, res) => {
  var data = sessionStorage.getItem(req.query.code);
  var decodedToken = util.decodeToken(data.access_token);

  return res.json({ 
    token: data.access_token,
    refresh_token: data.refresh_token,
    email: decodedToken.mail,
    exp: decodedToken.exp
  });
});

//#endregion

module.exports = router;
