//#region Libraries
require('dotenv-expand').expand(require ('dotenv').config());
//#endregion

module.exports = Object.freeze({   
    //Status Code
    INTERNAL_SERVER_ERROR: '500',
    SUCCESS: '200',
    PROCESSING: '202',
    CREATED: '201',
    NO_CONTENT: '204',
    NOT_AUTHENTICATED: '401',

    //Constants
    TOKEN_EXPIRED: 'token-expired',
    UNAUTHENTICATED: 'unauthenticated',
    AUTHENTICATED: 'authenticated',
    AUTH_FAILED_MSG: 'Authentication failed!',
    SESSION_ID_KEY: 'session-id',
    SESSION_EXP_TIMESTAMP: 'session-exp-timestamp',
    PUT: 'PUT',
    POST: 'POST',

    SECRET_KEY: 'mp2bodev',
    DEFAULT_TIMESTAMP :  'T00:00:00.000Z',
    NO_CONTENT_MSG : 'No Content',
    
    //Fusion Endpoints
    GET_SESSION_ID: `${process.env.BASE_URL}/login/machine-access`,
    INVOICE_BILL_PREVIEW_B2C: `${process.env.BASE_URL}/datasets/operationalQueue/invoiceBillPreviewB2C?PAGING=false&RESPONSEFORMAT=JSON{recache}`,
    UNRATED_USAGE: `${process.env.BASE_URL}/datasets/operationalQueue/unratedUsage?{creation_date_param}PAGING=false&RESPONSEFORMAT=JSON`,
    INVOICE_BATCH_LOG_ERROR: `${process.env.BASE_URL}/datasets/operationalQueue/invoiceBatchLogError?{message_date_param}PAGING=false&RESPONSEFORMAT=JSON`,
    UNBILLED_35_DAYS: `${process.env.BASE_URL}/datasets/operationalQueue/unbilled35Days?{check_date_param}PAGING=false&RESPONSEFORMAT=JSON`,
    PREVIEW_USAGE_HOLD: `${process.env.BASE_URL}/datasets/operationalQueue/previewUsageHold`,
    MONTHLY_USAGE: '/datasets/fusionUsage/monthlyUsage',
    CLOSE_BATCH_LOG_ERRORS: `${process.env.BASE_URL}/actions/fusionBatch/closeBatchLogDetail`,
    INVOICE_HOLIDAY_ID: `${process.env.BASE_URL}/datasets/fusionCalendar/calendar?CALENDAR_CODE=INV&PAGING=false&RESPONSEFORMAT=JSON`,
    INVOICE_HOLIDAYS: `${process.env.BASE_URL}/datasets/fusionCalendar/holiday?CALENDAR_ID={calendar_id}&PAGING=false&RESPONSEFORMAT=JSON`,
    BULK: `${process.env.BASE_URL}/actions/bulk/bulk`,
    BULK_CLOSE_BATCH_LOG_DETAILS: `/actions/fusionBatch/closeBatchLogDetail`,
    BULK_CHANGE_INVOICE_CYCLE: `/datasets/fusionAccount/account`,
    BULK_FUSION_SERVICE: `/datasets/fusionService/service`,
    FUSION_INTERACTION: `${process.env.BASE_URL}/datasets/fusionInteraction/interaction`,
    BULK_FUSION_INTERACTION: `/datasets/fusionInteraction/interaction`,
    COOKIE_NAME: `${process.env.BASE_URL}=s%3A`,

    //Legacy Endpoints    
    GET_PREBILLED_FAILED_ACCTS: `${process.env.LEGACY_BASE_URL}/ShellEnergyApi/api/v1/Usage/GetPrebilledFailedAccounts?filterDate=`,
    GET_CONTRACT_EXPIRING_ACCTS: `${process.env.LEGACY_BASE_URL}/ShellEnergyApi/api/v1/Usage/GetContractExpiringAccounts?minDate={min_date}&maxDate={max_date}`,
    GET_UNRATED_USAGE: `${process.env.LEGACY_BASE_URL}/ShellEnergyApi/api/v1/Usage/GetUnratedUsage?creationDate={creation_date}`,
    GET_INVOICE_BATCH_LOG_ERROR_B2B: `${process.env.LEGACY_BASE_URL}/ShellEnergyApi/api/v1/Usage/GetInvoiceBatchLogErrorsB2B?messageDate={message_date}`,
    GET_DUPLICATE_MONTHLY_USAGE: `${process.env.LEGACY_BASE_URL}/ShellEnergyApi/api/v1/Usage/GetDuplicateMonthlyUsage`,
    GET_UNBILLED_35: `${process.env.LEGACY_BASE_URL}/ShellEnergyApi/api/v1/Usage/GetUnbilled35Accounts?checkDate={checkDate}`,
    GET_PENDING_FIRST_BILL: `${process.env.LEGACY_BASE_URL}/ShellEnergyApi/api/v1/Usage/GetPendingFirstBillAccounts`,
    GET_MONTHLY_USAGE: `${process.env.LEGACY_BASE_URL}/ShellEnergyApi/api/v1/Usage/GetMonthlyUsageById?ldcAcctId={ldcAcctId}&monthlyUsageId={monthlyUsageId}`,
    GET_CALENDAR_BY_CODE: `${process.env.LEGACY_BASE_URL}/ShellEnergyApi/api/v1/Usage/GetCalendarByCode?calendarCode={calendarCode}`,
    GET_CALENDAR_HOLIDAYS: `${process.env.LEGACY_BASE_URL}/ShellEnergyApi/api/v1/Usage/GetCalendarHolidays?calendarCode={calendarCode}`,
    SET_INTERACTION: `${process.env.LEGACY_BASE_URL}/ShellEnergyApi/api/v1/Usage/SetInteraction?userName={userName}`,
    CODE_VERIFIER: 'hzsW4mN3grg0vhzsW4mN3grg0vhzsW4mN3grg0v-_Haa7dhNk37eM_RS256'
});