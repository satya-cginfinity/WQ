//#region Libraries
const express = require("express");
var router = express.Router();
var util = require('./common');
var Constants = require('./Utility/constants');
const fetch = require('node-fetch');
//#endregion

//#Legacy Endpoints
router.get('/GetPrebilledFailedAccounts', async (req, res) => {
  try {
    var url = Constants.GET_PREBILLED_FAILED_ACCTS;
    var options = util.getApiOptions(url);

    const response = await fetch(url,options);
    var status = await response.status;

    if (status == Constants.SUCCESS) {
        const data = await response.json();
        res.json(util.formatSuccessResponse(data));
      }
      else {
        var err = await response.error;
        res.json(util.formatError(response, 'GetPrebilledFailedAccounts-Error: ', err.toString()));
      }
    }
  catch (ex) {
    res.json(util.formatError(null, 'GetPrebilledFailedAccounts-Exception: ', ex.message?.toString()));
  }
});

router.get('/GetContractExpiringAccounts', async (req, res) => {
  try {
    var url = Constants.GET_CONTRACT_EXPIRING_ACCTS.replace("{min_date}", req.query.minDate).replace("{max_date}", req.query.maxDate);
    var options = util.getApiOptions(url);

    const response = await fetch(url, options);
    var status = await response.status;

    if (status == Constants.SUCCESS) {
      const data = await response.json();
      res.json(util.formatSuccessResponse(data));
    }
    else {
      var err = await response.error;
      res.json(util.formatError(response, 'GetContractExpiringAccounts-Error: ', err.toString()));
    }
  }
  catch (ex) {
    res.json(util.formatError(null, 'GetContractExpiringAccounts-Exception: ', ex.message?.toString()));
  }
});

router.get('/GetUnratedUsage', async (req, res) => {
  try {
    var url = Constants.GET_UNRATED_USAGE.replace("{creation_date}", req.query.creationDate);
    var options = util.getApiOptions(url);
    const response = await fetch(url, options);
    var status = await response.status;
    
    if (status == Constants.SUCCESS) {
      const data = await response.json();
      res.json(util.formatSuccessResponse(data));
    }
    else {
      var err = await response.error;
      res.json(util.formatError(response, 'GetUnratedUsage-Error: ', err.toString()));
    }
  }
  catch (ex) {
    res.json(util.formatError(null, 'GetUnratedUsage-Exception: ', ex.message?.toString()));
  }
});

router.get('/GetInvoiceBatchLogErrorsB2B', async (req, res) => {
  try {
    var url = Constants.GET_INVOICE_BATCH_LOG_ERROR_B2B.replace("{message_date}", req.query.messageDate);
    var options = util.getApiOptions(url);

    const response = await fetch(url, options);
    var status = await response.status;

    if (status == Constants.SUCCESS) {
      const data = await response.json();
      res.json(util.formatSuccessResponse(data));
    }
    else {
      var err = await response.error;
      res.json(util.formatError(response, 'GetInvoiceBatchLogErrorsB2B-Error: ', err.toString()));
    }
  }
  catch (ex) {
    res.json(util.formatError(null, 'GetInvoiceBatchLogErrorsB2B-Exception: ', ex.message?.toString()));
  }
});

router.get('/GetDuplicateMonthlyUsage', async (req, res) => {
  try {
    var url = Constants.GET_DUPLICATE_MONTHLY_USAGE
    var options = util.getApiOptions(url);

    const response = await fetch(url, options);
    var status = await response.status;

    if (status == Constants.SUCCESS) {
      const data = await response.json();
      res.json(util.formatSuccessResponse(data));
    }
    else {
      var err = await response.error;
      res.json(util.formatError(response, 'GetDuplicateMonthlyUsage-Error: ', err.toString()));
    }
  }
  catch (ex) {
    res.json(util.formatError(null, 'GetDuplicateMonthlyUsage-Exception: ', ex.message?.toString()));
  }
});

router.get('/GetUnbilled35', async (req, res) => {
  try {
    var url = Constants.GET_UNBILLED_35.replace("{checkDate}", req.query.checkDate);
    var options = util.getApiOptions(url);

    const response = await fetch(url, options);
    var status = await response.status;

    if (status == Constants.SUCCESS) {
      const data = await response.json();
      res.json(util.formatSuccessResponse(data));
    }
    else {
      var err = await response.error;
      res.json(util.formatError(response, 'GetUnbilled35-Error: ', err.toString()));
    }
  }
  catch (ex) {
    res.json(util.formatError(null, 'GetUnbilled35-Exception: ', ex.message?.toString()));
  }
});

router.get('/GetPendingFirstBill', async (req, res) => {
  try {
    var url = Constants.GET_PENDING_FIRST_BILL
    var options = util.getApiOptions(url);

    const response = await fetch(url, options);
    var status = await response.status;

    if (status == Constants.SUCCESS) {
      const data = await response.json();
      res.json(util.formatSuccessResponse(data));
    }
    else {
      var err = await response.error;
      res.json(util.formatError(response, 'GetPendingFirstBill-Error: ', err.toString()));
    }
  }
  catch (ex) {
    res.json(util.formatError(null, 'GetPendingFirstBill-Exception: ', ex.message?.toString()));
  }
});

router.get('/GetMonthlyUsageById', async (req, res) => {
  try {
    var url = Constants.GET_MONTHLY_USAGE.replace("{ldcAcctId}", req.query.ldcAcctId).replace("{monthlyUsageId}", req.query.monthlyUsageId);
    var options = util.getApiOptions(url);

    const response = await fetch(url, options);
    var status = await response.status;

    if (status == Constants.SUCCESS) {
      const data = await response.json();
      res.json(util.formatSuccessResponse(data));
    }
    else {
      var err = await response.error;
      res.json(util.formatError(response, 'GetMonthlyUsageById-Error: ', err.toString()));
    }
  }
  catch (ex) {
    res.json(util.formatError(null, 'GetMonthlyUsageById-Exception: ', ex.message?.toString()));
  }
});

router.get('/GetCalendarByCode', async (req, res) => {
  try {
    var url = Constants.GET_CALENDAR_BY_CODE.replace("{calendarCode}", req.query.calendarCode);
    var options = util.getApiOptions(url);

    const response = await fetch(url, options);
    var status = await response.status;

    if (status == Constants.SUCCESS) {
      const data = await response.json();
      res.json(util.formatSuccessResponse(data));
    }
    else {
      var err = await response.error;
      res.json(util.formatError(response, 'GetCalendarByCode-Error: ', err.toString()));
    }
  }
  catch (ex) {
    res.json(util.formatError(null, 'GetCalendarByCode-Exception: ', ex.message?.toString()));
  }
});

router.get('/GetCalendarHolidays', async (req,res)=>{
  try
  {
    var url = Constants.GET_CALENDAR_HOLIDAYS.replace("{calendarCode}", req.query.calendarCode);
    var options = util.getApiOptions(url);

    const response = await fetch(url, options);
    var status = await response.status;

    if (status == Constants.SUCCESS) {
      const data = await response.json();
      res.json(util.formatSuccessResponse(data));
    }
    else {
      var err = await response.error;
      res.json(util.formatError(response, 'GetCalendarHolidays-Error: ', err.toString()));
    }
  }
  catch (ex) {
    res.json(util.formatError(null, 'GetCalendarHolidays-Exception: ', ex.message?.toString()));
  }
});

router.post('/SetInteraction', async (req, res) => {
  try {
    var url = Constants.SET_INTERACTION.replace("{userName}", req.query.userName || req.params.userName);
    var options = util.getApiOptions(url);

    options.method = 'POST';
    options.body = JSON.stringify(req.body);
    options.headers = options.headers || {};
    options.headers['Content-Type'] = 'application/json';

    const response = await fetch(url, options);
    var status = await response.status;

    if (status == Constants.SUCCESS) {
      const data = await response.json();
      res.json(util.formatSuccessResponse(data));
    }
    else {
      var err = await response.error;
      res.json(util.formatError(response, 'SetInteraction-Error: ', err.toString()));
    }
  }
  catch (ex) {
    res.json(util.formatError(null, 'SetInteraction-Exception: ', ex.message?.toString()));
  }
});

//#endregion

module.exports = router;