//#region Libraries
require('dotenv-expand').expand(require ('dotenv').config());
const express = require('express');
const cors = require('cors');
const app = express();
const passport = require('passport');
var Constants = require('./Utility/constants');
var util = require('./common');
//#endregion

//#region Middlewares
app.use(cors());
app.use(express.json({limit: '10mb'}));
app.use(require('express-session')({ secret: Constants.SECRET_KEY, resave: false, saveUninitialized: false }));
app.use(passport.initialize());
app.use(passport.session());
//#endregion

//#region Initialization
var login = require('./login');
var fusion = require('./fusion');
var mp2API = require('./mp2API');
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
//#endregion

//#region Authentication and Routes
function checkAuthentication(req, res, next) {
  var issValid = false;
  var tokenIsNotExpired = false;
  var isTokenValid = false;
  try {
    var headerToken = req.header('access-token');
    var token = util.decodeToken(headerToken);
    issValid = token.clientid === process.env.SIMAAS_CLIENT_ID;
    var currentTimestamp = new Date().getTime() / 1000;
    tokenIsNotExpired = token.exp > currentTimestamp;

    isTokenValid = issValid && tokenIsNotExpired;
  }
  catch { }

  if (isTokenValid) {
    next();
  } else if (issValid && !tokenIsNotExpired) {
    res.json({ message: Constants.TOKEN_EXPIRED });
  }
  else {
    res.statusCode = 400;
    res.json({ message: Constants.UNAUTHENTICATED });
  }
}

app.use('/', login);
app.use('/api/',checkAuthentication, mp2API);
//#endregion

//#region Unathenticated Routes 

app.get("/healthstatus", (req, res) => {
  res.header('Access-Control_Allow-origin', '*');
  return res.json({ status: 200 });
});

//#endregion

//#region Others
app.listen(process.env.PORT, () =>
  console.log(`Server started at port ${process.env.PORT}`)
);

module.exports = app;
//#endregion
