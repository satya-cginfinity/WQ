# ses-work-queues
Operational work queues for B2B and B2B - Invoice Preview and Exception Handling
